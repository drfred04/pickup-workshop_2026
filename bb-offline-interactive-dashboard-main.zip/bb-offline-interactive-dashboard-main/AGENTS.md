# AGENTS.md — orientation for AI coding assistants

You are (most likely) helping a **faculty member set up and run this tool** on their own machine.
Read this file first, then `README.md` and `docs/SETUP.md`. Be patient and concrete: assume the
user is not a programmer.

## What this is

A local, **read-only** Python tool (package `bbdash`) that uses a faculty member's *own*
Blackboard REST API credentials to download their students' submissions and build a daily HTML
"morning dashboard" (who submitted / late / missing). All data stays on the user's machine — no
third-party cloud. **Platform: macOS and Windows** (both tested; all OS-specific code is isolated
in `bbdash/osutil.py`). Linux is best-effort (`xdg-open` + a tkinter dialog) but not regularly
tested.

## Two steps you (the AI) CANNOT do — the human must do them

Do **not** fabricate these, invent fake keys, or claim you performed them. Guide the user through
them and then continue:

1. **Register a developer application** on the Anthology developer portal to obtain the user's own
   **Application Key** and **Application Secret** (see `docs/SETUP.md`).
   ⚠️ The **Key is not the same as the Application ID** — pasting the ID into the Key field is the
   #1 setup mistake (causes HTTP 401).
2. **Get the user's campus Blackboard administrator to approve** that Application ID on their
   institution's instance (see `docs/IT_APPROVAL_EMAIL.md`, a ready-to-send request).
   **Until IT approves it, every run fails with HTTP 401 — this is expected, not a bug.**

## Setup you CAN help with (in order)

1. Confirm Python 3 exists: `python3 --version` (macOS/Linux) or `python --version` (Windows).
   macOS has it preinstalled; on Windows it's a separate install from python.org.
2. Create a virtual environment and install the one dependency:
   - macOS/Linux: `python3 -m venv .venv && .venv/bin/pip install -r requirements.txt`
   - Windows (PowerShell): `python -m venv .venv; .\.venv\Scripts\python.exe -m pip install -r requirements.txt`
   On **Apple Silicon**, build the venv from a *native arm64* Python (e.g. `/usr/bin/python3`) so
   it doesn't run under Rosetta — see `README_TECHNICAL.md`.
3. Run credential setup: `python3 install/setup_config.py` (Windows: `python install\setup_config.py`).
   By default it **creates `~/.bbdash/config.json` from a template and opens it in the editor**
   for the user to paste in their **Application Key**, **Application Secret**, and **username**
   (the **Base URL** is pre-filled). Add `--interactive` to type each value at a prompt instead
   (masked Secret). Re-running never overwrites an existing config — it just reopens it. On
   macOS/Linux the file is written `600`; on Windows it lives in the private user profile.
4. Verify (downloads nothing): `.venv/bin/python -m bbdash --check` (Windows:
   `.venv\Scripts\python.exe -m bbdash --check`, or `.\install\run.ps1 --check`) — lists the courses.
5. Full run: `.venv/bin/python -m bbdash` (Windows: `.\install\run.ps1`).

To try the tool with **no credentials and no real data**, run the demo: `python3 demo/demo_run.py`
(fake students, never contacts Blackboard).

## Common errors → what they mean

| Symptom | Meaning / fix |
|---|---|
| **HTTP 401** | IT hasn't approved the Application ID yet, **or** the Key/Secret is wrong (often the Application *ID* was pasted into the Key field). |
| **HTTP 403** on a course | The user isn't the instructor of record, or the grant lacks that entitlement. |
| **"0 courses found"** | Set `instructor_username` in `~/.bbdash/config.json`. |
| **`ModuleNotFoundError: requests`** | Dependencies not installed in the interpreter being used (activate the venv). |
| **Port already in use** | Change `opener_port` in the config (or set it to `0` to disable the optional companion). |
| **"Support Ending for Intel-based Apps" (macOS)** | The venv was built from an Intel Python; rebuild it from a native arm64 Python (see `README_TECHNICAL.md`). |

## Safety guardrails (important)

- The **Application Secret is a password.** Never print it, commit it, log it, or paste it into a
  public chat. On macOS/Linux `~/.bbdash/config.json` must stay `chmod 600`; on Windows it
  lives in the user's private profile (`%USERPROFILE%\.bbdash\`) and POSIX perms don't apply.
- Downloaded submissions, generated dashboards, and student photos are **FERPA-protected student
  records.** Never upload, commit, or sync them. They live in `~/BB Offline Dashboard/` and `~/.bbdash/`
  (outside this repo; also gitignored).
- The tool is **read-only** — it must never write to Blackboard. Don't add code that does.
- Don't commit anything ignored by `.gitignore` (config, tokens, dashboards, avatars, the `.venv`).

## Where things are

| Path | What |
|---|---|
| `bbdash/` | The source. OS-specific code is isolated in `bbdash/osutil.py`. |
| `install/` | `setup_config.py`, the run scripts (`run.sh`/`run.ps1`), macOS launch agents (`launchagents/`), and Windows Task Scheduler setup (`windows/`). |
| `docs/` | `SETUP.md`, `IT_APPROVAL_EMAIL.md`, `ARCHITECTURE.md`, `CONFIGURATION.md`, `DESIGN_NOTES.md`. |
| `demo/` | Self-contained fake-data demo (`demo_run.py`). |
| `config.example.json` | Template for `~/.bbdash/config.json`. |
