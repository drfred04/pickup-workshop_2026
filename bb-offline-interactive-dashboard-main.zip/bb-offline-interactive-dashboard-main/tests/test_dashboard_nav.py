"""Dashboard section order, Previous/Next snapshot navigation, and keep_previous pruning."""
import tempfile
import unittest
from datetime import datetime
from pathlib import Path

from bbdash.dashboard import render, DashboardData


def _render(d, y, mo, day, h, mi, keep=True):
    return render(DashboardData(generated_at=datetime(y, mo, day, h, mi)), d, keep_previous=keep)


class SectionOrderTest(unittest.TestCase):
    def test_missing_comes_before_submitted_tables(self):
        d = Path(tempfile.mkdtemp())
        html = _render(d, 2026, 7, 4, 6, 0).read_text()
        self.assertLess(html.index("<h2 id='sec-missing'>"), html.index("<h2 id='sec-new'>"))
        self.assertLess(html.index("<h2 id='sec-new'>"), html.index("<h2 id='sec-late'>"))


class PrevNextNavTest(unittest.TestCase):
    def setUp(self):
        self.d = Path(tempfile.mkdtemp())

    def test_second_run_links_back_and_patches_first(self):
        p1 = _render(self.d, 2026, 7, 4, 6, 0)
        p2 = _render(self.d, 2026, 7, 4, 9, 30)
        t1, t2 = p1.read_text(), p2.read_text()
        # the newest links to its predecessor
        self.assertIn("Previous Dashboard", t2)
        self.assertIn(p1.name, t2)
        # ...and the predecessor was patched to point forward
        self.assertIn("Next Dashboard", t1)
        self.assertIn(p2.name, t1)

    def test_first_dashboard_has_no_previous_and_keeps_marker_until_succeeded(self):
        p1 = _render(self.d, 2026, 7, 4, 6, 0)
        self.assertNotIn("Previous Dashboard", p1.read_text())   # nothing before it
        self.assertIn("<!--NEXTLINK-->", p1.read_text())         # awaiting a successor
        _render(self.d, 2026, 7, 4, 9, 30)                        # create the successor
        self.assertNotIn("<!--NEXTLINK-->", p1.read_text())      # marker now consumed


class KeepPreviousTest(unittest.TestCase):
    def test_false_keeps_only_latest_and_prunes_subfolders(self):
        d = Path(tempfile.mkdtemp())
        _render(d, 2026, 7, 4, 6, 0)
        (d / "details" / "2026-07-04__06-00").mkdir(parents=True, exist_ok=True)
        p2 = _render(d, 2026, 7, 4, 9, 30, keep=False)
        self.assertEqual(sorted(x.name for x in d.glob("*.html")), [p2.name])
        # the stale per-run detail subfolder is gone
        left = sorted(x.name for x in (d / "details").iterdir()) if (d / "details").is_dir() else []
        self.assertNotIn("2026-07-04__06-00", left)
        self.assertNotIn("<div class='dashnav'>", p2.read_text())  # no nav for a lone snapshot

    def test_true_keeps_both(self):
        d = Path(tempfile.mkdtemp())
        _render(d, 2026, 7, 4, 6, 0)
        _render(d, 2026, 7, 4, 9, 30, keep=True)
        self.assertEqual(len(list(d.glob("*.html"))), 2)


if __name__ == "__main__":
    unittest.main()
