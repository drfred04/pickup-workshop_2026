"""Tests for the nudge-email wording (now driven by configurable body templates) and the config
template staying in sync."""
import json
import unittest
from urllib.parse import unquote

from bbdash.config import (Config, DEFAULT_MISSING_EMAIL_NEW, DEFAULT_MISSING_EMAIL_OLD,
                           _strip_jsonc)
from bbdash.main import _missing_mailto, _missing_mailto_group, _fill_email


def _body(mailto: str) -> str:
    return unquote(mailto.split("body=", 1)[1])


class MissingMailtoTest(unittest.TestCase):
    def test_recent_default_says_last_night(self):
        m = _missing_mailto("s@x.edu", "Jack", "Homework 11", "PHYS 220", DEFAULT_MISSING_EMAIL_NEW)
        body = _body(m)
        self.assertIn("Hi Jack,", body)
        self.assertIn("didn't get Homework 11 turned in last night for PHYS 220", body)

    def test_older_default_says_still_missing(self):
        m = _missing_mailto("s@x.edu", "Jack", "Homework 3", "PHYS 220", DEFAULT_MISSING_EMAIL_OLD)
        body = _body(m)
        self.assertIn("Homework 3 is still missing for PHYS 220.", body)
        self.assertNotIn("last night", body)

    def test_addressed_to_the_student(self):
        m = _missing_mailto("jack@school.edu", "Jack", "HW1", "C", DEFAULT_MISSING_EMAIL_NEW)
        self.assertTrue(m.startswith("mailto:jack@school.edu?"))

    def test_custom_template_is_used(self):
        tmpl = "Yo {first_name} — where is {assignment} for {course_number}??"
        body = _body(_missing_mailto("s@x.edu", "Sam", "Lab 2", "PHYS 101", tmpl))
        self.assertEqual(body, "Yo Sam — where is Lab 2 for PHYS 101??")

    def test_group_uses_all_greeting(self):
        body = _body(_missing_mailto_group(["a@x.edu", "b@x.edu"], "HW9", "PHYS 320",
                                           DEFAULT_MISSING_EMAIL_NEW))
        self.assertIn("Hi all,", body)
        self.assertIn("HW9", body)


class FillEmailTest(unittest.TestCase):
    def test_unknown_placeholder_left_intact_not_crashing(self):
        out = _fill_email("Hi {first_name}, {unknown} thing about {assignment}.",
                          "Jo", "HW1", "C")
        self.assertEqual(out, "Hi Jo, {unknown} thing about HW1.")

    def test_stray_brace_does_not_crash(self):
        # A malformed template (lone '{') must return something, never raise.
        self.assertIsInstance(_fill_email("Hi {first_name} { oops", "Jo", "HW1", "C"), str)


class ConfigParityTest(unittest.TestCase):
    def test_example_matches_dataclass(self):
        with open("config.example.json") as f:
            example = set(json.loads(_strip_jsonc(f.read())).keys())
        fields = set(Config.__dataclass_fields__.keys())
        self.assertEqual(example - fields, set(), "example.json has keys the Config lacks")
        self.assertEqual(fields - example, set(), "Config has fields missing from example.json")


if __name__ == "__main__":
    unittest.main()
