"""Embedded attachments: a file a student attaches inline in their submission body (e.g. a ZIP)
comes back only as a bbcswebdav link in the studentSubmission HTML, not via the files endpoint.
These tests pin: the link is parsed, the file is downloaded as a real file, and a pure-attachment
body no longer leaves a noise HTML .txt behind.
"""
import tempfile
import unittest
from pathlib import Path

from bbdash.discover import Course, NameInfo
from bbdash.download import process_attempt
from bbdash.state import State
from bbdash.submission import parse_submission
from bbdash.util import sha256_bytes

# The exact shape Blackboard sends (from a real PHYS-320 submission): entity-encoded data-bbfile.
ZIP_BODY = (
    '<br> <p><a href="https://fmarion.blackboard.com/bbcswebdav/internal/courses/20280/gradebook/'
    'submission/attempt/3/7/9/_3603379_1/embedded/Thermo_HW7.zip?Kq3cZcYS15=de14&amp;VxJw3wfC56=1"'
    ' data-bbtype="attachment" data-bbfile="{&quot;alternativeText&quot;:&quot;Thermo_HW7.zip&quot;,'
    '&quot;displayName&quot;:&quot;Thermo_HW7.zip&quot;,&quot;fileName&quot;:&quot;Thermo_HW7.zip&quot;,'
    '&quot;fileSize&quot;:288890,&quot;mimeType&quot;:&quot;application/zip&quot;,'
    '&quot;resourceUrl&quot;:&quot;https://fmarion.blackboard.com/bbcswebdav/internal/courses/20280/'
    'gradebook/submission/attempt/3/7/9/_3603379_1/embedded/Thermo_HW7.zip?Kq3cZcYS15=de14&amp;'
    'VxJw3wfC56=1&quot;,&quot;linkName&quot;:&quot;Thermo_HW7.zip&quot;}">Thermo_HW7.zip</a></p> <br>'
)


class ParseSubmissionTest(unittest.TestCase):
    def test_extracts_zip_attachment_and_empty_body(self):
        attachments, text = parse_submission(ZIP_BODY)
        self.assertEqual(len(attachments), 1)
        a = attachments[0]
        self.assertEqual(a.name, "Thermo_HW7.zip")
        self.assertEqual(a.mime, "application/zip")
        self.assertTrue(a.url.startswith("https://fmarion.blackboard.com/bbcswebdav/"))
        self.assertIn("Thermo_HW7.zip", a.url)
        self.assertEqual(text, "")   # body is nothing but the attachment -> no noise text

    def test_keeps_real_prose_and_still_finds_attachment(self):
        body = ('<p>Here is my homework, sorry it is late.</p>'
                '<p><a data-bbtype="attachment" data-bbfile="{&quot;fileName&quot;:&quot;a.zip&quot;,'
                '&quot;resourceUrl&quot;:&quot;https://x/a.zip&quot;}">a.zip</a></p>')
        attachments, text = parse_submission(body)
        self.assertEqual(len(attachments), 1)
        self.assertEqual(attachments[0].name, "a.zip")
        self.assertEqual(text, "Here is my homework, sorry it is late.")

    def test_plain_text_passes_through(self):
        attachments, text = parse_submission("just my typed answer, no file")
        self.assertEqual(attachments, [])
        self.assertEqual(text, "just my typed answer, no file")

    def test_derives_name_from_url_when_metadata_missing(self):
        body = '<a href="https://x/bbcswebdav/courses/1/embedded/Report%20Final.pdf?sig=1">file</a>'
        attachments, _ = parse_submission(body)
        self.assertEqual(len(attachments), 1)
        self.assertEqual(attachments[0].name, "Report Final.pdf")


class _EmbedClient:
    """No attempt files; the ZIP lives only in the submission body. download_to writes the bytes
    and returns (sha, None) so the name must come from the parsed attachment metadata."""
    def __init__(self, zip_bytes):
        self.zip = zip_bytes
        self.downloaded_urls = []

    def get_all(self, path):
        return []

    def download_to(self, url, dest):
        self.downloaded_urls.append(url)
        Path(dest).write_bytes(self.zip)
        return sha256_bytes(self.zip), None


class EmbeddedDownloadTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.out = Path(self.tmp) / "out"
        self.state = State(Path(self.tmp) / "state.json")
        self.course = Course(id="_c1_1", name="Thermo", code="PHYS-320-1")
        self.name = NameInfo(family="EngelhardtTest", given="LarryTest", username="larrytest")

    def _run(self, client):
        attempt = {"id": "_a1_1", "studentSubmission": ZIP_BODY}
        return process_attempt(client, self.course, "HW7", attempt,
                               self.name, self.state, self.out)

    def test_zip_is_downloaded_as_a_real_file(self):
        client = _EmbedClient(b"PK\x03\x04 zip-bytes")
        saved = self._run(client)
        names = [s.filename for s in saved]
        self.assertIn("EngelhardtTest_LarryTest_larrytest_Thermo_HW7.zip", names)
        # the real download URL (the resourceUrl) was used
        self.assertTrue(any("bbcswebdav" in u for u in client.downloaded_urls))
        f = next(self.out.rglob("*Thermo_HW7.zip"))
        self.assertEqual(f.read_bytes(), b"PK\x03\x04 zip-bytes")

    def test_pure_attachment_body_writes_no_text_file(self):
        self._run(_EmbedClient(b"PK\x03\x04"))
        self.assertEqual(list(self.out.rglob("*submission_text.txt")), [],
                         "a body that is only an attachment must not leave an HTML .txt")

    def test_second_run_skips_identical_zip(self):
        self._run(_EmbedClient(b"PK\x03\x04 zip-bytes"))
        saved2 = self._run(_EmbedClient(b"PK\x03\x04 zip-bytes"))
        zip_items = [s for s in saved2 if s.filename.endswith("Thermo_HW7.zip")]
        self.assertTrue(zip_items and zip_items[0].skipped)


if __name__ == "__main__":
    unittest.main()
