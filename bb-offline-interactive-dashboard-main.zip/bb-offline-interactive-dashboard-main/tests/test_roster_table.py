"""The 'All students' roster overview: placement (after Missing, before the submitted tables) and
the red (not submitted) / orange (late) row tints."""
import tempfile
import unittest
from datetime import datetime
from pathlib import Path

from bbdash.dashboard import render, DashboardData, RosterTable


class RosterTableTest(unittest.TestCase):
    def _html(self, tables):
        data = DashboardData(generated_at=datetime(2026, 7, 4, 6, 0))
        data.roster_tables = tables
        return render(data, Path(tempfile.mkdtemp())).read_text()

    def test_tints_and_placement(self):
        html = self._html([RosterTable(
            course="PHYS 220", assignment="Homework 1", due="2026-07-03 23:59",
            rows=[("Zed, Zoe", "z1", "rowmiss", "Not submitted"),
                  ("Ada, Amy", "a1", "rowlate", "Late"),
                  ("Bob, Ben", "b1", "", "On time")])])
        self.assertIn("id='sec-roster'", html)
        self.assertIn("<tr class='srow rowmiss'", html)   # not submitted -> red
        self.assertIn("<tr class='srow rowlate'", html)   # late -> orange
        # after Missing, before the New on time table
        self.assertLess(html.index("<h2 id='sec-missing'>"), html.index("<h2 id='sec-roster'>"))
        self.assertLess(html.index("<h2 id='sec-roster'>"), html.index("<h2 id='sec-new'>"))

    def test_omitted_when_empty(self):
        self.assertNotIn("id='sec-roster'", self._html([]))


if __name__ == "__main__":
    unittest.main()
