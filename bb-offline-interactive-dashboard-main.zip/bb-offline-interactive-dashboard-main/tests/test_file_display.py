"""Dashboard file rendering: the shown name drops the on-disk prefix, and each file carries an
on-time (green ✓) / late (orange L) flag matching the status grid."""
import unittest

from bbdash.dashboard import _file_link, _file_flag
from bbdash.main import _strip_prefix


class StripPrefixTest(unittest.TestCase):
    def test_drops_last_first_username_prefix(self):
        self.assertEqual(
            _strip_prefix("EngelhardtTest_LarryTest_larrytest_Animations with x.ipynb",
                          "EngelhardtTest_LarryTest_larrytest_"),
            "Animations with x.ipynb")

    def test_leaves_name_without_prefix_alone(self):
        self.assertEqual(_strip_prefix("hw.py", "Smith_Ann_asmith_"), "hw.py")

    def test_empty_prefix_is_noop(self):
        self.assertEqual(_strip_prefix("hw.py", ""), "hw.py")


class FileFlagTest(unittest.TestCase):
    def test_on_time_is_green_check(self):
        f = _file_flag(False)
        self.assertIn("ffok", f)
        self.assertIn("✓", f)
        self.assertNotIn("ffl'", f)

    def test_late_is_orange_L(self):
        f = _file_flag(True)
        self.assertIn("ffl", f)
        self.assertIn(">L<", f)

    def test_late_shows_submission_time_inline(self):
        f = _file_flag(True, "2026-07-04 06:00")
        self.assertIn("latewhen", f)
        self.assertIn("2026-07-04 06:00", f)

    def test_on_time_never_shows_a_time(self):
        self.assertNotIn("latewhen", _file_flag(False, "2026-07-04 06:00"))


class FileLinkTest(unittest.TestCase):
    def test_shows_display_name_links_full_path_and_flags_late(self):
        html = _file_link(("hw.ipynb", "/x/Smith_Ann_asmith_hw.ipynb", True))
        self.assertIn(">hw.ipynb</a>", html)              # visible text is the short name
        self.assertIn("Smith_Ann_asmith_hw.ipynb", html)  # link target keeps the on-disk name
        self.assertIn("ffl", html)                         # late flag present

    def test_two_tuple_defaults_to_on_time(self):
        html = _file_link(("hw.py", "/x/Smith_Ann_asmith_hw.py"))
        self.assertIn("ffok", html)

    def test_four_tuple_late_file_shows_time(self):
        html = _file_link(("plot.png", "/x/Smith_Ann_asmith_plot.png", True, "2026-07-04 06:00"))
        self.assertIn(">plot.png</a>", html)
        self.assertIn("ffl", html)
        self.assertIn("2026-07-04 06:00", html)

    def test_opener_prefix_builds_companion_url(self):
        html = _file_link(("hw.py", "/x/hw.py", False),
                          opener_prefix="http://127.0.0.1:8765/open?path=", opener_token="tok")
        self.assertIn("bbOpen(", html)
        self.assertIn("token=tok", html)


if __name__ == "__main__":
    unittest.main()
