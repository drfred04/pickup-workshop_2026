"""Regression tests for how downloaded submission files are named.

The key bug (found 2026-07-04): on Blackboard **Ultra** assignments, the attempt-files
*listing* endpoint returns an internal storage key in its ``name`` field (e.g. "16989750_1")
instead of the original filename. The real name is only in the download response's
``Content-Disposition`` header. These tests pin the fix: the on-disk name must use the real
filename (with its extension), which also lets the ``_nocomments`` copy trigger.
"""
import tempfile
import unittest
from pathlib import Path

from bbdash.discover import Course, NameInfo
from bbdash.download import process_attempt
from bbdash.state import State

NB = (
    '{"cells":[{"cell_type":"code","source":["import numpy as np  # comment\\n",'
    '"x = 1\\n"]},{"cell_type":"markdown","source":["# a heading"]}],'
    '"metadata":{"kernelspec":{"language":"python","name":"python3"}},'
    '"nbformat":4,"nbformat_minor":5}'
)


class _UltraClient:
    """Mimics Ultra: the files listing gives a storage key; the download reveals the real
    name via (sha, real_name), the shape bbdash.api.download_to now returns."""

    def __init__(self, listing_name, real_name, content):
        self.listing_name = listing_name
        self.real_name = real_name
        self.content = content

    def get_all(self, path):
        if path.endswith("/files"):
            return [{"id": "_file1_1", "name": self.listing_name}]
        return []

    def download_to(self, endpoint, dest):
        from bbdash.util import sha256_bytes
        Path(dest).write_bytes(self.content)
        return sha256_bytes(self.content), self.real_name


class DownloadNamingTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.out = Path(self.tmp) / "out"
        self.state = State(Path(self.tmp) / "state.json")
        self.course = Course(id="_c1_1", name="PHYS 397 Research", code="PHYS-397-2")
        self.name = NameInfo(family="EngelhardtTest", given="LarryTest", username="larrytest")

    def _run(self, listing_name, real_name, content=b'{"cells":[],"nbformat":4}'):
        client = _UltraClient(listing_name, real_name, content)
        attempt = {"id": "_a1_1"}
        return process_attempt(client, self.course, "Assignment 1 - Test", attempt,
                               self.name, self.state, self.out, strip_docstrings=True)

    def test_real_filename_beats_storage_key(self):
        saved = self._run("16989750_1", "Animations with Matplotlib.ipynb")
        names = [s.filename for s in saved]
        # The original must carry the real name + extension, not the storage key.
        self.assertIn("EngelhardtTest_LarryTest_larrytest_Animations with Matplotlib.ipynb", names)
        self.assertFalse(any("16989750_1" in n for n in names),
                         f"storage key leaked into a filename: {names}")

    def test_extension_present_enables_nocomments_copy(self):
        saved = self._run("16989750_1", "hw.ipynb", NB.encode())
        names = [s.filename for s in saved]
        self.assertTrue(any(n.endswith("hw.ipynb") for n in names))
        self.assertTrue(any(n.endswith("hw_nocomments.ipynb") for n in names),
                        "the _nocomments copy did not get generated (extension lost?)")

    def test_falls_back_to_listing_name_when_no_content_disposition(self):
        # Classic Learn (and the demo): no real name from the header -> use the listing name.
        client = _UltraClient("Homework 3.pdf", None, b"%PDF-1.4 data")
        saved = process_attempt(client, self.course, "A", {"id": "_a2_1"},
                                self.name, self.state, self.out)
        self.assertIn("EngelhardtTest_LarryTest_larrytest_Homework 3.pdf",
                      [s.filename for s in saved])

    def test_file_actually_written_with_correct_bytes(self):
        self._run("16989750_1", "data.bin", b"\x00\x01\x02hello")
        f = next((self.out).rglob("*data.bin"))
        self.assertEqual(f.read_bytes(), b"\x00\x01\x02hello")

    def test_second_run_skips_identical_file(self):
        self._run("16989750_1", "hw.ipynb", NB.encode())
        saved2 = self._run("16989750_1", "hw.ipynb", NB.encode())
        original = [s for s in saved2 if s.filename.endswith("hw.ipynb")]
        self.assertTrue(original and original[0].skipped,
                        "an unchanged file should be skipped on the second run")


if __name__ == "__main__":
    unittest.main()
