"""Fast unit tests for the pure helpers (no network, no filesystem beyond temp)."""
import json
import unittest
from types import SimpleNamespace

from bbdash.api import _response_filename
from bbdash.codeproc import strip_python_comments, strip_notebook_comments
from bbdash.config import _parse_weekday, _strip_jsonc
from bbdash.util import sanitize, parse_dt


class WeekdayParseTest(unittest.TestCase):
    def test_names_case_insensitive(self):
        self.assertEqual(_parse_weekday("Monday"), 0)
        self.assertEqual(_parse_weekday("mon"), 0)
        self.assertEqual(_parse_weekday("SUNDAY"), 6)
        self.assertEqual(_parse_weekday("Weds"), 2)

    def test_ints_and_numeric_strings(self):
        self.assertEqual(_parse_weekday(4), 4)
        self.assertEqual(_parse_weekday("4"), 4)

    def test_out_of_range_and_junk_fall_back_to_monday(self):
        self.assertEqual(_parse_weekday(9), 0)
        self.assertEqual(_parse_weekday("someday"), 0)
        self.assertEqual(_parse_weekday(True), 0)   # bool must not be read as weekday 1


class StripJsoncTest(unittest.TestCase):
    def test_line_comment_removed_but_url_preserved(self):
        src = ('{\n  "url": "https://x.edu/a?b=1",  // a comment\n'
               '  "port": 8765 // trailing\n}')
        d = json.loads(_strip_jsonc(src))
        self.assertEqual(d["url"], "https://x.edu/a?b=1")   # // inside the string survived
        self.assertEqual(d["port"], 8765)

    def test_block_comment_removed(self):
        d = json.loads(_strip_jsonc('{/* hi */ "a": 1, "b": 2 /* end */}'))
        self.assertEqual(d, {"a": 1, "b": 2})

    def test_slashes_in_string_value_untouched(self):
        d = json.loads(_strip_jsonc('{"note": "use // or /* */ in text"}'))
        self.assertEqual(d["note"], "use // or /* */ in text")

    def test_plain_json_unchanged(self):
        self.assertEqual(json.loads(_strip_jsonc('{"a": 1}')), {"a": 1})


def _resp(cd=None, url=""):
    return SimpleNamespace(headers={"Content-Disposition": cd} if cd else {}, url=url)


class ResponseFilenameTest(unittest.TestCase):
    def test_rfc5987_utf8(self):
        cd = ("attachment; filename=\"Animations.ipynb\"; "
              "filename*=UTF-8''Animations%20with%20Matplotlib.ipynb")
        self.assertEqual(_response_filename(_resp(cd)), "Animations with Matplotlib.ipynb")

    def test_plain_quoted(self):
        self.assertEqual(_response_filename(_resp('attachment; filename="a b.pdf"')), "a b.pdf")

    def test_bare_token(self):
        self.assertEqual(_response_filename(_resp("attachment; filename=bare.py")), "bare.py")

    def test_non_ascii_percent(self):
        self.assertEqual(_response_filename(_resp("attachment; filename*=utf-8''caf%C3%A9.txt")),
                         "café.txt")

    def test_url_basename_fallback(self):
        self.assertEqual(_response_filename(_resp(None, "https://x/a/b/Real%20Name.gif")),
                         "Real Name.gif")

    def test_none_when_nothing(self):
        self.assertIsNone(_response_filename(_resp(None, "")))


class SanitizeTest(unittest.TestCase):
    def test_path_traversal_neutralised(self):
        import os
        s = sanitize("../../etc/passwd")
        # The real security property: it's a single filesystem component (no separators),
        # so it can never traverse out of the target directory.
        self.assertNotIn("/", s)
        self.assertNotIn("\\", s)
        self.assertEqual(os.path.basename(s), s)
        self.assertNotIn(s, ("..", "."))       # bare traversal tokens collapse to "unnamed"
        self.assertEqual(sanitize(".."), "unnamed")

    def test_keeps_spaces_dots_dashes(self):
        self.assertEqual(sanitize("Homework 3 - final.ipynb"), "Homework 3 - final.ipynb")

    def test_strips_control_and_slashes(self):
        self.assertNotIn("\n", sanitize("a\nb"))
        self.assertNotIn("\\", sanitize("a\\b"))

    def test_empty_becomes_unnamed(self):
        self.assertEqual(sanitize("   "), "unnamed")


class ParseDtTest(unittest.TestCase):
    def test_z_suffix_is_utc(self):
        dt = parse_dt("2026-07-04T15:35:05.817Z")
        self.assertEqual(dt.utcoffset().total_seconds(), 0)

    def test_bad_returns_none(self):
        self.assertIsNone(parse_dt("not a date"))
        self.assertIsNone(parse_dt(None))


class CodeprocTest(unittest.TestCase):
    def test_comment_removed_string_hash_kept(self):
        src = 'x = 1  # a comment\ny = "not # a comment"\n'
        out = strip_python_comments(src)
        self.assertIn("x = 1\n", out)               # the trailing comment was removed
        self.assertNotIn("x = 1  #", out)
        self.assertIn('"not # a comment"', out)     # a '#' inside a string is preserved

    def test_shebang_kept(self):
        out = strip_python_comments("#!/usr/bin/env python3\nx=1  # c\n")
        self.assertTrue(out.startswith("#!/usr/bin/env python3"))

    def test_docstring_removed_sole_becomes_pass(self):
        src = 'def f():\n    """doc"""\n'
        out = strip_python_comments(src, strip_docstrings=True)
        self.assertNotIn("doc", out)
        self.assertIn("pass", out)

    def test_invalid_python_not_corrupted(self):
        src = "def f(:\n  # c\n"   # syntax error
        out = strip_python_comments(src, strip_docstrings=True)
        self.assertIn("def f(:", out)  # returned, not crashed

    def test_notebook_strips_code_keeps_markdown_and_valid(self):
        nb = {
            "cells": [
                {"cell_type": "code", "source": ["import os  # c\n", "x=1\n"]},
                {"cell_type": "markdown", "source": ["# a heading (not code)"]},
                {"cell_type": "code", "source": ["%%bash\necho hi  # keep\n"]},
            ],
            "metadata": {"kernelspec": {"language": "python", "name": "python3"}},
            "nbformat": 4, "nbformat_minor": 5,
        }
        out = strip_notebook_comments(json.dumps(nb), strip_docstrings=True)
        parsed = json.loads(out)                       # must remain valid JSON/nbformat
        self.assertEqual(parsed["nbformat"], 4)
        code0 = "".join(parsed["cells"][0]["source"])
        self.assertNotIn("# c", code0)                 # comment stripped
        self.assertIn("# a heading", "".join(parsed["cells"][1]["source"]))  # markdown untouched
        self.assertIn("# keep", "".join(parsed["cells"][2]["source"]))       # cell-magic untouched

    def test_non_python_notebook_returns_none(self):
        nb = {"cells": [], "metadata": {"kernelspec": {"language": "R"}}, "nbformat": 4}
        self.assertIsNone(strip_notebook_comments(json.dumps(nb)))


if __name__ == "__main__":
    unittest.main()
