#!/usr/bin/env python3
"""One-time credential setup for the Blackboard morning-dashboard tool (BYOK).

Two ways to run it:

    python3 setup_config.py                # DEFAULT: create the config file and open it in your
                                           # editor so you can paste your values in and save.
    python3 setup_config.py --interactive  # type answers at prompts instead (masked Secret).

Either way it writes ~/.bbdash/config.json with owner-only permissions (chmod 600 on
macOS/Linux). Your Secret is stored only in that local, permission-restricted file. This script
has NO third-party dependencies — it uses only the Python standard library.

This matches the tool's existing configuration system (a JSON config file, with optional
environment-variable overrides). It does not introduce a separate .env mechanism.
"""
from __future__ import annotations

import json
import os
import stat
import subprocess
import sys
from pathlib import Path

CONFIG_DIR = Path.home() / ".bbdash"
CONFIG_PATH = CONFIG_DIR / "config.json"

# Template written on first run (default, file-based setup). Placeholders make it obvious what
# to replace; domain/email are pre-filled for FMU (edit if your institution differs).
_TEMPLATE = {
    "domain": "blackboard.fmarion.edu",
    "application_key": "PASTE-YOUR-APPLICATION-KEY-HERE",
    "application_secret": "PASTE-YOUR-APPLICATION-SECRET-HERE",
    "instructor_username": "your-blackboard-username",
    "term_filter": ["Fall 2026"],
    "course_filter": [],
    "student_email_domain": "g.fmarion.edu",
}


def _read_masked(prompt: str) -> str:
    """Read a line without echoing the characters, but print a '*' for each one typed, so you
    can see how many characters you've entered (and correct typos with backspace). Falls back
    to a fully-hidden getpass if the terminal doesn't support character-at-a-time reads."""
    try:
        if os.name == "nt":
            return _read_masked_windows(prompt)
        return _read_masked_posix(prompt)
    except (ImportError, OSError, EOFError):
        import getpass
        return getpass.getpass(prompt)


def _read_masked_windows(prompt: str) -> str:
    import msvcrt
    sys.stdout.write(prompt)
    sys.stdout.flush()
    chars: list[str] = []
    while True:
        ch = msvcrt.getwch()
        if ch in ("\r", "\n"):
            sys.stdout.write("\n")
            sys.stdout.flush()
            return "".join(chars)
        if ch == "\x03":                 # Ctrl-C
            raise KeyboardInterrupt
        if ch in ("\x00", "\xe0"):       # function/arrow key -> consume and ignore the 2nd byte
            msvcrt.getwch()
            continue
        if ch == "\b":                   # backspace
            if chars:
                chars.pop()
                sys.stdout.write("\b \b")
                sys.stdout.flush()
            continue
        chars.append(ch)
        sys.stdout.write("*")
        sys.stdout.flush()


def _read_masked_posix(prompt: str) -> str:
    import termios
    import tty
    sys.stdout.write(prompt)
    sys.stdout.flush()
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    chars: list[str] = []
    try:
        tty.setraw(fd)
        while True:
            ch = sys.stdin.read(1)
            if ch in ("\r", "\n"):
                return "".join(chars)
            if ch == "\x03":             # Ctrl-C
                raise KeyboardInterrupt
            if ch in ("\x7f", "\b"):     # backspace/delete
                if chars:
                    chars.pop()
                    sys.stdout.write("\b \b")
                    sys.stdout.flush()
                continue
            chars.append(ch)
            sys.stdout.write("*")
            sys.stdout.flush()
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)
        sys.stdout.write("\n")
        sys.stdout.flush()


def _prompt(label: str, *, default: str = "", secret: bool = False, required: bool = True) -> str:
    suffix = f" [{default}]" if default else ""
    while True:
        if secret:
            value = _read_masked(f"{label}{suffix}: ").strip()
        else:
            value = input(f"{label}{suffix}: ").strip()
        if not value and default:
            return default
        if value or not required:
            return value
        print("  (required) — please enter a value.")


def _verify_command() -> str:
    """The `--check` command that will actually work on this machine. Prefers the project
    virtualenv's interpreter if it exists (so it isn't the system Python that lacks `requests`),
    and uses Windows vs. POSIX path/quoting conventions."""
    project_dir = Path(__file__).resolve().parent.parent
    if os.name == "nt":
        venv_py = project_dir / ".venv" / "Scripts" / "python.exe"
        if venv_py.exists():
            return r".\.venv\Scripts\python.exe -m bbdash --check"
        # No venv found: run.ps1 auto-detects an interpreter and is the safest thing to suggest.
        return r".\install\run.ps1 --check"
    venv_py = project_dir / ".venv" / "bin" / "python"
    if venv_py.exists():
        return ".venv/bin/python -m bbdash --check"
    return "python3 -m bbdash --check"


def _normalize_base_url(raw: str) -> str:
    """Accept a full Blackboard URL and reduce it to scheme + host (no trailing path/slash)."""
    raw = raw.strip().rstrip("/")
    if not raw:
        return raw
    if not raw.startswith("http"):
        raw = "https://" + raw
    # Keep only scheme://host (strip any path the user pasted from their address bar).
    from urllib.parse import urlparse
    p = urlparse(raw)
    host = p.netloc or p.path  # if they typed just a hostname, it lands in path
    return f"{p.scheme or 'https'}://{host}".rstrip("/")


def _utf8_console() -> None:
    """Emit UTF-8 so the ✓ and em dashes we print don't become mojibake on Windows' console."""
    if os.name == "nt":
        for _stream in (sys.stdout, sys.stderr):
            try:
                _stream.reconfigure(encoding="utf-8")  # type: ignore[union-attr]  # 3.7+ TextIO
            except (AttributeError, OSError, ValueError):
                pass


def _print_header() -> None:
    print("=" * 68)
    print(" Blackboard Morning Dashboard — credential setup")
    print("=" * 68)
    print("You'll need: your Blackboard Base URL, your Application KEY and")
    print("SECRET (from developer.anthology.com), and your Blackboard username.")
    print("Reminder: the Application KEY is NOT the Application ID.\n")


def _write_json(path: Path, data: dict) -> None:
    """Write JSON with owner-only permissions from the start (no world-readable window)."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        json.dump(data, f, indent=2)
    try:
        os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)  # 600, belt and suspenders
    except OSError:
        pass  # Windows: POSIX perms don't apply; the file lives in the private user profile.


def _open_in_editor(path: Path) -> None:
    """Open the config file in the OS default handler so the user can paste values and save."""
    try:
        if os.name == "nt":
            os.startfile(str(path))  # type: ignore[attr-defined]  # Windows-only
        elif sys.platform == "darwin":
            subprocess.run(["open", str(path)], check=False)
        else:
            subprocess.run(["xdg-open", str(path)], check=False)
    except OSError:
        pass  # Non-fatal: we also print the path so the user can open it manually.


def _file_setup() -> int:
    """DEFAULT setup: create the config file (if missing) and open it for the user to edit."""
    _print_header()
    existed = CONFIG_PATH.exists()
    if existed:
        print(f"Your config already exists (nothing overwritten):\n    {CONFIG_PATH}")
        print("Opening it so you can paste or update your values, then save.")
    else:
        _write_json(CONFIG_PATH, _TEMPLATE)
        print(f"Created a template config:\n    {CONFIG_PATH}")
        print("\nOpening it in your editor. Replace the placeholders, then SAVE:")
        print("    • application_key     — your Application KEY (NOT the Application ID)")
        print("    • application_secret  — your Application Secret")
        print("    • instructor_username — your Blackboard username")
        print("    • domain              — Base URL (pre-filled: blackboard.fmarion.edu — edit if different)")
        print('    • term_filter         — semester(s) to watch, e.g. ["Fall 2026"]  (or [] for all courses)')

    _open_in_editor(CONFIG_PATH)

    print(f"\nAfter you SAVE the file, verify your setup and course access with:")
    print(f"    {_verify_command()}")
    print("It lists your courses with their exact term names — copy one into 'term_filter'")
    print("if you want to narrow to a single semester.")
    print("\nPrefer typing answers at prompts instead (with a masked Secret)? Re-run with:")
    print("    ...setup_config.py --interactive")
    print("\nIf --check fails with HTTP 401, your campus IT hasn't approved your Application ID")
    print("yet (see IT_APPROVAL_EMAIL.md) — expected until they do.")
    return 0


def _interactive_setup() -> int:
    """Alternative setup: type each value at a prompt (Secret is masked with '*')."""
    _print_header()

    if CONFIG_PATH.exists():
        ans = input(f"{CONFIG_PATH} already exists. Overwrite? [y/N]: ").strip().lower()
        if ans not in ("y", "yes"):
            print("Aborted; existing config left unchanged.")
            return 0

    base_url = _normalize_base_url(
        _prompt("Blackboard Base URL (e.g. https://blackboard.yourschool.edu)")
    )
    application_key = _prompt("Application Key")
    application_secret = _prompt("Application Secret (hidden)", secret=True)
    instructor_username = _prompt("Your Blackboard username (e.g. jsmith)")

    print("\nOptional: restrict which courses the tool watches (recommended).")
    print("Easiest is by SEMESTER — type the term name, e.g. 'Fall 2026' (you can list several,")
    print("comma-separated). Leave blank to instead pick specific courses, or to watch them all.")
    raw_terms = _prompt("Semester / term", required=False)
    term_filter = [t.strip() for t in raw_terms.split(",") if t.strip()] if raw_terms else []

    course_filter = []
    if not term_filter:
        print("\nOr restrict to specific courses by ID or code (comma-separated),")
        print("or leave blank to watch all your courses.")
        raw_filter = _prompt("Course ID/code filter", required=False)
        course_filter = [c.strip() for c in raw_filter.split(",") if c.strip()] if raw_filter else []

    if not term_filter and not course_filter:
        print("\n(No filter set — the tool will watch all courses you teach. You can narrow this")
        print(" later by editing 'term_filter' or 'course_filter' in the config file.)")

    config = {
        "domain": base_url,
        "application_key": application_key,
        "application_secret": application_secret,
        "instructor_username": instructor_username,
        "term_filter": term_filter,
        "course_filter": course_filter,
    }

    _write_json(CONFIG_PATH, config)

    # Show the verify command that actually works on THIS OS. On Windows, `python3` is usually
    # the wrong interpreter (system Python without `requests`); the venv's python or run.ps1 is
    # what's needed — so print that instead of the mac/Linux `python3`.
    print(f"\n✓ Wrote {CONFIG_PATH}.")
    print("\nNext: verify your setup and course access with")
    print(f"    {_verify_command()}")
    print("It lists your courses with their exact term names — copy one into 'term_filter'")
    print("in the config if you want to narrow to a single semester.")
    print("\nIf that fails with HTTP 401, your campus IT has not yet approved your")
    print("Application ID (see IT_APPROVAL_EMAIL.md). That is expected until they do.")
    return 0


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    _utf8_console()
    if any(a in ("-i", "--interactive", "--prompt") for a in argv):
        return _interactive_setup()
    return _file_setup()


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("\nCancelled.")
        sys.exit(1)
