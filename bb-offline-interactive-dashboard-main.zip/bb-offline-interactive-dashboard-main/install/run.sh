#!/bin/bash
# Wrapper that launchd (or you) can call to produce the morning dashboard.
# Lives in install/; PROJECT_DIR is this script's parent (the project root).
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_DIR"

# Use the project virtualenv if present, else the system python3.
if [ -x "$PROJECT_DIR/.venv/bin/python" ]; then
  PY="$PROJECT_DIR/.venv/bin/python"
else
  PY="$(command -v python3)"
fi

exec "$PY" -m bbdash "$@"
