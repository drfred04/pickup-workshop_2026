# Wrapper that runs the "open file" companion server (keeps running in the background).
# Lives in install/; the project root is this script's parent directory.
# Windows equivalent of run_opener.sh.
$ErrorActionPreference = 'Stop'

$ProjectDir = Split-Path -Parent $PSScriptRoot
Set-Location $ProjectDir

$venvPy = Join-Path $ProjectDir '.venv\Scripts\python.exe'
if (Test-Path $venvPy) {
    $py = $venvPy
} else {
    $cmd = Get-Command python -ErrorAction SilentlyContinue
    if (-not $cmd) { $cmd = Get-Command python3 -ErrorAction SilentlyContinue }
    if (-not $cmd) {
        throw "No Python found. Create the venv (python -m venv .venv) or install Python from python.org."
    }
    $py = $cmd.Source
}

# When launched by the scheduled task, BBREPORT_LOG names a stdout log file; stderr goes to a
# sibling ".err" file (see run.ps1 for why Start-Process is used).
if ($env:BBREPORT_LOG) {
    $outLog = $env:BBREPORT_LOG
    $errLog = Join-Path (Split-Path $outLog -Parent) `
        ("{0}.err{1}" -f [IO.Path]::GetFileNameWithoutExtension($outLog), [IO.Path]::GetExtension($outLog))
    $p = Start-Process -FilePath $py -ArgumentList (@('-m', 'bbdash.opener') + $args) `
        -NoNewWindow -Wait -PassThru -RedirectStandardOutput $outLog -RedirectStandardError $errLog
    exit $p.ExitCode
} else {
    & $py -m bbdash.opener @args
    exit $LASTEXITCODE
}
