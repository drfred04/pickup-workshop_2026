#Requires -Version 5.1
<#
.SYNOPSIS
    Create (or remove) a Start Menu shortcut that runs the BB Offline Dashboard with one
    click — the Windows equivalent of the macOS Dock app.

.DESCRIPTION
    Adds "BB Offline Dashboard" to your Start Menu. Clicking it runs `python -m bbdash` using
    the project's virtualenv, with no terminal window (it uses pythonw.exe). By default it shows
    the "Download from Blackboard?" dialog first (so a click gives instant feedback and can be cancelled);
    pass -NoPrompt to have it just run. The shortcut is branded with the project icon
    (bbdash/icon.png is resized to 256x256 and saved as ~/.bbdash/icon.ico).

    Per-user, no admin rights required. Remove it with -Remove.

.PARAMETER Name
    Shortcut name (the Start Menu label). Default "BB Offline Dashboard".

.PARAMETER NoPrompt
    Make the shortcut run immediately with no "Download from Blackboard?" dialog.

.PARAMETER Remove
    Remove the shortcut (and the generated icon) instead of creating it.

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File install\windows\install_shortcut.ps1

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File install\windows\install_shortcut.ps1 -NoPrompt

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File install\windows\install_shortcut.ps1 -Remove
#>
[CmdletBinding()]
param(
    [string]$Name = "BB Offline Dashboard",
    [switch]$NoPrompt,
    [switch]$Remove
)

$ErrorActionPreference = 'Stop'

$ProjectDir = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$StartMenu  = [Environment]::GetFolderPath('Programs')
$LnkPath    = Join-Path $StartMenu "$Name.lnk"
$IcoPath    = Join-Path $env:USERPROFILE '.bbdash\icon.ico'

if ($Remove) {
    foreach ($p in @($LnkPath, $IcoPath)) {
        if (Test-Path $p) { Remove-Item $p -Force; Write-Host "Removed $p" }
        else { Write-Host "Not found: $p" }
    }
    return
}

# Prefer the venv's windowless interpreter (pythonw.exe = no console window).
$pyw = Join-Path $ProjectDir '.venv\Scripts\pythonw.exe'
if (-not (Test-Path $pyw)) {
    $cmd = Get-Command pythonw -ErrorAction SilentlyContinue
    if (-not $cmd) {
        throw "No pythonw.exe found. Create the project virtualenv first: python -m venv .venv"
    }
    $pyw = $cmd.Source
    Write-Warning "No project venv found; using $pyw (make sure 'requests' is installed for it)."
}

# Build a 256x256 .ico from bbdash/icon.png (best effort; skip the custom icon if it fails).
function New-IcoFromPng {
    param([string]$Png, [string]$Ico)
    Add-Type -AssemblyName System.Drawing
    $src = [System.Drawing.Image]::FromFile($Png)
    try {
        $bmp = New-Object System.Drawing.Bitmap 256, 256
        $g = [System.Drawing.Graphics]::FromImage($bmp)
        $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
        $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
        $g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
        $g.Clear([System.Drawing.Color]::Transparent)
        $g.DrawImage($src, 0, 0, 256, 256)
        $g.Dispose()
        $ms = New-Object System.IO.MemoryStream
        $bmp.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png)
        $bmp.Dispose()
        $pngBytes = $ms.ToArray()
        $ms.Dispose()
        # ICO container with one PNG-compressed 256x256 entry (width/height 0 => 256).
        $out = New-Object System.IO.MemoryStream
        $bw = New-Object System.IO.BinaryWriter $out
        $bw.Write([UInt16]0); $bw.Write([UInt16]1); $bw.Write([UInt16]1)     # ICONDIR
        $bw.Write([Byte]0); $bw.Write([Byte]0); $bw.Write([Byte]0); $bw.Write([Byte]0)
        $bw.Write([UInt16]1); $bw.Write([UInt16]32)
        $bw.Write([UInt32]$pngBytes.Length); $bw.Write([UInt32]22)           # size, offset
        $bw.Write($pngBytes)
        $bw.Flush()
        [System.IO.File]::WriteAllBytes($Ico, $out.ToArray())
        $bw.Dispose(); $out.Dispose()
    } finally {
        $src.Dispose()
    }
}

$iconOk = $false
$pngIcon = Join-Path $ProjectDir 'bbdash\icon.png'
if (Test-Path $pngIcon) {
    try {
        New-Item -ItemType Directory -Force -Path (Split-Path $IcoPath) | Out-Null
        New-IcoFromPng -Png $pngIcon -Ico $IcoPath
        $iconOk = $true
    } catch {
        Write-Warning "Could not build the custom icon ($($_.Exception.Message)); using the default."
    }
}

# --no-prompt unless the dialog is wanted (default: show the "Download from Blackboard?" dialog).
$arguments = if ($NoPrompt) { '-m bbdash --no-prompt' } else { '-m bbdash' }

$ws = New-Object -ComObject WScript.Shell
$lnk = $ws.CreateShortcut($LnkPath)
$lnk.TargetPath = $pyw
$lnk.Arguments = $arguments
$lnk.WorkingDirectory = $ProjectDir
$lnk.Description = 'Download Blackboard submissions and open the morning dashboard'
$lnk.WindowStyle = 7  # minimized (pythonw shows nothing anyway; belt and suspenders)
if ($iconOk) { $lnk.IconLocation = "$IcoPath,0" }
$lnk.Save()

Write-Host "Created Start Menu shortcut:"
Write-Host "    $LnkPath"
Write-Host "    -> $pyw $arguments"
Write-Host "    (working dir: $ProjectDir)"
if ($iconOk) { Write-Host "    icon: $IcoPath" }
Write-Host "`nFind it by pressing Start and typing '$Name'. Remove it with:"
Write-Host "    powershell -ExecutionPolicy Bypass -File install\windows\install_shortcut.ps1 -Remove"
