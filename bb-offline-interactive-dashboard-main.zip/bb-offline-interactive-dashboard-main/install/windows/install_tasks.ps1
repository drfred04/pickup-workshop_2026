#Requires -Version 5.1
<#
.SYNOPSIS
    Register Windows Task Scheduler jobs for the BB Offline Dashboard morning run and the
    "open file" companion. This is the Windows equivalent of the macOS launchd agents
    in install/launchagents/.

.DESCRIPTION
    Creates two per-user tasks under the \BBReport\ folder in Task Scheduler. Both run as
    the CURRENT user in the INTERACTIVE session, so the "Download from Blackboard?" dialog and the
    browser can actually appear on your desktop (a background/session-0 task cannot show UI):

      * MorningReport - runs at logon AND daily at -Time. If the PC was off or asleep at the
                        scheduled time, it wakes the machine and runs the missed job as soon
                        as it can (StartWhenAvailable + WakeToRun) -- the same "runs when it
                        next wakes" behavior the macOS launchd agent gives you.
      * Opener        - the localhost 127.0.0.1 "open file" companion. Starts at logon and is
                        restarted if it ever exits. Skip it with -SkipOpener (then the report
                        falls back to plain file:// links, or set "opener_port": 0 in config).

    No administrator rights are required: these are per-user tasks that run only as you.
    Task output is logged to %USERPROFILE%\.bbdash\task_dashboard.log and task_opener.log.

.PARAMETER Time
    Daily run time for the morning dashboard as 24-hour "HH:mm". Default "06:00".

.PARAMETER NoPrompt
    Run the dashboard fully unattended (skip the "Download from Blackboard?" dialog). Without this, the
    dialog appears and auto-runs after 5 minutes if you don't answer.

.PARAMETER SkipOpener
    Do not install the opener companion task.

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File install\windows\install_tasks.ps1

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File install\windows\install_tasks.ps1 -Time 07:30 -NoPrompt

.NOTES
    Remove everything with install\windows\uninstall_tasks.ps1.
#>
[CmdletBinding()]
param(
    [string]$Time = "06:00",
    [switch]$NoPrompt,
    [switch]$SkipOpener
)

$ErrorActionPreference = 'Stop'

# install\windows\install_tasks.ps1 -> project root is two levels up from this folder.
$ProjectDir = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$RunReport  = Join-Path $ProjectDir 'install\run.ps1'
$RunOpener  = Join-Path $ProjectDir 'install\run_opener.ps1'
$LogDir     = Join-Path $env:USERPROFILE '.bbdash'
$TaskFolder = '\BBReport\'

if (-not (Test-Path $RunReport)) { throw "Cannot find $RunReport" }
if ((-not $SkipOpener) -and (-not (Test-Path $RunOpener))) { throw "Cannot find $RunOpener" }
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null

# Validate -Time and turn it into a [datetime] for the daily trigger.
try {
    $at = [datetime]::ParseExact($Time, 'HH:mm', [System.Globalization.CultureInfo]::InvariantCulture)
} catch {
    throw "-Time must be 24-hour HH:mm, e.g. 06:00 or 07:30. Got '$Time'."
}

$user = "$env:USERDOMAIN\$env:USERNAME"

function Register-BBTask {
    param($Name, $Action, $Trigger, $Settings, $Description)
    $principal = New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Limited
    $task = New-ScheduledTask -Action $Action -Trigger $Trigger -Settings $Settings `
        -Principal $principal -Description $Description
    Register-ScheduledTask -TaskName $Name -TaskPath $TaskFolder -InputObject $task -Force | Out-Null
    Write-Host "  Registered $TaskFolder$Name"
}

Write-Host "Installing BBReport scheduled tasks (user: $user, project: $ProjectDir)"

# --- Morning report task ---------------------------------------------------------------
# Pass --no-prompt (the bbdash CLI flag) through run.ps1 to python when -NoPrompt is set.
$reportPass = if ($NoPrompt) { ' --no-prompt' } else { '' }
$dashboardLog  = Join-Path $LogDir 'task_dashboard.log'
# Set BBREPORT_LOG so run.ps1 logs to a file Task Scheduler doesn't capture on its own.
$reportInner = "`$env:BBREPORT_LOG='$dashboardLog'; & '$RunReport'$reportPass"
$reportAction = New-ScheduledTaskAction -Execute 'powershell.exe' `
    -Argument "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command `"$reportInner`""

$reportTrigger = @(
    (New-ScheduledTaskTrigger -AtLogOn -User $user),
    (New-ScheduledTaskTrigger -Daily -At $at)
)
$reportSettings = New-ScheduledTaskSettingsSet `
    -StartWhenAvailable `
    -WakeToRun `
    -AllowStartIfOnBatteries `
    -DontStopIfGoingOnBatteries `
    -ExecutionTimeLimit (New-TimeSpan -Hours 1) `
    -MultipleInstances IgnoreNew

Register-BBTask -Name 'MorningReport' -Action $reportAction -Trigger $reportTrigger `
    -Settings $reportSettings `
    -Description 'Blackboard morning submission report: download submissions, build the HTML report, and open it.'

# --- Opener companion task -------------------------------------------------------------
if (-not $SkipOpener) {
    $openerLog = Join-Path $LogDir 'task_opener.log'
    $openerInner = "`$env:BBREPORT_LOG='$openerLog'; & '$RunOpener'"
    $openerAction = New-ScheduledTaskAction -Execute 'powershell.exe' `
        -Argument "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command `"$openerInner`""
    $openerTrigger = New-ScheduledTaskTrigger -AtLogOn -User $user
    # ExecutionTimeLimit 0 = run indefinitely (it's a long-lived server); restart if it dies.
    $openerSettings = New-ScheduledTaskSettingsSet `
        -AllowStartIfOnBatteries `
        -DontStopIfGoingOnBatteries `
        -ExecutionTimeLimit (New-TimeSpan -Seconds 0) `
        -RestartCount 3 `
        -RestartInterval (New-TimeSpan -Minutes 1) `
        -MultipleInstances IgnoreNew
    Register-BBTask -Name 'Opener' -Action $openerAction -Trigger $openerTrigger `
        -Settings $openerSettings `
        -Description 'Blackboard report "open file" companion: a localhost 127.0.0.1 server that opens report file links in their app.'
}

Write-Host ""
Write-Host "Done. Review or edit these in Task Scheduler under Task Scheduler Library \ BBReport."
Write-Host "Test the report now without waiting for the schedule:"
Write-Host "    Start-ScheduledTask -TaskPath '$TaskFolder' -TaskName 'MorningReport'"
if (-not $SkipOpener) {
    Write-Host "The opener starts at your next logon; start it now with:"
    Write-Host "    Start-ScheduledTask -TaskPath '$TaskFolder' -TaskName 'Opener'"
}
Write-Host "Logs: $LogDir\task_dashboard.log  and  task_opener.log"
