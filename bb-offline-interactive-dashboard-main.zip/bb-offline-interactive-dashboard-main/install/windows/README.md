# Windows scheduling (Task Scheduler)

The Windows equivalent of the macOS `launchd` agents in `../launchagents/`. These scripts
register two per-user scheduled tasks so the morning dashboard runs automatically and the
"open file" companion stays running — the same behavior faculty get on a Mac.

Everything here runs as **you**, in **your** interactive desktop session (so the "Download
now?" dialog and the browser can actually appear), and needs **no administrator rights**.

## Prerequisites

1. Python 3 installed (from [python.org](https://www.python.org/downloads/)).
2. Dependencies installed — a project virtualenv is recommended:
   ```powershell
   cd C:\path\to\bb-offline-interactive-dashboard
   python -m venv .venv
   .\.venv\Scripts\python.exe -m pip install -r requirements.txt
   ```
   (The run scripts auto-detect `.venv\Scripts\python.exe`; if there's no venv they fall back
   to whatever `python` is on your PATH.)
3. Your credentials configured once: `python install\setup_config.py`.

## Install the scheduled tasks

From the project root, in PowerShell:

```powershell
powershell -ExecutionPolicy Bypass -File install\windows\install_tasks.ps1
```

Options:

| Flag | Effect |
|---|---|
| `-Time 07:30` | Daily run time, 24-hour `HH:mm` (default `06:00`). |
| `-NoPrompt` | Run the dashboard fully unattended (no "Download from Blackboard?" dialog). |
| `-SkipOpener` | Don't install the opener companion task. |

Example: `... install_tasks.ps1 -Time 07:15 -NoPrompt`

This creates two tasks under **Task Scheduler Library → BBReport**:

- **MorningReport** — runs at logon *and* daily at your chosen time. If the PC was off or
  asleep at that time, it wakes the machine and runs the missed job as soon as it can
  (`StartWhenAvailable` + `WakeToRun`) — the same "runs when it next wakes" behavior the macOS
  agent gives you.
- **Opener** — the localhost `127.0.0.1` "open file" companion. Starts at logon and is
  restarted if it ever exits. (Skip with `-SkipOpener`, or set `"opener_port": 0` in your
  config, and the dashboard falls back to plain `file://` links.)

## Run now / manage / logs

```powershell
# Run the dashboard immediately (don't wait for the schedule):
Start-ScheduledTask -TaskPath '\BBReport\' -TaskName 'MorningReport'

# Start the opener now (otherwise it starts at your next logon):
Start-ScheduledTask -TaskPath '\BBReport\' -TaskName 'Opener'
```

Output is logged (the Windows equivalent of launchd's `.out`/`.err` files) to:

- `%USERPROFILE%\.bbdash\task_dashboard.log` / `task_dashboard.err.log`
- `%USERPROFILE%\.bbdash\task_opener.log` / `task_opener.err.log`

## Uninstall

```powershell
powershell -ExecutionPolicy Bypass -File install\windows\uninstall_tasks.ps1
```

Removes both tasks and the `\BBReport\` folder from Task Scheduler. A currently-running
opener may keep its `python.exe` alive until you log off; end it in Task Manager if you need
port 8765 freed right away.

## One-click Start Menu shortcut

For a click-to-run launcher (the Windows counterpart of the macOS Dock app):

```powershell
powershell -ExecutionPolicy Bypass -File install\windows\install_shortcut.ps1
```

Adds **"BB Offline Dashboard"** to your Start Menu. It runs `python -m bbdash` via the venv's
windowless `pythonw.exe` (no console window), shows the "Download from Blackboard?" dialog, then builds and
opens the dashboard. It's branded with `bbdash/icon.png` (resized to a 256×256 `.ico` in
`~/.bbdash/icon.ico`).

| Flag | Effect |
|---|---|
| `-NoPrompt` | Run immediately, skipping the "Download from Blackboard?" dialog. |
| `-Name "Label"` | Use a different Start Menu label. |
| `-Remove` | Remove the shortcut and its generated icon. |

Per-user, no admin rights needed.

## Running by hand (no scheduling)

You don't need Task Scheduler at all — the run scripts work directly:

```powershell
.\install\run.ps1                 # download + build + open the dashboard (with the dialog)
.\install\run.ps1 --no-prompt     # ...without the dialog
.\install\run.ps1 --check         # validate config + auth + list courses, download nothing
.\install\run_opener.ps1          # run the "open file" companion in this window
```
