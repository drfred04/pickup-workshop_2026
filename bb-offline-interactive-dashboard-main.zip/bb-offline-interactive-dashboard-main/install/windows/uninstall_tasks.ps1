#Requires -Version 5.1
<#
.SYNOPSIS
    Remove the BBReport Windows Task Scheduler jobs created by install_tasks.ps1.
.EXAMPLE
    powershell -ExecutionPolicy Bypass -File install\windows\uninstall_tasks.ps1
#>
[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$TaskFolder = '\BBReport\'

foreach ($name in 'MorningReport', 'Opener') {
    $existing = Get-ScheduledTask -TaskPath $TaskFolder -TaskName $name -ErrorAction SilentlyContinue
    if ($existing) {
        # Stop a running instance first (harmless if it isn't running). Note: the long-lived
        # opener's python child may keep running until you log off; end python.exe in Task
        # Manager if you need port 8765 freed immediately.
        Stop-ScheduledTask -TaskPath $TaskFolder -TaskName $name -ErrorAction SilentlyContinue | Out-Null
        Unregister-ScheduledTask -TaskPath $TaskFolder -TaskName $name -Confirm:$false
        Write-Host "Removed $TaskFolder$name"
    } else {
        Write-Host "Not found (already removed): $TaskFolder$name"
    }
}

# Remove the now-empty \BBReport\ folder from the Task Scheduler library (best effort).
try {
    $svc = New-Object -ComObject 'Schedule.Service'
    $svc.Connect()
    $svc.GetFolder('\').DeleteFolder('BBReport', 0)
    Write-Host "Removed task folder $TaskFolder"
} catch {
    # Folder missing or not empty -> nothing to do.
}
