# Wrapper that Task Scheduler (or you) can call to produce the morning dashboard.
# Lives in install/; the project root is this script's parent directory.
# Windows equivalent of run.sh. Any arguments are passed straight through to
# `python -m bbdash` (e.g.  .\install\run.ps1 --no-prompt --dry-run).
$ErrorActionPreference = 'Stop'

$ProjectDir = Split-Path -Parent $PSScriptRoot
Set-Location $ProjectDir

# Prefer the project virtualenv; fall back to whatever `python`/`python3` is on PATH.
$venvPy = Join-Path $ProjectDir '.venv\Scripts\python.exe'
if (Test-Path $venvPy) {
    $py = $venvPy
} else {
    $cmd = Get-Command python -ErrorAction SilentlyContinue
    if (-not $cmd) { $cmd = Get-Command python3 -ErrorAction SilentlyContinue }
    if (-not $cmd) {
        throw "No Python found. Create the venv (python -m venv .venv) or install Python from python.org."
    }
    $py = $cmd.Source
}

# When launched by the scheduled task, BBREPORT_LOG names a stdout log file; stderr goes to a
# sibling ".err" file (the two-file model launchd uses on macOS). Start-Process captures the
# child's raw output cleanly, unlike PowerShell stream redirection, which wraps native stderr
# in noisy error records. Run manually with no BBREPORT_LOG and output goes to the console.
if ($env:BBREPORT_LOG) {
    $outLog = $env:BBREPORT_LOG
    $errLog = Join-Path (Split-Path $outLog -Parent) `
        ("{0}.err{1}" -f [IO.Path]::GetFileNameWithoutExtension($outLog), [IO.Path]::GetExtension($outLog))
    $p = Start-Process -FilePath $py -ArgumentList (@('-m', 'bbdash') + $args) `
        -NoNewWindow -Wait -PassThru -RedirectStandardOutput $outLog -RedirectStandardError $errLog
    exit $p.ExitCode
} else {
    & $py -m bbdash @args
    exit $LASTEXITCODE
}
