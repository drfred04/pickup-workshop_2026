#!/bin/bash
# Wrapper that runs the "open file" companion server (keeps running in the background).
# Lives in install/; PROJECT_DIR is this script's parent (the project root).
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_DIR"

if [ -x "$PROJECT_DIR/.venv/bin/python" ]; then
  PY="$PROJECT_DIR/.venv/bin/python"
else
  PY="$(command -v python3)"
fi

exec "$PY" -m bbdash.opener
