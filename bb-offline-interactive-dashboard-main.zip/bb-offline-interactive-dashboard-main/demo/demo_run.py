#!/usr/bin/env python3
"""Self-contained DEMO of the BB Offline Dashboard for showing colleagues.

Generates a synthetic set of courses — NO real Blackboard data — then runs the real pipeline:
the 2-button dialog, the download of the "new" submissions, and the morning dashboard opened in
Safari. Three fictional courses; only ONE has an assignment due last night (Homework 11, with
files: .py, its comment-stripped copy, and a .png plot). The other two courses show only past
submissions, so they populate the status grids at the bottom (a realistic multi-course view).
Each course's "Online Gradebook" button points at a real course so it works in the demo.

Run:  python3 demo/demo_run.py   (or click the "BB Offline Dashboard (Demo)" app in the Dock)
"""
from __future__ import annotations

import base64
import datetime
import io
import re
import shutil
import sys
from pathlib import Path

# This script lives in demo/, so put the project root (its parent) on the path to import bbdash.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from bbdash import main as M
from bbdash.config import Config
from bbdash.state import State
from bbdash.util import sanitize, sha256_file

_now = datetime.datetime.now(datetime.timezone.utc)


def _iso(dt):
    return dt.strftime("%Y-%m-%dT%H:%M:%S.000Z")


# (uid, family, given, username)
STUDENTS = [
    ("_s01", "Adams", "Amy", "aadams"), ("_s02", "Brown", "Ben", "bbrown"),
    ("_s03", "Carter", "Cara", "ccarter"), ("_s04", "Davis", "Dan", "ddavis"),
    ("_s05", "Evans", "Erin", "eevans"), ("_s06", "Frank", "Fred", "ffrank"),
    ("_s07", "Garcia", "Gina", "ggarcia"), ("_s08", "Harris", "Hank", "hharris"),
    ("_s09", "Ito", "Iris", "iito"), ("_s10", "Jones", "Jack", "jjones"),
]

# Real course pk1 ids so each "Online Gradebook" button opens a working gradebook.
# "new": True gives the course a Homework <past+1> due last night; others are past-only.
COURSES = [
    {"id": "_21575_1", "name": "DEMO - PHYS 220 Computational Methods", "code": "DEMO-220",
     "past": 10, "new": True},
    {"id": "_21555_1", "name": "DEMO - PHYS 401 Quantum Mechanics", "code": "DEMO-401",
     "past": 6, "new": False},
    {"id": "_21591_1", "name": "DEMO - PHYS 406 Adv Computational Phys", "code": "DEMO-406",
     "past": 5, "new": False},
]

_NEW_DUE = _iso((_now - datetime.timedelta(days=1)).replace(hour=23, minute=59))
_NEW_ONTIME = _iso((_now - datetime.timedelta(days=1)).replace(hour=20, minute=0))
_NEW_LATE = _iso(_now.replace(hour=6, minute=0))

_DEMO_PY = (
    "#!/usr/bin/env python3\n"
    "# Homework 11 - projectile range\n"
    "import math\n\n"
    "G = 9.81  # gravitational acceleration (m/s^2)\n\n"
    "def projectile_range(v0, angle_deg):\n"
    '    """Return the horizontal range of a projectile launched over flat ground."""\n'
    "    angle = math.radians(angle_deg)          # convert to radians\n"
    "    return v0 ** 2 * math.sin(2 * angle) / G  # range formula\n\n"
    'print("Range:", projectile_range(20, 45), "meters")\n'
)
_FALLBACK_PNG = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==")
_PLOT_CACHE = None


def _past_due(i):
    return _iso((_now - datetime.timedelta(days=(12 - i))).replace(hour=23, minute=59))


def _plot_png_bytes() -> bytes:
    """A real matplotlib plot PNG (generated once, then cached). Falls back to a tiny PNG."""
    global _PLOT_CACHE
    if _PLOT_CACHE is not None:
        return _PLOT_CACHE
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        import numpy as np
        fig, ax = plt.subplots(figsize=(4.6, 3.2))
        x = np.linspace(0, 4 * np.pi, 300)
        ax.plot(x, np.sin(x), label="sin(x)")
        ax.plot(x, np.sin(x) * np.exp(-x / 10), label="damped")
        ax.set_title("Homework 11 - demo plot")
        ax.set_xlabel("x")
        ax.set_ylabel("amplitude")
        ax.legend()
        ax.grid(True, alpha=0.3)
        buf = io.BytesIO()
        fig.savefig(buf, format="png", dpi=110, bbox_inches="tight")
        plt.close(fig)
        _PLOT_CACHE = buf.getvalue()
    except Exception:
        _PLOT_CACHE = _FALLBACK_PNG
    return _PLOT_CACHE


def _course_by_id(cid):
    for c in COURSES:
        if c["id"] == cid:
            return c
    return None


class FakeClient:
    def get(self, path, params=None):
        m = re.match(r"/learn/api/public/v1/courses/([^/]+)$", path)
        if m:
            c = _course_by_id(m.group(1))
            if c:
                return {"id": c["id"], "name": c["name"], "courseId": c["code"]}
        if path.startswith("/learn/api/public/v1/users/"):
            uid = path.rsplit("/", 1)[1]
            for u, fam, giv, un in STUDENTS:
                if u == uid:
                    return {"name": {"family": fam, "given": giv}, "userName": un,
                            "contact": {"email": f"{un}@g.fmarion.edu"}}
            return {"name": {}, "userName": uid}
        return None

    def get_all(self, path, params=None):
        if path.endswith("/users/userName:demo/courses"):
            return [{"courseId": c["id"], "courseRoleId": "Instructor"} for c in COURSES]
        m = re.match(r"/learn/api/public/v2/courses/([^/]+)/gradebook/columns$", path)
        if m:
            return self._columns(m.group(1))
        if re.match(r"/learn/api/public/v1/courses/[^/]+/users$", path):
            return [{"userId": u, "courseRoleId": "Student"} for u, _, _, _ in STUDENTS]
        m = re.match(r"/learn/api/public/v2/courses/[^/]+/gradebook/columns/([^/]+)/attempts$", path)
        if m:
            return self._attempts(m.group(1))
        m = re.match(r"/learn/api/public/v1/courses/[^/]+/gradebook/attempts/([^/]+)/files$", path)
        if m:
            return self._files(m.group(1))
        return []

    def _columns(self, cid):
        c = _course_by_id(cid)
        cols = [{"id": f"{cid}_c{i}", "name": f"Homework {i}",
                 "grading": {"type": "Attempts", "due": _past_due(i)}}
                for i in range(1, c["past"] + 1)]
        if c["new"]:
            cols.append({"id": f"{cid}_cNEW", "name": f"Homework {c['past'] + 1}",
                         "grading": {"type": "Attempts", "due": _NEW_DUE}})
        return cols

    def _attempts(self, col):
        out = []
        if col.endswith("_cNEW"):
            for idx, (u, _, _, _) in enumerate(STUDENTS):
                if idx in (6, 9):
                    continue                        # two missing (X): Gina Garcia + Jack Jones
                if idx == 7:
                    # Hank Harris: TWO attempts — the .py on time, then the .png after the
                    # deadline. This shows the per-file on-time (✓) / late (L) split within one
                    # student's submission (his overall status stays on-time).
                    out.append({"id": f"attNEW_{col}_{u}_pyontime", "userId": u,
                                "status": "NeedsGrading",
                                "attemptReceipt": {"submissionDate": _NEW_ONTIME}})
                    out.append({"id": f"attNEW_{col}_{u}_pnglate", "userId": u,
                                "status": "NeedsGrading",
                                "attemptReceipt": {"submissionDate": _NEW_LATE}})
                    continue
                ts = _NEW_LATE if idx == 8 else _NEW_ONTIME    # Ito late; rest on time
                out.append({"id": f"attNEW_{col}_{u}", "userId": u, "status": "NeedsGrading",
                            "attemptReceipt": {"submissionDate": ts}})
        else:
            i = int(col.split("_c")[-1])
            for idx, (u, _, _, _) in enumerate(STUDENTS):
                if idx == 9 and i in (3, 7):
                    continue                        # a couple of historical misses for realism
                hh = 6 if (idx == 2 and i == 5) else 20   # student 3 late on HW5
                ts = _iso((_now - datetime.timedelta(days=(12 - i))).replace(hour=hh, minute=0))
                out.append({"id": f"att_{col}_{u}", "userId": u, "status": "NeedsGrading",
                            "attemptReceipt": {"submissionDate": ts}})
        return out

    def _files(self, aid):
        # The new assignment showcases a code file + a plot. Past assignments each carry a code
        # file too, so you can demo clicking the file links on any assignment's page.
        if aid.startswith("attNEW_"):
            if aid.endswith("_pyontime"):
                return [{"id": aid + "_py", "name": "hw11.py"}]     # Harris's on-time code file
            if aid.endswith("_pnglate"):
                return [{"id": aid + "_png", "name": "plot.png"}]   # Harris's late plot
            return [{"id": aid + "_py", "name": "hw11.py"},
                    {"id": aid + "_png", "name": "plot.png"}]
        if aid.startswith("att_"):
            m = re.search(r"_c(\d+)_", aid)            # pull the homework number from the column id
            n = m.group(1) if m else "x"
            return [{"id": aid + "_py", "name": f"hw{n}.py"}]
        return []

    def download_to(self, path, dest):
        # ``path`` is the download endpoint (contains the fake file id, e.g. ..._png/download);
        # the temp ``dest`` name is id-based, so decide the content from the endpoint.
        p = Path(dest)
        if "_png/" in path:
            p.write_bytes(_plot_png_bytes())
        else:
            p.write_text(_DEMO_PY)
        # (sha, real_filename): no Content-Disposition in the demo -> None, so the
        # pipeline falls back to the listing's (good) name — same as classic Learn.
        return sha256_file(p), None

    def get_avatar(self, user_id):
        # Demo never contacts Blackboard. About 25% of the fictional students have a stock
        # headshot (bundled in demo_assets/faces, so this stays offline); the rest fall back
        # to colored initials. These are stock faces, not real students.
        face = Path(__file__).resolve().parent / "faces" / f"{user_id}.jpg"
        if face.exists():
            return (face.read_bytes(), "image/jpeg")
        return None


def build_config() -> Config:
    real = Path.home() / ".bbdash"
    demo = Path.home() / ".bbdash_demo"
    demo.mkdir(parents=True, exist_ok=True)
    if (real / "opener.token").exists():
        shutil.copy(real / "opener.token", demo / "opener.token")
    return Config(
        domain="fmarion.blackboard.com", application_key="x", application_secret="x",
        instructor_username="demo",
        # Keep the demo fully under ~/.bbdash_demo so it never touches the real output folder
        # (submissions AND the dashboard now live under output_dir).
        output_dir=demo / "BB Offline Dashboard",
        data_dir=demo,
        opener_port=8765,
        dialog_icon=str(real / "dialog_icon.png"),
        launch_prompt=True,
    )


def seed_state(config: Config):
    """Mark every PAST assignment (all courses) as already handled on prior days, so only the
    NEW assignment shows as 'new' / 'just came due'. Also wipes the demo course folders so each
    run downloads fresh (files show as new)."""
    for c in COURSES:
        shutil.rmtree(config.output_dir / sanitize(c["name"]), ignore_errors=True)
    (config.data_dir / "state.json").unlink(missing_ok=True)
    # Wipe the cached avatars so each demo reflects the current set of stock faces.
    shutil.rmtree(config.data_dir / "avatars", ignore_errors=True)
    st = State(config.state_path)
    for c in COURSES:
        for i in range(1, c["past"] + 1):
            col = f"{c['id']}_c{i}"
            st.assignment(col)["due_report_done"] = True
            st.assignment(col)["due"] = _past_due(i)
            for idx, (u, _, _, _) in enumerate(STUDENTS):
                if idx == 9 and i in (3, 7):
                    continue
                st.attempt(f"att_{col}_{u}")["downloaded"] = True
    st.save()


def run_demo():
    config = build_config()
    seed_state(config)
    if M.prompt_launch(config) == "run":
        M.run(config, open_dashboard=True, client=FakeClient())
    else:
        print("Demo: you clicked 'Not Now' (in a real morning, you'd run it later).")


if __name__ == "__main__":
    run_demo()
