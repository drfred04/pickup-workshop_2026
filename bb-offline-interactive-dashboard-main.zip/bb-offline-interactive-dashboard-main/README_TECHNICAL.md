# Offline Interactive Dashboard & Downloader for Blackboard

A daily, automated tool that downloads new Blackboard assignment submissions for all
your courses and produces a morning summary dashboard — who submitted, who's missing, who was
late. Built on the official Blackboard REST API with OAuth 2.0 (no browser automation, no
cookie scraping).

See [docs/DESIGN_NOTES.md](docs/DESIGN_NOTES.md) for the full design and the verified
API details.

> **Status:** live and validated end‑to‑end against FMU's Blackboard (`fmarion.blackboard.com`),
> and extended to Windows. Use `--check` to confirm config + auth + course discovery at any time.

---

## What it does each run

1. Finds the courses you teach and their assignments (with due dates).
2. Downloads any **new** submission files + text submissions (skips unchanged ones; keeps
   both copies when a file actually changed).
3. For Python submissions (`.py`/`.pyw` files **and** the code cells of `.ipynb`
   notebooks), also writes a `_nocomments` copy with all `#` comments stripped (using
   `tokenize`, so a `#` inside a string is never touched) and docstrings removed (via the
   AST; configurable with `strip_docstrings`). Shebang lines are kept and the original is
   always preserved verbatim.
4. Sorts files into `~/BB Offline Dashboard/<Course>/<Assignment>/LastName_FirstName_username_<file>`.
5. Updates a per-course `submission_status.csv` matrix (see below).
6. Writes an interactive HTML dashboard to
   `~/BB Offline Dashboard/Dashboard/YYYY-MM-DD__HH-MM.html` — one timestamped snapshot per run, so
   re-running the same day doesn't overwrite an earlier dashboard — and opens it automatically.
   Each snapshot carries **Previous** / **Next** links (top corners) to step through the history;
   set `keep_previous_dashboards: false` to keep only the latest instead.

Before it runs, a 2-button dialog (with your icon) asks **Run Now** or **Not Now**. "Not Now"
skips today — you can run it later with `python3 -m bbdash --no-prompt` (or a Dock app that
runs the same command). Disable the dialog entirely with `launch_prompt: false`.

### The HTML dashboard (interactive)

The status grid shows a green **✓** (on time), **L** (late), or red **✕** (missing). It's
clickable:
- click a **✓** or **L** to open a detail page for that one student + assignment in a new tab;
- click an **assignment heading** (e.g. "Homework 1") to open that assignment's full roster (in
  the same tab, with a "← Back to the dashboard" link at the top) — a row per student with
  their status, submission time, and file links, plus the red **✕** + nudge email for anyone who
  hasn't submitted;
- click a **student's name** to focus the whole dashboard on just that student (with a "Show
  all students" link to return);
- click a red **✕** to draft a nudge email about the missing work.

At the top, a **New Submissions** line summarizes the night as three clickable counts —
`N on time · N late · N missing` — that jump to the matching section. The two daily tables are
**one row per student** and disjoint: **New on time submissions** lists students who submitted on
time; **New late submissions** lists students who were entirely late. Each file in a row carries
its own marker — a green **✓** (on time) or an orange **L** (late) — and a late file also shows
the time it arrived, so a student who turned most work in on time but slipped one file in late
stays in the on-time table with just that file flagged. Filenames are shown without the
`Last_First_username_` prefix that they carry on disk. Files a student attached *inline* in the
submission body (e.g. a ZIP) are downloaded and listed alongside regular attempt files.

After Missing, an **All students** overview lists every enrolled student per course, with the row
tinted by their status on that course's **most-recently-due** assignment: **red** = not submitted,
**orange** = late, plain = on time. It complements the detailed status grid further down.

In **Missing — assignments that just came due**, the red **✕** appears twice: after each
student's name (drafts that student's personalized nudge), and after the count in the
**# Missing** column (opens a *separate*, personalized draft for **each** missing student —
one email per student, each greeting that student by name, not one mass email). The
per-student column works with any mail setup; the **# Missing** ✕ needs the "open file"
companion (below), which opens each draft for you.

Each student is shown with their **photo** — the real Blackboard photo where one exists,
otherwise a colored initials badge. Photos are cached under `~/.bbdash/avatars` and
embedded directly in the dashboard; nothing is uploaded anywhere. Because the dashboard then
contains student photos (FERPA-protected), keep dashboard files to yourself. Turn photos off
with `"student_photos": false`.

Two things you can do with a photo (both need the "open file" companion below):
- **Click a photo** to open it full-size in your default image viewer (Preview).
- **Drag an image file from Finder onto a thumbnail** (a photo *or* an initials badge) to set
  that student's photo. It appears immediately and is saved to `~/.bbdash/avatars`, so every
  future dashboard uses it. This is the easy way to fill in students Blackboard has no photo for.
  (A manually imported photo always wins — it's never overwritten by Blackboard's "no photo".)

### Status spreadsheet (`<Course>/submission_status.csv`)

Rewritten each run. First two columns are **Last Name** and **First Name**; each remaining
column is an assignment. Each cell:

| Cell | Meaning |
|------|---------|
| *(blank)* | Submitted on time (or assignment not yet due) |
| `L` | Submitted late |
| `X` | Not submitted and the due date has passed |

(The green-check/on-time distinction is shown in the HTML dashboard; the CSV keeps on-time
blank as above.)

**Reporting cadence**
- **Daily:** new submissions, newly-arrived late submissions, and missing students for
  assignments that just came due.
- **Weekly** (configurable weekday): still-outstanding missing submissions for older
  assignments — so you aren't nagged daily.

---

## Setup

```bash
cd /Users/larryengelhardt/.gemini/antigravity/scratch/bb-offline-interactive-dashboard

# 1. Create a virtualenv and install dependencies.
#    On Apple Silicon, build it from a NATIVE (arm64) Python (see the note below);
#    macOS's built-in python works well:
/usr/bin/python3 -m venv .venv
.venv/bin/pip install -r requirements.txt

# 2. Create your private config from the template
mkdir -p ~/.bbdash
cp config.example.json ~/.bbdash/config.json
chmod 600 ~/.bbdash/config.json
#    ...then edit ~/.bbdash/config.json and fill in:
#      - domain               (FMU's Blackboard hostname)
#      - application_key       (from developer.blackboard.com)
#      - application_secret    (keep private!)
#      - instructor_username   (your Blackboard username)

# 3. Verify everything once credentials are live
.venv/bin/python -m bbdash --check
```

`--check` confirms the config loads, authenticates (gets a token), and lists the courses
it found — without downloading anything.

> **Apple Silicon (M-series): use a native (arm64) Python.** If the venv is built from an
> *Intel* Python (e.g. an Intel Anaconda build), the tool runs through Rosetta 2, and recent
> macOS shows a **"Support Ending for Intel-based Apps"** warning — Apple is phasing Rosetta out.
> Build the venv from an arm64 Python instead: the simplest is macOS's built-in `/usr/bin/python3`
> (shown above); Homebrew (`brew install python`), the python.org universal2 installer, or
> miniforge also work. Verify with
> `.venv/bin/python -c "import platform; print(platform.machine())"` → it should print `arm64`
> (not `x86_64`). Because the run scripts and the Dock apps use this `.venv`, doing this once
> makes the whole tool — dashboard, companion, and 6 AM agent — run natively.
> *(The `urllib3<2` pin in `requirements.txt` also keeps the built-in Python quiet about its
> older LibreSSL; harmless either way.)*

---

## Usage

```bash
python -m bbdash            # full run: download + dashboard + open it
python -m bbdash --dry-run  # analyze + build dashboard, but download nothing / don't save state
python -m bbdash --no-open  # don't auto-open the dashboard
python -m bbdash --check    # validate config + auth + list courses, then exit
python -m bbdash --config /path/to/other-config.json

python -m bbdash --gradebook           # open a launcher page (buttons per course) in Safari
python -m bbdash --gradebook PHYS-220   # jump straight to one course's gradebook
```

The `--gradebook` shortcut just navigates you around Blackboard; it does not download
anything. The launcher page (`~/BB Offline Dashboard/Dashboard/course_shortcuts.html`) gives each course two
buttons: **Gradebook** (one click from **Download → Work Offline with Grade Data**) and
**Course Content** (jumps to the course's content outline — handy for uploading class notes).
Bookmark the page, or drag a button to your Bookmarks Bar. If a link doesn't land in the right
place for your Ultra version, edit `gradebook_url_template` / `content_url_template` in your
config. The morning dashboard and this page **cross-link** each other (a "Course Shortcuts →" link
atop the dashboard, a "← Dashboard" link atop this page); each morning run refreshes this
page so both stay current.

Or via the wrapper: `./install/run.sh --dry-run`

---

## Tests

A small, dependency‑free (`unittest`, no pytest) regression suite lives in `tests/`. Run it from
the project root:

```bash
.venv/bin/python -m unittest discover -s tests
```

It covers the parts most likely to break silently: submission‑file **naming** (including the
Ultra "storage key vs. real filename" case that once produced extension‑less files),
`Content-Disposition` parsing, comment/docstring stripping for `.py` and `.ipynb`, the
missing‑work email wording, and that `config.example.json` stays in sync with the `Config`
dataclass. Add a test here whenever you touch downloading, naming, or code‑processing.

---

## Run automatically every morning (macOS launchd)

```bash
mkdir -p ~/.bbdash     # so launchd can write its logs
chmod +x install/run.sh
# In the plist, replace __PROJECT_DIR__ (this folder's absolute path) and __HOME__ (your
# home dir, e.g. /Users/yourname) — launchd needs absolute paths, it doesn't expand "~". Then:
cp install/launchagents/com.fmu.bbdash.plist ~/Library/LaunchAgents/
launchctl bootstrap gui/$(id -u) ~/Library/LaunchAgents/com.fmu.bbdash.plist
# (older macOS: launchctl load -w ~/Library/LaunchAgents/com.fmu.bbdash.plist)
```

The agent fires in **two** situations (either one covers a given day):

- **`RunAtLoad`** — when you genuinely log in or restart.
- **`StartCalendarInterval`** — daily at **6:00 AM**. Crucially, if the Mac is *asleep* at
  6:00, launchd runs the job the moment it next **wakes** — so it works even if you just
  unlock the machine in the morning (unlocking after sleep is *not* a login, so RunAtLoad
  alone would never fire in that case). Change the time by editing the `Hour`/`Minute` in
  the plist.

When it finishes, the HTML dashboard opens automatically in Safari (configurable via
`dashboard_browser`). Logs go to
`~/.bbdash/launchd.out` / `launchd.err`.

To stop it:

```bash
launchctl bootout gui/$(id -u)/com.fmu.bbdash
# (older macOS: launchctl unload ~/Library/LaunchAgents/com.fmu.bbdash.plist)
```

## Dock apps (one-click manual runs)

Two small apps live in `~/Applications` (drag them to the Dock once):

- **BB Offline Dashboard.app** — runs a real download + dashboard immediately (no dialog;
  clicking it *is* "run now"). Use this after answering "Not Now" in the morning.
- **BB Offline Dashboard (Demo).app** — runs `demo/demo_run.py`: an entirely fictional
  3-course demo (fake students/assignments, real-looking dashboard) for showing colleagues.
  Safe to run anytime; it never contacts Blackboard and rebuilds itself fresh on each run.

Both were built with `osacompile` and embed the current `python3` path — if the Python
install ever moves, rebuild them (one command; see project notes).

## "Open file" companion (clickable filenames that launch native apps)

The filenames in the dashboard are clickable. To make a click open the file in its **native app**
instead of just showing it in the browser, install the tiny companion — a local server
bound to `127.0.0.1` only, protected by a secret token, that only opens files under your
`output_dir`. Code files (`.py`, `.pyw`, `.ipynb`) open in **VS Code**; everything else
opens in its normal default app (both configurable via `code_editor_app` / `code_extensions`
and `dashboard_browser`):

```bash
chmod +x install/run_opener.sh
cp install/launchagents/com.fmu.bbdash-opener.plist ~/Library/LaunchAgents/
launchctl bootstrap gui/$(id -u) ~/Library/LaunchAgents/com.fmu.bbdash-opener.plist
```

It stays running in the background (`KeepAlive`). To stop it:

```bash
launchctl bootout gui/$(id -u)/com.fmu.bbdash-opener
```

If you update the code, restart the companion so it picks up the changes:

```bash
launchctl kickstart -k gui/$(id -u)/com.fmu.bbdash-opener
```

If you'd rather not run it, set `"opener_port": 0` in your config and skip this agent — the
dashboard then uses plain `file://` links (which the browser opens/downloads itself).

---

## Configuration reference (`~/.bbdash/config.json`)

The config accepts `//` line comments and `/* */` block comments (JSONC), so you can annotate
your settings; comment markers inside string values (e.g. a `https://` URL) are left untouched.

| Key | Meaning |
|---|---|
| `domain` | Your Blackboard hostname, e.g. `blackboard.fmarion.edu` |
| `application_key` | OAuth Application Key from developer.blackboard.com |
| `application_secret` | OAuth Application Secret — keep private (file is chmod 600) |
| `instructor_username` | Your Blackboard username; scopes discovery to courses you teach |
| `output_dir` | Where submissions are saved (default `~/BB Offline Dashboard`) |
| `data_dir` | Hidden folder for machine state: config, token cache, `state.json`, opener token, and the avatar cache (default `~/.bbdash`). The generated dashboard now lives under `output_dir/Dashboard/`, not here |
| `term_filter` | **Recommended** way to scope courses: a list of semester names (e.g. `["Fall 2026"]`), matched case-insensitively as a substring of each course's term. Empty = no term restriction |
| `course_filter` | Alternative scoping: a list of specific course IDs/codes. Empty = all you teach. If both filters are set, a course must satisfy both |
| `weekly_roundup_weekday` | Day the weekly outstanding-missing roundup runs. A day name (`"Monday"`/`"Mon"`, case-insensitive) or an int `0`=Mon … `6`=Sun |
| `missing_email_new` | Body of the nudge email for an assignment that **just came due**. Placeholders `{first_name}`, `{assignment}`, `{course_number}` are filled in per student |
| `missing_email_old` | Body of the nudge email for an **older, still-missing** assignment (same placeholders) |
| `opener_port` | Localhost port for the "open file" companion (default 8765); `0` disables it |
| `student_email_domain` | Used to show a student's email after their name when the API doesn't return one (default `g.fmarion.edu`) |
| `dashboard_browser` | macOS app to open the dashboard in (default `Safari` — handles the companion links most reliably); `""` uses your default browser |
| `keep_previous_dashboards` | Keep each run's timestamped snapshot (default `true`), enabling the Previous/Next links between them. `false` keeps only the latest — each run deletes the earlier dashboards and their detail/assignment pages |
| `code_editor_app` | macOS app that code files open in via the companion (default `Visual Studio Code`); `""` disables routing |
| `code_extensions` | Extensions routed to `code_editor_app` (default `.py`, `.pyw`, `.ipynb`); all other files open in their normal default app |
| `strip_docstrings` | In the `_nocomments` copy, also remove docstrings (module/class/function `"""documentation"""`). Default `true`; set `false` to keep them |
| `launch_prompt` | Show a 2-button "Download from Blackboard? / Not Now" dialog before each run. Default `true`; set `false` for fully unattended runs |
| `gradebook_url_template` | URL the `--gradebook`/"Gradebook" button opens. `{base}` = instance URL, `{course_id}` = pk1. Edit if your Ultra version's gradebook path differs |
| `content_url_template` | URL the "Course Content" button opens (same `{base}`/`{course_id}` substitutions) |
| `dialog_icon` | Path to a custom icon (`.png`) for the launch dialog. Empty auto-detects `~/.bbdash/dialog_icon.png` |
| `student_photos` | Show a student photo in the dashboard — the real Blackboard photo where available, otherwise a colored initials badge. Default `true`; set `false` to show no photos. Photos are cached locally in `data_dir/avatars` and embedded in the dashboard (nothing is uploaded) |

Credentials can also be supplied via environment variables (`BB_DOMAIN`,
`BB_APPLICATION_KEY`, `BB_APPLICATION_SECRET`, `BB_INSTRUCTOR_USERNAME`), which override the
config file.

---

## Note on the OAuth flow

This tool uses the **Client Credentials** flow (Key + Secret → token, no browser), which is
what allows unattended morning runs. If IT enabled only the interactive **Authorization
Code** flow, the auth step in `bbdash/auth.py` is the single place that would need
adapting — the rest of the code is unaffected.
