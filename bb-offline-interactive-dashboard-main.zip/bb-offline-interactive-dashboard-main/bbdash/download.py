"""Download a submitted attempt's files (and text submission) to disk.

Behavior (per the confirmed spec):
  - Files go to  <output_dir>/<Course>/<Assignment>/<Last_First_username>_<filename>
  - Identical file already on disk  -> skipped
  - A changed file (different hash)  -> saved alongside, never overwriting (keeps both)
  - Text / online-text submissions  -> saved as <Last_First_username>_submission_text.txt
"""
from __future__ import annotations

import hashlib
import os
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse

from .api import APIError, BlackboardClient
from .codeproc import ensure_stripped_copy, make_stripped_copy
from .discover import Course, NameInfo
from .state import State
from .submission import parse_submission
from .util import fs_path, sanitize, sha256_bytes, sha256_file


@dataclass
class SavedItem:
    filename: str
    skipped: bool = False
    changed_version: bool = False
    derived: bool = False  # a generated artifact (e.g. comment-stripped code copy)
    path: str = ""         # absolute path on disk (for building clickable links)


def _versioned(path: Path) -> Path:
    """Return a sibling path with a timestamp suffix, to keep a changed file's prior copy."""
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return path.with_name(f"{path.stem}__changed_{stamp}{path.suffix}")


def process_attempt(
    client: BlackboardClient,
    course: Course,
    assignment_name: str,
    attempt: dict,
    name: NameInfo,
    state: State,
    output_dir: Path,
    strip_docstrings: bool = False,
) -> list[SavedItem]:
    attempt_id = attempt["id"]
    att_state = state.attempt(attempt_id)
    file_hashes: dict = att_state["files"]
    saved: list[SavedItem] = []

    dest_dir = Path(output_dir) / course.label / sanitize(assignment_name)
    os.makedirs(fs_path(dest_dir), exist_ok=True)

    # Some attempts (Discussion/Reading and other tool-based columns) have no downloadable
    # files, and Blackboard's own files endpoint returns HTTP 500 for them
    # ("toolAttemptDetailProvider is null") rather than an empty list. Treat any failure to
    # list files as "no files": the attempt is still counted as submitted upstream, and any
    # text submission below is still saved. A genuinely transient error just means this run
    # downloads no file for the attempt; the next run retries (nothing is marked done).
    try:
        files = client.get_all(
            f"/learn/api/public/v1/courses/{course.id}/gradebook/attempts/{attempt_id}/files"
        )
    except APIError:
        files = []

    for fmeta in files:
        file_id = str(fmeta.get("id", "")).strip()
        if not file_id:
            # No downloadable file id (e.g. a video/media submission). There's nothing to
            # fetch — trying would build a malformed ".../files//download" URL and 404.
            # The attempt is still counted as submitted upstream; just skip the file.
            continue
        endpoint = (
            f"/learn/api/public/v1/courses/{course.id}/gradebook/attempts/"
            f"{attempt_id}/files/{file_id}/download"
        )
        # The listing's ``name`` is an internal storage key on Ultra (e.g. "16989750_1"), so it
        # is only a fallback hint — the real filename comes from the download response.
        _fetch_file(client, endpoint, dest_dir, name, state_key=file_id,
                    original_hint=fmeta.get("name"), file_hashes=file_hashes, saved=saved,
                    strip_docstrings=strip_docstrings)

    # A student can *attach a file inline* in their submission body (e.g. a ZIP). Ultra returns
    # those only as ``bbcswebdav`` links in the HTML, never via the files endpoint above — so
    # parse them out and download each as a real file.
    raw_text = attempt.get("studentSubmission") or ""
    attachments, body_text = parse_submission(raw_text)
    for att in attachments:
        # Key on the URL's stable path (the signed query string changes every run).
        state_key = "embed_" + hashlib.sha1(urlparse(att.url).path.encode("utf-8")).hexdigest()[:16]
        try:
            _fetch_file(client, att.url, dest_dir, name, state_key=state_key,
                        original_hint=att.name, file_hashes=file_hashes, saved=saved,
                        strip_docstrings=strip_docstrings)
        except APIError:
            # A single inaccessible attachment shouldn't abort the attempt; nothing is marked
            # done for it, so the next run retries.
            continue

    # Typed / online-text submission: save the PLAIN text (tags stripped, attachment links
    # removed) only when meaningful prose remains — so a submission that is *only* an attached
    # file no longer leaves a noise ``_submission_text.txt`` full of HTML.
    if body_text:
        text_hash = sha256_bytes(raw_text.encode("utf-8"))
        if att_state.get("text_sha") != text_hash:
            text_path = dest_dir / sanitize(f"{name.label}_submission_text.txt")
            if os.path.exists(fs_path(text_path)) and att_state.get("text_sha") is not None:
                text_path = _versioned(text_path)
            with open(fs_path(text_path), "w", encoding="utf-8") as f:
                f.write(body_text)
            att_state["text_sha"] = text_hash
            saved.append(SavedItem(filename=text_path.name, path=str(text_path)))

    return saved


def _fetch_file(
    client: BlackboardClient,
    url: str,
    dest_dir: Path,
    name: NameInfo,
    *,
    state_key: str,
    original_hint,
    file_hashes: dict,
    saved: list,
    strip_docstrings: bool,
) -> None:
    """Download one file (attempt file or embedded attachment) to ``dest_dir`` and record it.

    Downloads first to a temp file, because only the response reveals the ORIGINAL filename;
    the final on-disk name is ``<Last_First_username>_<original>``. Identical existing file ->
    skipped (but its ``_nocomments`` copy is ensured); a changed file is kept alongside the old.
    """
    tmp = dest_dir / (sanitize(f"dl_{state_key}") + ".part")
    new_hash, real_name = client.download_to(url, tmp)
    original = real_name or original_hint or f"file_{state_key}"
    final = dest_dir / sanitize(f"{name.label}_{original}")

    # Already have an identical copy at the target name? Skip the download itself, but make sure
    # the comment-stripped copy exists (e.g. added in a later version).
    if os.path.exists(fs_path(final)) and sha256_file(final) == new_hash:
        _remove(tmp)
        file_hashes[state_key] = new_hash
        saved.append(SavedItem(filename=final.name, skipped=True, path=str(final)))
        stripped = ensure_stripped_copy(final, strip_docstrings=strip_docstrings)
        if stripped is not None:
            saved.append(SavedItem(filename=stripped.name, derived=True, path=str(stripped)))
        return

    # Target name exists but content differs -> keep both.
    changed = False
    if os.path.exists(fs_path(final)):
        final = _versioned(final)
        changed = True

    os.replace(fs_path(tmp), fs_path(final))
    file_hashes[state_key] = new_hash
    saved.append(SavedItem(filename=final.name, changed_version=changed, path=str(final)))

    # For Python submissions, also write a comment-stripped copy alongside.
    stripped = make_stripped_copy(final, strip_docstrings=strip_docstrings)
    if stripped is not None:
        saved.append(SavedItem(filename=stripped.name, derived=True,
                               changed_version=changed, path=str(stripped)))


def _remove(path: Path) -> None:
    """Delete a file if it exists (long-path safe), ignoring 'already gone'."""
    try:
        os.remove(fs_path(path))
    except FileNotFoundError:
        pass
