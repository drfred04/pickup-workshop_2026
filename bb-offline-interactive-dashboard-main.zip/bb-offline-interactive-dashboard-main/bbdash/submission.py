"""Parse a Blackboard Ultra text/online submission body.

Ultra stores a student's typed submission as HTML in ``studentSubmission``. When a student
*attaches a file inline* (e.g. a ZIP), the file does NOT come back from the attempt-files
endpoint — it appears only as an anchor in this HTML, e.g.::

    <p><a href="https://.../bbcswebdav/.../embedded/Thermo_HW7.zip?..."
          data-bbtype="attachment"
          data-bbfile="{&quot;fileName&quot;:&quot;Thermo_HW7.zip&quot;,
                        &quot;resourceUrl&quot;:&quot;https://.../Thermo_HW7.zip?...&quot;, ...}">
       Thermo_HW7.zip</a></p>

``parse_submission`` pulls those out so the downloader can fetch them as real files, and also
returns the *plain text* of the body with the attachment anchors removed — so a submission that
is nothing but an attachment yields empty text (no noise ``_submission_text.txt``), while a
submission with real prose still yields that prose.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from html.parser import HTMLParser
from urllib.parse import unquote, urlparse


@dataclass
class Attachment:
    name: str      # original filename (may be "" if unknown -> caller derives from URL)
    url: str       # absolute download URL (bbcswebdav resourceUrl / href)
    mime: str = ""


class _SubmissionParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.attachments: list[Attachment] = []
        self._text: list[str] = []
        self._skip_anchor_depth = 0  # >0 while inside an attachment <a> (its text is the filename)

    def handle_starttag(self, tag, attrs):
        if tag != "a":
            return
        d = {k: (v or "") for k, v in attrs}
        href = d.get("href", "")
        is_attach = d.get("data-bbtype") == "attachment" or "data-bbfile" in d \
            or "/bbcswebdav/" in href
        if not is_attach:
            return
        meta = {}
        raw = d.get("data-bbfile", "")
        if raw:
            try:
                meta = json.loads(raw)  # HTMLParser has already decoded the &quot; entities
            except (ValueError, TypeError):
                meta = {}
        url = (meta.get("resourceUrl") or href or "").strip()
        name = (meta.get("fileName") or meta.get("displayName")
                or meta.get("linkName") or meta.get("alternativeText") or "").strip()
        if url:
            self.attachments.append(Attachment(name=name, url=url,
                                               mime=(meta.get("mimeType") or "").strip()))
        self._skip_anchor_depth += 1

    def handle_endtag(self, tag):
        if tag == "a" and self._skip_anchor_depth > 0:
            self._skip_anchor_depth -= 1

    def handle_data(self, data):
        if self._skip_anchor_depth == 0:
            self._text.append(data)

    def text(self) -> str:
        return re.sub(r"\s+", " ", "".join(self._text)).strip()


def filename_from_url(url: str) -> str:
    """Best-effort original filename from a bbcswebdav URL's path (query stripped)."""
    try:
        base = unquote(urlparse(url).path.rsplit("/", 1)[-1]).strip()
        return base or "attachment"
    except (ValueError, AttributeError):
        return "attachment"


def parse_submission(html: str) -> tuple[list[Attachment], str]:
    """Return (embedded attachments, plain-text body with attachment anchors removed).

    A non-HTML string (a plain typed answer with no tags) is returned unchanged as the text,
    with no attachments.
    """
    if not html:
        return [], ""
    if "<" not in html:                      # plain text, not HTML
        return [], html.strip()
    p = _SubmissionParser()
    try:
        p.feed(html)
        p.close()
    except Exception:                        # noqa: BLE001 - malformed HTML must not kill a run
        # Fall back to a crude tag strip so we still capture any text.
        return [], re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", html)).strip()
    for a in p.attachments:
        if not a.name:
            a.name = filename_from_url(a.url)
    return p.attachments, p.text()
