"""Open a course's Blackboard Ultra gradebook in the browser — one click from Download.

This does NOT automate or download anything. It just navigates you straight to the
gradebook page so you're one click from "Download → Work Offline with Grade Data",
instead of clicking through the course each time.

  python -m bbdash --gradebook            # launcher page with a button per course
  python -m bbdash --gradebook PHYS-220   # open one course's gradebook directly
"""
from __future__ import annotations

import html
import sys
from pathlib import Path

from . import discover
from . import osutil
from .api import BlackboardClient


def _e(s: str) -> str:
    return html.escape(str(s))


def _course_label(c) -> str:
    return c.name or c.code or c.id


def gradebook_url(config, course) -> str:
    return config.gradebook_url_template.format(base=config.base_url, course_id=course.id)


def content_url(config, course) -> str:
    return config.content_url_template.format(base=config.base_url, course_id=course.id)


def _open_target(config, target: str) -> None:
    """Open a URL or file path in the configured browser (Safari by default)."""
    osutil.open_in_app(target, config.dashboard_browser)


def _latest_dashboard_href(config) -> str:
    """Relative href (same folder — the shortcuts page lives beside the dashboards) to the most
    recent submission dashboard, or '' if none."""
    try:
        # Date-named YYYY-MM-DD.html; exclude course_shortcuts.html which shares this folder.
        dashboards = sorted(p for p in config.dashboard_dir.glob("*.html")
                            if p.name != "course_shortcuts.html")
        if dashboards:
            return dashboards[-1].name
    except OSError:
        pass
    return ""


def build_launcher(config, courses, dashboard_href: str = "") -> Path:
    """Write a small HTML page with, per course, a 'Gradebook' and a 'Course Content' button.
    ``dashboard_href`` (relative to this page, which lives in the Dashboard folder) links back to
    the submission dashboard; if omitted, the most recent dashboard is used."""
    dashboard_href = dashboard_href or _latest_dashboard_href(config)
    back = (f"<p class='backlink'><a href='{_e(dashboard_href)}'>&larr; Dashboard</a></p>"
            if dashboard_href else "")
    cards = []
    for c in sorted(courses, key=lambda x: _course_label(x).lower()):
        gb = gradebook_url(config, c)
        content = content_url(config, c)
        cards.append(
            "<div class='card'>"
            f"<span class='name'>{_e(_course_label(c))}</span>"
            f"<span class='code'>{_e(c.code or '')}</span>"
            "<div class='btns'>"
            f"<a class='btn gb' href='{_e(gb)}' target='_blank'>Gradebook</a>"
            f"<a class='btn content' href='{_e(content)}' target='_blank'>Course Content</a>"
            "</div></div>"
        )
    doc = (
        "<!doctype html><html lang='en'><head><meta charset='utf-8'>"
        "<meta name='viewport' content='width=device-width, initial-scale=1'>"
        "<title>Course Shortcuts</title><style>"
        "body{font-family:-apple-system,system-ui,sans-serif;margin:2rem;color:#1a1a1a;}"
        "h1{font-size:1.4rem;} p.sub{color:#555;margin-top:0;}"
        ".grid{display:flex;flex-wrap:wrap;gap:.75rem;margin-top:1rem;}"
        ".card{display:flex;flex-direction:column;min-width:15rem;padding:1rem 1.25rem;"
        "border:1px solid #d0d7de;border-radius:8px;background:#f6f8fa;}"
        ".card .name{font-weight:600;} .card .code{color:#666;font-size:.85rem;margin-top:.25rem;}"
        ".btns{display:flex;gap:.5rem;margin-top:.75rem;}"
        ".btn{flex:1;text-align:center;padding:.45rem .6rem;border-radius:7px;text-decoration:none;"
        "font-weight:600;font-size:.9rem;color:#fff;}"
        ".btn.gb{background:#2e7d32;} .btn.gb:hover{background:#1b5e20;}"
        ".btn.content{background:#0a58ca;} .btn.content:hover{background:#0942a0;}"
        ".backlink{margin:0 0 1rem;} .backlink a{color:#0a58ca;text-decoration:none;font-weight:600;}"
        ".backlink a:hover{text-decoration:underline;}"
        "</style></head><body>"
        + back +
        "<h1>Course Shortcuts</h1>"
        "<p class='sub'><b>Gradebook</b> jumps to the course's gradebook (then use "
        "<b>Download → Work Offline with Grade Data</b>).<br>"
        "<b>Course Content</b> jumps to the course's content outline (handy for uploading "
        "class notes).<br>"
        "Bookmark this page (or drag a button to your Bookmarks Bar).</p>"
        "<div class='grid'>" + "".join(cards) + "</div></body></html>"
    )
    out = config.dashboard_dir / "course_shortcuts.html"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(doc, encoding="utf-8")
    return out


def run_gradebook(config, arg: str) -> int:
    client = BlackboardClient(config)
    try:
        courses = discover.list_instructor_courses(client, config)
    except Exception as e:  # noqa: BLE001
        print(f"Could not list courses: {e}", file=sys.stderr)
        return 1
    if not courses:
        print("No courses found (check instructor_username / course_filter).", file=sys.stderr)
        return 1

    if arg == "__ALL__":
        out = build_launcher(config, courses)
        print(f"Gradebook launcher written to: {out}")
        for c in sorted(courses, key=lambda x: _course_label(x).lower()):
            print(f"  {_course_label(c)}\n    {gradebook_url(config, c)}")
        _open_target(config, out.resolve().as_uri())
        return 0

    q = arg.lower()
    matches = [c for c in courses
               if q in (c.code or "").lower() or q in (c.name or "").lower()]
    if not matches:
        print(f"No course matched '{arg}'. Run --gradebook (no value) to see them all.",
              file=sys.stderr)
        return 1
    if len(matches) > 1:
        print(f"'{arg}' matched multiple courses — be more specific:", file=sys.stderr)
        for c in matches:
            print(f"  {c.code}: {c.name}", file=sys.stderr)
        return 1
    c = matches[0]
    url = gradebook_url(config, c)
    print(f"Opening gradebook for {_course_label(c)}:\n  {url}")
    _open_target(config, url)
    return 0
