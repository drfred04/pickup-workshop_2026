"""Small shared helpers: filesystem-safe names, hashing, date parsing."""
from __future__ import annotations

import hashlib
import os
import re
from datetime import datetime, timezone
from pathlib import Path


def fs_path(p) -> str:
    """A path string safe for very long (>260-char) paths on Windows.

    Windows' legacy MAX_PATH (260) limit makes ``open()``/``os`` calls fail on deep submission
    paths (e.g. ``BB Offline Dashboard/LongCourse/LongAssignment/Last_First_user_longfile_nocomments.py``).
    Prefixing an *absolute* path with the extended-length marker (``\\\\?\\``) lifts that limit.
    Use this only at the point of a filesystem call (open, os.replace, os.makedirs); never store
    it, display it, or build dashboard links from it. No-op on macOS/Linux.
    """
    s = os.fspath(p)
    if os.name != "nt":
        return s
    abspath = os.path.abspath(s)
    if abspath.startswith("\\\\?\\"):
        return abspath
    if abspath.startswith("\\\\"):          # UNC share \\server\share -> \\?\UNC\server\share
        return "\\\\?\\UNC\\" + abspath[2:]
    return "\\\\?\\" + abspath


def sanitize(name: str, max_len: int = 150) -> str:
    """Make an arbitrary string safe to use as a single path component."""
    name = (name or "").strip()
    # Replace anything that isn't a word char, dot, dash, or space.
    name = re.sub(r"[^\w.\- ]", "_", name, flags=re.UNICODE)
    name = re.sub(r"\s+", " ", name).strip()
    name = name.strip(". ")  # avoid trailing dots/spaces (Windows-hostile, also tidy)
    return name[:max_len] or "unnamed"


def parse_dt(value: str | None) -> datetime | None:
    """Parse a Blackboard ISO-8601 timestamp (e.g. '2023-09-08T15:35:05.817Z')."""
    if not value:
        return None
    try:
        s = value
        if s.endswith("Z"):
            s = s[:-1] + "+00:00"
        dt = datetime.fromisoformat(s)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except ValueError:
        return None


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(fs_path(path), "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def now_utc() -> datetime:
    return datetime.now(timezone.utc)
