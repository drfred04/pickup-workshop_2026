"""Tiny localhost companion that opens files in their native macOS app.

The morning dashboard links to ``http://127.0.0.1:<port>/open?path=<file>&token=<t>``. Clicking
a filename makes your browser call this local server, which runs the macOS ``open`` command
so the file launches in its normal application (your editor, Numbers, Preview, ...).

Run it continuously in the background via the ``com.fmu.bbdash-opener`` launchd agent, or
manually with:  ``python -m bbdash.opener``

It also accepts student photos dragged onto a thumbnail in the dashboard:
``POST http://127.0.0.1:<port>/avatar?token=<t>&uid=<id>&ext=<jpg|png|gif>`` with the image
bytes as the body saves the photo into ``<data_dir>/avatars`` so the next dashboard embeds it.

Safety:
  - binds to 127.0.0.1 only (never reachable from the network);
  - requires a secret token, shared through a 0600 file in your data dir, so a random web
    page you visit can't drive it;
  - only opens files located under your configured ``output_dir`` (or the avatars cache);
  - only writes image files, into the avatars cache, with a sanitized filename.
"""
from __future__ import annotations

import json
import os
import secrets
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from . import osutil
from .config import Config, load_config
from .util import sanitize

MAX_AVATAR_BYTES = 8 * 1024 * 1024          # reject anything larger than 8 MB
AVATAR_EXTS = {"jpg", "jpeg", "png", "gif"}  # image types we accept for a dropped photo


def get_or_create_token(config: Config) -> str:
    """Return the shared opener token, creating a random one (0600) if needed."""
    path = config.opener_token_path
    if path.exists():
        try:
            tok = path.read_text().strip()
            if tok:
                return tok
        except OSError:
            pass
    path.parent.mkdir(parents=True, exist_ok=True)
    tok = secrets.token_urlsafe(24)
    path.write_text(tok)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass
    return tok


def _is_within(root: Path, target: Path) -> bool:
    try:
        root_r = root.resolve()
        target_r = target.resolve()
    except OSError:
        return False
    return target_r == root_r or root_r in target_r.parents


def make_handler(config: Config, token: str):
    output_root = Path(config.output_dir)
    avatars_root = Path(config.data_dir) / "avatars"  # where dropped photos are saved
    # Files we're allowed to OPEN: submissions, plus cached avatars, plus the whole demo tree
    # (~/.bbdash_demo holds the demo's submissions, dashboard, and avatars) so the demo's file
    # links and thumbnails work through the one running companion.
    open_roots = [output_root, avatars_root, Path.home() / ".bbdash_demo"]
    code_app = config.code_editor_app
    # Normalize to a set of lowercase extensions with a leading dot.
    code_exts = {("." + e.lstrip(".")).lower() for e in config.code_extensions}

    def open_file(target: Path) -> None:
        """Open in the code editor for code extensions, else the default app.
        Falls back to the default app if the editor can't be launched."""
        app = code_app if (code_app and target.suffix.lower() in code_exts) else ""
        osutil.open_in_app(target, app)

    class Handler(BaseHTTPRequestHandler):
        def _reply(self, code: int, body: bytes = b"", ctype: str = "text/plain; charset=utf-8"):
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            # The dashboard is a local file:// page (origin "null"); allow it to call us.
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")
            self.end_headers()
            if body:
                self.wfile.write(body)

        def do_OPTIONS(self):  # noqa: N802 - CORS preflight for the /avatar POST
            self._reply(204)

        def do_GET(self):  # noqa: N802 (http.server API)
            parsed = urlparse(self.path)
            if parsed.path == "/mail":
                self._handle_mail(parse_qs(parsed.query))
                return
            if parsed.path != "/open":
                self._reply(404, b"not found")
                return
            qs = parse_qs(parsed.query)
            if qs.get("token", [""])[0] != token:
                self._reply(403, b"bad token")
                return
            raw = qs.get("path", [""])[0]
            if not raw:
                self._reply(400, b"missing path")
                return
            target = Path(raw)
            if not any(_is_within(root, target) for root in open_roots):
                self._reply(403, b"path not allowed")
                return
            if not target.exists():
                self._reply(404, b"file not found")
                return
            try:
                open_file(target)
            except OSError as e:
                self._reply(500, f"open failed: {e}".encode())
                return
            self._reply(
                200,
                b"<!doctype html><meta charset=utf-8>"
                b"<script>window.close()</script>Opened \xe2\x80\x94 you can close this tab.",
                "text/html; charset=utf-8",
            )

        def _handle_mail(self, qs):
            """Open a single pre-filled mail draft (``open "mailto:..."``). The dashboard calls this
            once per student so each missing student gets their own personalized email."""
            if qs.get("token", [""])[0] != token:
                self._reply(403, b"bad token")
                return
            url = qs.get("url", [""])[0]
            if not url.startswith("mailto:"):
                self._reply(400, b"not a mailto url")
                return
            osutil.open_mail(url)
            self._reply(200, b"ok")

        def do_POST(self):  # noqa: N802 - save a photo dragged onto a dashboard thumbnail
            parsed = urlparse(self.path)
            if parsed.path != "/avatar":
                self._reply(404, b"not found")
                return
            qs = parse_qs(parsed.query)
            if qs.get("token", [""])[0] != token:
                self._reply(403, b"bad token")
                return
            uid = qs.get("uid", [""])[0].strip()
            ext = qs.get("ext", [""])[0].strip().lower().lstrip(".")
            if not uid:
                self._reply(400, b"missing uid")
                return
            if ext not in AVATAR_EXTS:
                self._reply(415, b"unsupported image type")
                return
            try:
                length = int(self.headers.get("Content-Length", "0"))
            except ValueError:
                length = 0
            if length <= 0 or length > MAX_AVATAR_BYTES:
                self._reply(413, b"bad image size")
                return
            body = self.rfile.read(length)
            key = sanitize(uid)
            try:
                avatars_root.mkdir(parents=True, exist_ok=True)
                # Remove any previous photo variants + the "no photo" marker so the new one wins.
                for stale in ("jpg", "jpeg", "png", "gif", "none"):
                    p = avatars_root / f"{key}.{stale}"
                    if p.exists():
                        p.unlink()
                dest = avatars_root / f"{key}.{ext}"
                dest.write_bytes(body)
            except OSError as e:
                self._reply(500, f"save failed: {e}".encode())
                return
            self._reply(200, json.dumps({"path": str(dest.resolve())}).encode(),
                        "application/json; charset=utf-8")

        def log_message(self, *args):  # keep the launchd log quiet
            pass

    return Handler


def serve(config: Config) -> None:
    token = get_or_create_token(config)
    handler = make_handler(config, token)
    server = HTTPServer(("127.0.0.1", config.opener_port), handler)
    print(
        f"bbdash opener listening on http://127.0.0.1:{config.opener_port} "
        f"(root: {config.output_dir})"
    )
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass


def main(argv=None) -> int:
    osutil.enable_utf8_console()
    try:
        # The companion never contacts Blackboard, so it does not need the API credentials.
        # This lets it run before you've filled in your Application Key/Secret.
        config = load_config(require_credentials=False)
    except Exception as e:  # noqa: BLE001 - surface any config failure plainly
        print(f"opener: config error: {e}", file=sys.stderr)
        return 1
    if config.opener_port <= 0:
        print("opener disabled (opener_port <= 0)")
        return 0
    serve(config)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
