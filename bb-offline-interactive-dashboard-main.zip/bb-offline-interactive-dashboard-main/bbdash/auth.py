"""OAuth 2.0 authentication for the Blackboard REST API.

Default flow: **Client Credentials** (two-legged) — the Application Key + Secret are
exchanged directly for a Bearer token, with no browser login. This is what makes
unattended, run-at-login automation possible.

If your institution only enables the Authorization Code flow (interactive faculty
login), this module is the seam where that alternative would be implemented; the rest
of the codebase only depends on ``TokenManager.get_token()``.
"""
from __future__ import annotations

import base64
import json
import os
import stat
import time

import requests

from .config import Config

TOKEN_ENDPOINT = "/learn/api/public/v1/oauth2/token"
# Refresh a bit before actual expiry to avoid racing the clock.
EXPIRY_SKEW_SECONDS = 60


class AuthError(Exception):
    pass


class TokenManager:
    def __init__(self, config: Config, session: requests.Session | None = None):
        self.config = config
        self.session = session or requests.Session()
        self._token: str | None = None
        self._expires_at: float = 0.0
        self._load_cache()

    def get_token(self) -> str:
        if self._token and time.time() < self._expires_at - EXPIRY_SKEW_SECONDS:
            return self._token
        return self._request_token()

    def invalidate(self) -> None:
        """Force a refresh on the next get_token() (e.g. after a 401)."""
        self._token = None
        self._expires_at = 0.0

    def _request_token(self) -> str:
        creds = f"{self.config.application_key}:{self.config.application_secret}"
        basic = base64.b64encode(creds.encode("utf-8")).decode("ascii")
        try:
            resp = self.session.post(
                self.config.base_url + TOKEN_ENDPOINT,
                headers={
                    "Authorization": f"Basic {basic}",
                    "Content-Type": "application/x-www-form-urlencoded",
                },
                data={"grant_type": "client_credentials"},
                timeout=30,
            )
        except requests.RequestException as e:
            raise AuthError(f"Could not reach token endpoint: {e}") from e

        if resp.status_code != 200:
            raise AuthError(
                f"Token request failed (HTTP {resp.status_code}): {resp.text[:300]}\n"
                "Check that IT has registered the integration on this instance and that "
                "the Application Key/Secret are correct."
            )

        data = resp.json()
        token = data.get("access_token")
        if not token:
            raise AuthError(f"Token response missing access_token: {data}")
        self._token = token
        self._expires_at = time.time() + int(data.get("expires_in", 3600))
        self._save_cache()
        return token

    # --- token cache (so back-to-back runs don't re-auth needlessly) ---
    def _load_cache(self) -> None:
        path = self.config.token_cache_path
        if not path.exists():
            return
        try:
            data = json.loads(path.read_text())
            self._token = data.get("access_token")
            self._expires_at = float(data.get("expires_at", 0))
        except (json.JSONDecodeError, OSError, ValueError):
            self._token = None
            self._expires_at = 0.0

    def _save_cache(self) -> None:
        path = self.config.token_cache_path
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps({"access_token": self._token, "expires_at": self._expires_at}))
        try:
            os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)  # 0600
        except OSError:
            pass
