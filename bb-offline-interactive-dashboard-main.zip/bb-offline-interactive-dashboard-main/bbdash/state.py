"""Persistent run-to-run state.

This is what lets the dashboard tell you about each event exactly once:
  - which attempts have already been downloaded,
  - which late arrivals have already been flagged,
  - which assignments have already had their initial "this came due" missing report,
  - file hashes (to skip unchanged files and keep changed ones), and
  - when the weekly outstanding-missing roundup last ran.
"""
from __future__ import annotations

import json
from pathlib import Path

STATE_VERSION = 1


class State:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.data: dict = {
            "version": STATE_VERSION,
            "last_run": None,
            "last_weekly_roundup": None,
            "attempts": {},      # attemptId -> {downloaded, late_reported, files: {fileId: sha256}, text_sha}
            "assignments": {},   # columnId  -> {due, due_report_done}
        }
        if self.path.exists():
            try:
                loaded = json.loads(self.path.read_text())
                if isinstance(loaded, dict):
                    self.data.update(loaded)
            except (json.JSONDecodeError, OSError):
                pass  # start fresh rather than crash on a corrupt state file

    # --- accessors that lazily create sub-records ---
    def attempt(self, attempt_id: str) -> dict:
        return self.data["attempts"].setdefault(
            attempt_id, {"downloaded": False, "late_reported": False, "files": {}, "text_sha": None}
        )

    def assignment(self, column_id: str) -> dict:
        return self.data["assignments"].setdefault(column_id, {"due": None, "due_report_done": False})

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(self.data, indent=2, sort_keys=True))
        tmp.replace(self.path)  # atomic on POSIX
