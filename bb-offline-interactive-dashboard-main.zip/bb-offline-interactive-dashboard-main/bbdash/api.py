"""Thin REST client over the Blackboard Learn public API.

Responsibilities:
  - attach the Bearer token to every request
  - transparently refresh the token once on a 401
  - retry with backoff on 429 / 5xx
  - follow ``paging.nextPage`` so callers always get the *complete* result set
  - stream file downloads to disk and return their SHA-256
"""
from __future__ import annotations

import hashlib
import os
import re
import time
from pathlib import Path
from urllib.parse import unquote, urlparse

import requests

from .auth import TokenManager
from .config import Config
from .util import fs_path

RETRY_STATUSES = {429, 500, 502, 503, 504}
MAX_ATTEMPTS = 5


class APIError(Exception):
    pass


class BlackboardClient:
    def __init__(
        self,
        config: Config,
        token_manager: TokenManager | None = None,
        session: requests.Session | None = None,
    ):
        self.config = config
        self.session = session or requests.Session()
        self.tokens = token_manager or TokenManager(config, self.session)

    def _auth_header(self) -> dict:
        return {"Authorization": f"Bearer {self.tokens.get_token()}"}

    def get(self, path: str, params: dict | None = None) -> dict | None:
        """GET a single resource/page. Returns parsed JSON, or None on 404."""
        url = self.config.base_url + path
        retried_auth = False
        for attempt in range(MAX_ATTEMPTS):
            resp = self.session.get(url, headers=self._auth_header(), params=params, timeout=60)

            if resp.status_code == 401 and not retried_auth:
                self.tokens.invalidate()
                retried_auth = True
                continue
            if resp.status_code == 404:
                return None
            if resp.status_code in RETRY_STATUSES:
                _backoff(attempt, resp)
                continue
            if not resp.ok:
                raise APIError(f"GET {path} failed (HTTP {resp.status_code}): {resp.text[:300]}")
            return resp.json()

        raise APIError(f"GET {path} failed after {MAX_ATTEMPTS} attempts")

    def get_all(self, path: str, params: dict | None = None) -> list[dict]:
        """GET every page of a paged collection and return the combined ``results``."""
        results: list[dict] = []
        params = dict(params or {})
        params.setdefault("limit", 100)

        next_path: str | None = path
        next_params: dict | None = params
        seen_pages = 0
        while next_path and seen_pages < 1000:  # hard stop guards against a paging loop
            data = self.get(next_path, params=next_params)
            seen_pages += 1
            if not data:
                break
            results.extend(data.get("results", []))
            paging = data.get("paging") or {}
            nxt = paging.get("nextPage")
            if nxt:
                next_path = nxt          # already a relative path including its query string
                next_params = None
            else:
                next_path = None
        return results

    def download_to(self, path: str, dest_path: Path) -> tuple:
        """Stream a file to ``dest_path``. Returns ``(sha256_hex, real_filename_or_None)``.

        The real filename comes from the response's ``Content-Disposition`` header (falling
        back to the final redirect URL's basename). This matters because Blackboard Ultra's
        attempt-files *listing* endpoint returns an internal storage key (e.g. "16989750_1")
        in its ``name`` field instead of the original filename — only the download response
        carries the true name (e.g. "Homework 3.ipynb").

        ``path`` may be an API-relative path or an absolute URL (used for ``bbcswebdav``
        attachment links embedded in a submission body)."""
        url = path if path.startswith(("http://", "https://")) else self.config.base_url + path
        dest_path = Path(dest_path)
        os.makedirs(fs_path(dest_path.parent), exist_ok=True)
        retried_auth = False
        while True:
            resp = self.session.get(url, headers=self._auth_header(), stream=True, timeout=180)
            if resp.status_code == 401 and not retried_auth:
                resp.close()
                self.tokens.invalidate()
                retried_auth = True
                continue
            if not resp.ok:
                resp.close()
                raise APIError(f"Download {path} failed (HTTP {resp.status_code})")
            real_name = _response_filename(resp)
            h = hashlib.sha256()
            with open(fs_path(dest_path), "wb") as f:
                for chunk in resp.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
                        h.update(chunk)
            return h.hexdigest(), real_name


    def get_avatar(self, user_id: str):
        """Return (image_bytes, content_type) for the user's real photo, or None if they use
        the default placeholder (an SVG served from '.../avatar/default_user')."""
        url = self.config.base_url + f"/learn/api/public/v1/users/{user_id}/avatar"
        try:
            r = self.session.get(url, headers=self._auth_header(), allow_redirects=True, timeout=30)
        except requests.RequestException:
            return None
        if not r.ok:
            return None
        ct = r.headers.get("Content-Type", "")
        if "default_user" in (r.url or "") or "svg" in ct or not ct.startswith("image/"):
            return None
        return (r.content, ct)


def _response_filename(resp: requests.Response):
    """Extract the original filename from a download response, or None.

    Preference order: RFC 5987 ``filename*=UTF-8''...`` (handles non-ASCII), then plain
    ``filename="..."``/``filename=token``, then the basename of the final (post-redirect) URL.
    """
    cd = resp.headers.get("Content-Disposition", "") or ""
    m = re.search(r"filename\*\s*=\s*[Uu][Tt][Ff]-8''([^;]+)", cd)
    if m:
        name = unquote(m.group(1)).strip().strip('"')
        if name:
            return name
    m = re.search(r'filename\s*=\s*"([^"]*)"', cd)
    if m and m.group(1).strip():
        return m.group(1).strip()
    m = re.search(r"filename\s*=\s*([^;]+)", cd)
    if m and m.group(1).strip().strip('"'):
        return m.group(1).strip().strip('"')
    try:
        name = unquote(urlparse(resp.url or "").path.rsplit("/", 1)[-1]).strip()
        return name or None
    except (ValueError, AttributeError):
        return None


def _backoff(attempt: int, resp: requests.Response) -> None:
    retry_after = resp.headers.get("Retry-After")
    if retry_after and retry_after.isdigit():
        time.sleep(min(int(retry_after), 30))
    else:
        time.sleep(min(2 ** attempt, 30))
