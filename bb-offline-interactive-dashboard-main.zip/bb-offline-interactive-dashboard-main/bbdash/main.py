"""Orchestrates a single morning run and opens the dashboard.

Usage:
    python -m bbdash                # prompt, then download + dashboard + open
    python -m bbdash --dry-run      # analyze + dashboard, download nothing, don't save state
    python -m bbdash --no-open      # don't auto-open the dashboard
    python -m bbdash --no-prompt    # skip the "run now / skip / wait" dialog
    python -m bbdash --check        # validate config + auth + list courses, then exit
    python -m bbdash --config PATH  # use a specific config file
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import re
import sys
import time
from datetime import datetime
from pathlib import Path
from urllib.parse import quote

from . import discover
from . import osutil
from .api import APIError, BlackboardClient
from .config import ConfigError, load_config
from .gradebook import gradebook_url
from .gradesheet import write_status_csv
from .dashboard import (
    AssignmentPage, AssignmentRow, Avatar, GridCell, MissingRow, DashboardData, RosterTable,
    StatusGrid, SubmissionDetail, SubmissionRow, render,
)
from .state import State
from .util import now_utc, parse_dt, sanitize


def run(config, dry_run: bool = False, open_dashboard: bool = True, client=None) -> Path:
    config.ensure_dirs()
    client = client or BlackboardClient(config)
    state = State(config.state_path)
    names = discover.NameResolver(client, email_domain=config.student_email_domain)
    today = now_utc()

    data = DashboardData(generated_at=datetime.now())
    if config.student_photos:
        data.avatars_dir = str((config.data_dir / "avatars").resolve())
    if config.opener_port and config.opener_port > 0:
        from .opener import get_or_create_token
        data.opener_prefix = f"http://127.0.0.1:{config.opener_port}/open?path="
        data.opener_token = get_or_create_token(config)
    pending_weekly: list[tuple] = []

    courses = discover.list_instructor_courses(client, config)
    if not courses:
        data.errors.append(
            "No courses found. If your token sees all courses, set 'instructor_username' "
            "in the config; otherwise verify IT granted course/membership read access."
        )

    for course in courses:
        try:
            assignments = discover.list_assignments(client, course.id)
            roster = discover.get_student_roster(client, course.id)
        except APIError as e:
            data.errors.append(f"{course.label}: {e}")
            continue

        # Accumulators for this course's status spreadsheet + grid.
        course_columns: list[tuple] = []                  # (col_id, name, due_dt)
        course_statuses: dict[tuple[str, str], str] = {}  # (uid, col_id) -> "OK"/"L"/"X"/""
        cell_detail: dict[tuple[str, str], str] = {}      # (uid, col_id) -> detail_id

        for col in assignments:
            col_id = col["id"]
            asg_name = discover.column_name(col)
            due = discover.column_due(col)
            due_dt = parse_dt(due)
            page_id = sanitize(f"a_{course.id}_{col_id}")   # this assignment's per-assignment page

            try:
                attempts = discover.get_attempts(client, course.id, col_id)
            except APIError as e:
                data.errors.append(f"{course.label} / {asg_name}: {e}")
                continue

            submitted_uids: set[str] = set()
            student_late: dict[str, bool] = {}  # uid -> late? (an on-time attempt wins)
            cell_info: dict[str, dict] = {}     # uid -> detail info (files/when/text)
            new_by_uid: dict[str, dict] = {}    # uid -> newly-downloaded files, merged per student
            for att in attempts:
                if not discover.is_submitted(att):
                    continue
                uid = att.get("userId")
                if uid:
                    submitted_uids.add(uid)
                attempt_id = att.get("id")
                if not attempt_id:
                    continue

                name = names.resolve(uid) if uid else discover.NameInfo("", "", "")
                att_state = state.attempt(attempt_id)
                sub_ts = discover.submission_timestamp(att)
                sub_dt = parse_dt(sub_ts)
                late = bool(due_dt and sub_dt and sub_dt > due_dt)
                # Display in the machine's local time (comparisons above stay in UTC).
                when = sub_dt.astimezone().strftime("%Y-%m-%d %H:%M") if sub_dt else "unknown"

                if uid:
                    prev = student_late.get(uid)
                    student_late[uid] = late if prev is None else (prev and late)

                # Download (skip-aware) unless this is a dry run. A failure on one student's
                # attempt (a flaky download, an over-long Windows path, an odd filename) must
                # NOT abort the whole run — log it and move on so the rest still downloads and
                # state is saved at the end.
                # File tuples are (display_name, abs_path, late, when): the display name drops the
                # "Last_First_username_" prefix used on disk; ``late``/``when`` are this attempt's
                # flag + submission time, so each file shows its own on-time/late marker (and, for
                # a late file, the time it arrived) in the dashboard.
                pfx = f"{name.label}_"
                saved_files: list[tuple[str, str, bool, str]] = []
                detail_files: list[tuple[str, str, bool, str]] = []
                if not dry_run:
                    from .download import process_attempt
                    try:
                        saved = process_attempt(
                            client, course, asg_name, att, name, state, config.output_dir,
                            strip_docstrings=config.strip_docstrings,
                        )
                        saved_files = [(_strip_prefix(s.filename, pfx), s.path, late, when)
                                       for s in saved if not s.skipped]
                        detail_files = [(_strip_prefix(s.filename, pfx), s.path, late, when)
                                        for s in saved if s.path]
                    except Exception as e:  # noqa: BLE001 - one bad attempt shouldn't kill the run
                        who = name.display or name.username or (uid or "unknown student")
                        data.errors.append(
                            f"{course.label} / {asg_name}: could not download "
                            f"{who}'s submission ({type(e).__name__}: {e})"
                        )

                # Detail info for this student+assignment. A student may submit SEVERAL times
                # in Ultra — each "Submit" is a separate attempt with its own file(s). Show the
                # UNION of files across all their attempts (deduped by path), while preferring an
                # on-time attempt for the displayed timestamp/text.
                if uid:
                    info = cell_info.get(uid)
                    if info is None:
                        info = {"when": when, "due": when_str(due_dt), "late": late,
                                "files": [], "text": att.get("studentSubmission") or "",
                                "_seen": set()}
                        cell_info[uid] = info
                    elif info["late"] and not late:
                        # This on-time attempt supersedes an earlier late one for the shown time.
                        info["when"] = when
                        info["late"] = late
                        info["text"] = att.get("studentSubmission") or info["text"]
                    for fn, pth, lt, wh in detail_files:
                        key = pth or fn
                        if key not in info["_seen"]:
                            info["_seen"].add(key)
                            info["files"].append((fn, pth, lt, wh))

                # Accumulate this attempt's NEW files under the student (reported once per attempt
                # via the "downloaded" flag). After the loop these merge into ONE row per student,
                # placed in the on-time or late table by overall status — so a student who
                # submitted on time but added a late file appears only in the on-time table, with
                # that file still flagged late (and carrying its own submission time).
                if not att_state.get("downloaded"):
                    if uid:
                        agg = new_by_uid.setdefault(
                            uid, {"files": [], "any_ontime": False, "ontime_when": "",
                                  "late_when": ""})
                        agg["files"].extend(saved_files)
                        if late:
                            agg["late_when"] = agg["late_when"] or when
                        else:
                            agg["any_ontime"] = True
                            agg["ontime_when"] = agg["ontime_when"] or when
                    else:
                        # No user id to group on -> keep a standalone row.
                        (data.new_late if late else data.new_submissions).append(
                            SubmissionRow(course=course.label, assignment=asg_name,
                                          student=name.display, student_key="", late=late,
                                          when=when, files=saved_files, page_id=page_id))
                    att_state["downloaded"] = True

            # Build one merged "new submission" row per student, placed by overall status:
            # on-time if they had any on-time attempt this run, otherwise late. Late files inside
            # an on-time row keep their own late flag + time, so no student appears in both tables.
            for uid_k, agg in new_by_uid.items():
                nm = names.resolve(uid_k)
                overall_late = not agg["any_ontime"]
                row = SubmissionRow(
                    course=course.label, assignment=asg_name, student=nm.display,
                    student_key=uid_k, late=overall_late,
                    when=(agg["ontime_when"] or agg["late_when"]),
                    files=agg["files"], page_id=page_id)
                (data.new_late if overall_late else data.new_submissions).append(row)

            # Record this assignment as a grid/CSV column; compute each cell + detail page.
            course_columns.append((col_id, asg_name, due_dt))
            due_passed = bool(due_dt and due_dt <= today)
            for uid in roster:
                if uid in student_late:
                    is_late = student_late[uid]
                    course_statuses[(uid, col_id)] = "L" if is_late else "OK"
                    nm = names.resolve(uid)
                    info = cell_info.get(uid, {"when": "unknown", "due": when_str(due_dt),
                                               "files": [], "text": ""})
                    detail_id = sanitize(f"d_{course.id}_{col_id}_{uid}")
                    av = _build_avatar(client, config, uid, nm, data.avatars) if config.student_photos else None
                    data.details.append(SubmissionDetail(
                        detail_id=detail_id, student=nm.display, email=nm.email,
                        course=course.label, assignment=asg_name, late=is_late,
                        when=info["when"], due=info["due"], files=info["files"], text=info["text"],
                        avatar=av))
                    cell_detail[(uid, col_id)] = detail_id
                else:
                    course_statuses[(uid, col_id)] = "X" if due_passed else ""

            # Missing analysis only makes sense once the due date has passed.
            if due_dt and due_dt <= today:
                missing_students = sorted(
                    ((names.resolve(u).display, u) for u in roster if u not in submitted_uids),
                    key=lambda t: t[0].lower(),
                )
                asg_state = state.assignment(col_id)
                asg_state["due"] = due
                if not asg_state.get("due_report_done"):
                    # Build the "email this student" / "email everyone missing" nudge links
                    # (same content as the ✕ in the status grid, for assignments just due).
                    course_num = _course_number(course)
                    student_mailtos: dict[str, str] = {}
                    group_emails: list[str] = []
                    for _disp, u in missing_students:
                        ni = names.resolve(u)
                        if ni.email:
                            student_mailtos[u] = _missing_mailto(
                                ni.email, ni.given or ni.display, asg_name, course_num,
                                config.missing_email_new)
                            group_emails.append(ni.email)
                    group_mailto = (_missing_mailto_group(group_emails, asg_name, course_num,
                                                          config.missing_email_new)
                                    if group_emails else "")
                    data.newly_due_missing.append(
                        MissingRow(course=course.label, assignment=asg_name,
                                   due=when_str(due_dt), students=missing_students,
                                   student_mailtos=student_mailtos, group_mailto=group_mailto,
                                   page_id=page_id)
                    )
                    asg_state["due_report_done"] = True
                elif missing_students:
                    pending_weekly.append((course, asg_name, when_str(due_dt), missing_students, page_id))

        # Write this course's submission-status spreadsheet + build its grid.
        if course_columns:
            students_sorted = sorted(
                ((uid, names.resolve(uid)) for uid in roster),
                key=lambda t: (t[1].family.lower(), t[1].given.lower(), t[1].username.lower()),
            )
            cols_sorted = sorted(
                course_columns,
                key=lambda c: (c[2] is None, c[2] or today, c[1].lower()),
            )
            csv_path = config.output_dir / course.label / "submission_status.csv"
            ordered_cols = [(cid, nm) for cid, nm, _ in cols_sorted]
            try:
                write_status_csv(csv_path, ordered_cols, students_sorted, course_statuses)
                csv_written = str(csv_path)
            except OSError as e:
                data.errors.append(f"{course.label}: could not write status CSV: {e}")
                csv_written = ""

            course_num = _course_number(course)
            due_by_col = {cid: ddt for cid, nm, ddt in cols_sorted}
            grid_rows = []
            for uid, info in students_sorted:
                if config.student_photos:
                    _build_avatar(client, config, uid, info, data.avatars)
                cells = []
                for cid, cname in ordered_cols:
                    status = course_statuses.get((uid, cid), "")
                    gc = GridCell(status=status, detail_id=cell_detail.get((uid, cid), ""))
                    # Every missing (X) student gets a clickable ✕ that drafts a nudge email;
                    # the wording differs for a just-due assignment vs an older one.
                    if status == "X" and info.email:
                        _tmpl = (config.missing_email_new
                                 if _due_recently(due_by_col.get(cid), today)
                                 else config.missing_email_old)
                        gc.mailto = _missing_mailto(
                            info.email, info.given or info.display, cname, course_num, _tmpl)
                    cells.append(gc)
                grid_rows.append((info.display, uid, cells))

            # All-students overview: every enrolled student, colored by their status on this
            # course's most-recently-due assignment (red = not submitted, orange = late).
            past_due = [(cid, cname, ddt) for cid, cname, ddt in cols_sorted if ddt and ddt <= today]
            if past_due:
                r_cid, r_cname, r_ddt = max(past_due, key=lambda c: c[2])
                r_rows = []
                for uid, info in students_sorted:
                    st = course_statuses.get((uid, r_cid), "")
                    css = {"X": "rowmiss", "L": "rowlate"}.get(st, "")
                    label = {"X": "Not submitted", "L": "Late", "OK": "On time"}.get(st, "—")
                    r_rows.append((info.display, uid, css, label))
                data.roster_tables.append(RosterTable(
                    course=course.label, assignment=r_cname, due=when_str(r_ddt), rows=r_rows))

            # Per-assignment roster pages (one per column): a row per student with files, status,
            # and — for a non-submitter past due — the same red ✕ + nudge email as the grid.
            gb_url = gradebook_url(config, course)
            detail_by_id = {d.detail_id: d for d in data.details}
            col_page_id: dict[str, str] = {}
            for cid, cname in ordered_cols:
                due_dt_c = due_by_col.get(cid)
                recent = _due_recently(due_dt_c, today)
                apage_rows = []
                for uid, info in students_sorted:
                    status = course_statuses.get((uid, cid), "")
                    did = cell_detail.get((uid, cid))
                    when_val, files_val, text_val, mailto = "", [], "", ""
                    d = detail_by_id.get(did) if did else None
                    if d is not None:
                        when_val, files_val, text_val = d.when, d.files, d.text
                    elif status == "X" and info.email:
                        mailto = _missing_mailto(
                            info.email, info.given or info.display, cname, course_num,
                            config.missing_email_new if recent else config.missing_email_old)
                    apage_rows.append(AssignmentRow(
                        student=info.display, student_key=uid, status=status,
                        when=when_val, files=files_val, mailto=mailto, text=text_val))
                page_id = sanitize(f"a_{course.id}_{cid}")
                col_page_id[cid] = page_id
                data.assignment_pages.append(AssignmentPage(
                    course=course.label, assignment=cname, due=when_str(due_dt_c),
                    page_id=page_id, rows=apage_rows, gradebook_url=gb_url))

            data.status_grids.append(
                StatusGrid(course=course.label, assignments=[nm for _, nm in ordered_cols],
                           rows=grid_rows, csv_path=csv_written, gradebook_url=gb_url,
                           assignment_ids=[col_page_id[cid] for cid, _ in ordered_cols])
            )

    # Weekly outstanding-missing roundup.
    if _should_run_weekly(state, config, today):
        data.include_weekly = True
        for course, asg_name, due_str, students, page_id in pending_weekly:
            data.weekly_outstanding.append(
                MissingRow(course=course.label, assignment=asg_name, due=due_str, students=students,
                           page_id=page_id)
            )
        state.data["last_weekly_roundup"] = today.isoformat()

    # Refresh the Course Shortcuts page (best-effort) so the dashboard can cross-link to it, and it
    # links back to today's dashboard. Uses the already-discovered courses (no extra API calls).
    if courses:
        try:
            from .gradebook import build_launcher
            from .dashboard import dashboard_stamp
            # The shortcuts page lives in the Dashboard folder next to this run's dashboard, so
            # the cross-links between them are same-folder (and use the same run stamp).
            build_launcher(config, courses, dashboard_href=f"{dashboard_stamp(data.generated_at)}.html")
            data.shortcuts_href = "course_shortcuts.html"
        except Exception:  # noqa: BLE001 - a shortcuts failure must not break the dashboard
            pass

    dashboard_path = render(data, config.dashboard_dir,
                            keep_previous=config.keep_previous_dashboards)
    state.data["last_run"] = today.isoformat()
    if not dry_run:
        state.save()

    if open_dashboard:
        _open(dashboard_path, config.dashboard_browser)
    return dashboard_path


def when_str(dt) -> str:
    # Display due dates in the machine's local time (UTC-aware -> local).
    return dt.astimezone().strftime("%Y-%m-%d %H:%M") if dt else "unknown"


def _strip_prefix(filename: str, prefix: str) -> str:
    """Drop the on-disk ``Last_First_username_`` filename prefix for display in the dashboard.
    The file on disk keeps the prefix; only the shown text is shortened to the original name."""
    return filename[len(prefix):] if prefix and filename.startswith(prefix) else filename


# --------------------------------------------------------------------------- #
# Student photos: a real Blackboard avatar where available, else colored initials.
# Photos are cached under data_dir/avatars so we don't re-fetch every morning.
# --------------------------------------------------------------------------- #

_AVATAR_EXT = {"image/jpeg": "jpg", "image/jpg": "jpg", "image/png": "png", "image/gif": "gif"}
_NONE_RECHECK_SECS = 7 * 24 * 3600  # re-check "no photo" students weekly (in case one is added)


def _avatar_color(seed: str) -> str:
    """A stable, pleasant background color for an initials badge (hashed from the user id)."""
    hue = int(hashlib.md5((seed or "?").encode("utf-8")).hexdigest(), 16) % 360
    return f"hsl({hue}, 52%, 42%)"


def _initials(name_info) -> str:
    given = (name_info.given or "").strip()
    family = (name_info.family or "").strip()
    letters = (given[:1] + family[:1]) or (name_info.display or "?")[:1]
    return letters.upper()


def _data_uri(content: bytes, content_type: str) -> str:
    ct = (content_type or "image/jpeg").split(";")[0].strip() or "image/jpeg"
    return f"data:{ct};base64,{base64.b64encode(content).decode('ascii')}"


def _build_avatar(client, config, uid: str, name_info, memo: dict) -> Avatar:
    """Return an Avatar for this student, using (in order): the in-run memo, an on-disk
    cached photo, a freshly fetched photo, or a colored initials badge. Results are memoized
    per run and photos are cached on disk (with a weekly re-check for the 'no photo' case)."""
    if uid in memo:
        return memo[uid]
    initials, color = _initials(name_info), _avatar_color(uid or name_info.display)
    av = Avatar(initials=initials, color=color, uid=uid or "")

    cache_dir = config.data_dir / "avatars"
    key = sanitize(uid) if uid else ""
    if uid:
        cache_dir.mkdir(parents=True, exist_ok=True)
        for ext, ct in (("jpg", "image/jpeg"), ("png", "image/png"), ("gif", "image/gif")):
            p = cache_dir / f"{key}.{ext}"
            if p.exists():
                av = Avatar(data_uri=_data_uri(p.read_bytes(), ct), initials=initials,
                            color=color, uid=uid, path=str(p.resolve()))
                memo[uid] = av
                return av
        none_marker = cache_dir / f"{key}.none"
        fresh_none = none_marker.exists() and (time.time() - none_marker.stat().st_mtime) < _NONE_RECHECK_SECS
        if not fresh_none:
            try:
                result = client.get_avatar(uid)
            except Exception:  # noqa: BLE001 - a photo is never worth failing the run
                result = None
            if result:
                content, ct = result
                ext = _AVATAR_EXT.get(ct.split(";")[0].strip().lower(), "jpg")
                saved = cache_dir / f"{key}.{ext}"
                try:
                    saved.write_bytes(content)
                except OSError:
                    pass
                av = Avatar(data_uri=_data_uri(content, ct), initials=initials,
                            color=color, uid=uid, path=str(saved.resolve()))
            else:
                try:
                    none_marker.write_bytes(b"")
                except OSError:
                    pass
    memo[uid] = av
    return av


def _course_number(course) -> str:
    """A short course designator for emails, e.g. 'PHYS 220' — pulled from the course name
    (or code) if it matches a course-code pattern; otherwise the code/name as-is."""
    for text in (course.name or "", course.code or ""):
        m = re.search(r"[A-Z]{2,5}[ -]?\d{3}[A-Z]?", text)
        if m:
            return m.group(0).replace("-", " ")
    return course.code or course.name or "your course"


def _due_recently(due_dt, today) -> bool:
    """True if the assignment was due 'last night' (yesterday or today, local time)."""
    if not due_dt or due_dt > today:
        return False
    return (today.astimezone().date() - due_dt.astimezone().date()).days <= 1


class _SafeDict(dict):
    """format_map helper: leave any unknown {placeholder} untouched instead of raising."""
    def __missing__(self, key):
        return "{" + key + "}"


def _fill_email(template: str, first_name: str, assignment: str, course_number: str) -> str:
    """Substitute the nudge-email placeholders, tolerating a template that is missing some of
    them or contains stray braces (a bad custom template must never crash a run)."""
    try:
        return template.format_map(_SafeDict(first_name=first_name, assignment=assignment,
                                             course_number=course_number))
    except (ValueError, IndexError):
        return template


def _missing_mailto(email: str, first_name: str, assignment: str, course_number: str,
                    template: str) -> str:
    """Build a mailto: URL to nudge one student about a missing assignment, using the given body
    ``template`` (the config's ``missing_email_new`` for just-due work, ``missing_email_old`` for
    an older still-missing one)."""
    subject = "Missing Assignment"
    body = _fill_email(template, first_name, assignment, course_number)
    return f"mailto:{email}?subject={quote(subject)}&body={quote(body)}"


def _missing_mailto_group(emails: list[str], assignment: str, course_number: str,
                          template: str) -> str:
    """A single nudge addressed to every student missing one assignment (uses the same body
    template as the per-student email, greeting the group with 'all')."""
    subject = "Missing Assignment"
    body = _fill_email(template, "all", assignment, course_number)
    return f"mailto:{','.join(emails)}?subject={quote(subject)}&body={quote(body)}"


def _should_run_weekly(state: State, config, today) -> bool:
    """Run the weekly roundup on the configured weekday, at most once that day."""
    if today.weekday() != config.weekly_roundup_weekday:
        return False
    last = parse_dt(state.data.get("last_weekly_roundup"))
    if last and last.date() == today.date():
        return False
    return True


def _open(path: Path, app: str = "") -> None:
    """Open the finished dashboard. If ``app`` is given (e.g. 'Safari'), prefer it and fall back
    to the system default browser. OS-specifics live in ``osutil``."""
    osutil.open_in_app(path, app)
    print(f"Dashboard: {path}")


# --------------------------------------------------------------------------- #
# Launch prompt (#1): a dialog asking whether to run now
# --------------------------------------------------------------------------- #

_LAUNCH_TIMEOUT_SECS = 300  # dialog auto-answers "Run Now" after this many seconds


def prompt_launch(config) -> str:
    """Show the 2-button launch dialog and return 'run' or 'skip'. "Not Now" (or Escape) =
    don't run today; no response defaults to 'run' so the morning automation still proceeds if
    you're away. The actual dialog is drawn by ``osutil`` (native on macOS)."""
    icon_source = config.dialog_icon.strip() if config.dialog_icon else str(config.data_dir / "dialog_icon.png")
    return osutil.ask_run_now(
        "Download from Blackboard?", "BB Offline Dashboard", confirm_label="Download",
        icon_source=icon_source, cache_dir=config.data_dir, timeout=_LAUNCH_TIMEOUT_SECS,
    )


def check(config, client=None) -> int:
    """Validate config + authentication + course discovery without downloading anything."""
    print(f"Instance:   {config.base_url}")
    print(f"Output dir: {config.output_dir}")
    client = client or BlackboardClient(config)
    try:
        token = client.tokens.get_token()
        print(f"Auth:       OK (token acquired, length {len(token)})")
    except Exception as e:  # noqa: BLE001 - surface any auth failure plainly
        print(f"Auth:       FAILED — {e}")
        return 2
    try:
        courses = discover.list_instructor_courses(client, config)
    except APIError as e:
        print(f"Courses:    FAILED — {e}")
        return 3
    print(f"Courses:    {len(courses)} found")
    # Resolve term ids -> names so you can see the exact semester strings to use in term_filter.
    term_names = discover.get_term_names(client) if courses else {}
    for c in courses:
        term = term_names.get(c.term_id, "") or c.term_id
        suffix = f"  [term: {term}]" if term else ""
        print(f"  - {c.code or c.id}: {c.name}{suffix}")
    return 0


def main(argv: list[str] | None = None) -> int:
    osutil.enable_utf8_console()
    parser = argparse.ArgumentParser(description="Blackboard morning submission dashboard")
    parser.add_argument("--config", help="Path to config JSON (default ~/.bbdash/config.json)")
    parser.add_argument("--dry-run", action="store_true", help="Analyze + dashboard, download nothing, don't save state")
    parser.add_argument("--no-open", action="store_true", help="Do not auto-open the dashboard")
    parser.add_argument("--no-prompt", action="store_true", help="Skip the run/skip/wait dialog")
    parser.add_argument("--check", action="store_true", help="Validate config + auth + list courses, then exit")
    parser.add_argument("--gradebook", nargs="?", const="__ALL__", metavar="COURSE",
                        help="Open a course's gradebook in the browser (no value = launcher page for all courses)")
    args = parser.parse_args(argv)

    try:
        config = load_config(args.config)
    except ConfigError as e:
        print(f"Config error: {e}", file=sys.stderr)
        return 1

    if args.check:
        return check(config)

    if args.gradebook is not None:
        from .gradebook import run_gradebook
        return run_gradebook(config, args.gradebook)

    # Launch prompt (skipped for dry runs, when disabled, or via --no-prompt).
    if not args.dry_run and not args.no_prompt and config.launch_prompt:
        if prompt_launch(config) == "skip":
            later = (r".\install\run.ps1 --no-prompt" if osutil.IS_WINDOWS
                     else "python3 -m bbdash --no-prompt")
            print(f"Not now. Run it later with: {later}")
            return 0

    try:
        run(config, dry_run=args.dry_run, open_dashboard=not args.no_open)
    except (APIError, ConfigError) as e:
        print(f"Run failed: {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
