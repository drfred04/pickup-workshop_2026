"""Post-processing for code submissions.

For Python submissions (plain ``.py``/``.pyw`` files *and* the code cells of Jupyter
``.ipynb`` notebooks) we keep the original file and also write a second, cleaned copy:
  - all ``#`` comments removed (via the standard-library ``tokenize`` module, so a ``#``
    inside a string literal is never mistaken for a comment), and
  - docstrings removed when ``strip_docstrings`` is True (via the AST; a docstring that is
    a block's only statement is replaced with ``pass`` so the code stays valid).

What is preserved:
  - shebang lines (``#!...`` on line 1),
  - real string literals (even those containing ``#`` or triple quotes),
  - all formatting/indentation (a comment-only line becomes blank).

Notebooks: only Python notebooks are processed; markdown cells and cell-magic cells
(``%%bash`` etc.) are left untouched; the notebook stays a valid ``.ipynb``.
"""
from __future__ import annotations

import ast
import io
import json
import os
import tokenize
from pathlib import Path

from .util import fs_path

PYTHON_EXTENSIONS = {".py", ".pyw"}
NOTEBOOK_EXTENSIONS = {".ipynb"}


def is_python_file(filename: str) -> bool:
    return Path(filename).suffix.lower() in PYTHON_EXTENSIONS


def is_notebook_file(filename: str) -> bool:
    return Path(filename).suffix.lower() in NOTEBOOK_EXTENSIONS


def is_code_submission(filename: str) -> bool:
    return is_python_file(filename) or is_notebook_file(filename)


def stripped_path(path: Path) -> Path:
    """Sibling path for the stripped copy: foo.py -> foo_nocomments.py"""
    return path.with_name(f"{path.stem}_nocomments{path.suffix}")


def _docstring_spans(source: str):
    """Return [(start_offset, end_offset, is_sole_statement), ...] for every module-,
    class-, and function-level docstring, or None if the source doesn't parse.

    ``is_sole_statement`` is True when the docstring is the only statement in its block
    (removing it would leave an empty body, so it must be replaced with ``pass``).
    """
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return None

    line_starts = [0]
    for line in source.splitlines(keepends=True):
        line_starts.append(line_starts[-1] + len(line))

    def offset(lineno: int, col: int) -> int:
        return line_starts[lineno - 1] + col

    spans = []

    def consider(body):
        if body and isinstance(body[0], ast.Expr):
            value = body[0].value
            if isinstance(value, ast.Constant) and isinstance(value.value, str):
                node = body[0]
                start = offset(node.lineno, node.col_offset)
                end = offset(node.end_lineno, node.end_col_offset)
                spans.append((start, end, len(body) == 1))

    consider(tree.body)  # module docstring
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            consider(node.body)
    return spans


def strip_python_docstrings(source: str) -> str:
    """Remove module/class/function docstrings. If a docstring is a block's only
    statement, it's replaced with ``pass`` to keep the code valid. On a parse error the
    source is returned unchanged (we never corrupt)."""
    spans = _docstring_spans(source)
    if not spans:
        return source
    for start, end, is_sole in sorted(spans, key=lambda s: s[0], reverse=True):
        source = source[:start] + ("pass" if is_sole else "") + source[end:]
    return source


def strip_python_comments(source: str, strip_docstrings: bool = False) -> str:
    """Return ``source`` with all ``#`` comments removed, preserving everything else.

    A Python ``#`` comment always runs to the end of its line, so for each line that
    contains a comment token we truncate the line at the comment's start column. A
    shebang (``#!`` on line 1) is kept. When ``strip_docstrings`` is True, docstrings are
    removed first (see :func:`strip_python_docstrings`).
    """
    if strip_docstrings:
        source = strip_python_docstrings(source)
    comment_start_col: dict[int, int] = {}
    try:
        for tok in tokenize.generate_tokens(io.StringIO(source).readline):
            if tok.type == tokenize.COMMENT:
                ln, col = tok.start
                # Keep a shebang line ("#!..." on the very first line, column 0).
                if ln == 1 and col == 0 and tok.string.startswith("#!"):
                    continue
                if ln not in comment_start_col or col < comment_start_col[ln]:
                    comment_start_col[ln] = col
    except (tokenize.TokenError, IndentationError, SyntaxError):
        # Incomplete/invalid source (e.g. work-in-progress, or a non-Python notebook
        # cell): keep whatever positions we collected. Worst case we under-strip,
        # never corrupt.
        pass

    if not comment_start_col:
        return source

    out_lines: list[str] = []
    for i, line in enumerate(source.splitlines(keepends=True), start=1):
        if i in comment_start_col:
            col = comment_start_col[i]
            stripped = line.rstrip("\r\n")
            newline = line[len(stripped):]
            kept = stripped[:col].rstrip()
            out_lines.append(kept + newline)
        else:
            out_lines.append(line)
    return "".join(out_lines)


def _notebook_is_python(nb: dict) -> bool:
    meta = nb.get("metadata", {}) or {}
    lang = (
        (meta.get("language_info") or {}).get("name")
        or (meta.get("kernelspec") or {}).get("language")
        or (meta.get("kernelspec") or {}).get("name")
        or ""
    )
    lang = str(lang).lower()
    if not lang:
        return True  # unspecified -> assume Python (the common case for student work)
    return "python" in lang or lang.startswith("py")


def strip_notebook_comments(raw: str, strip_docstrings: bool = False) -> str | None:
    """Strip ``#`` comments (and optionally docstrings) from the code cells of a Jupyter
    notebook.

    Returns the new notebook JSON, or None if it's not a Python notebook.
    Raises ValueError/JSONDecodeError if ``raw`` isn't a valid notebook.
    """
    nb = json.loads(raw)
    if not _notebook_is_python(nb):
        return None
    for cell in nb.get("cells", []):
        if cell.get("cell_type") != "code":
            continue
        src = cell.get("source", "")
        text = "".join(src) if isinstance(src, list) else (src or "")
        first_line = text.lstrip().split("\n", 1)[0] if text else ""
        if first_line.startswith("%%"):
            continue  # cell magic -> not plain Python; leave untouched
        stripped = strip_python_comments(text, strip_docstrings=strip_docstrings)
        # nbformat stores source as a list of lines (each keeping its trailing newline).
        cell["source"] = stripped.splitlines(keepends=True)
    return json.dumps(nb, indent=1, ensure_ascii=False) + "\n"


def make_stripped_copy(path: Path, strip_docstrings: bool = False) -> Path | None:
    """Write a stripped copy next to ``path``. Returns it, or None if not code."""
    path = Path(path)

    if is_python_file(path.name):
        try:
            source = _read_text(path)
        except OSError:
            return None
        out = stripped_path(path)
        _write_text(out, strip_python_comments(source, strip_docstrings=strip_docstrings))
        return out

    if is_notebook_file(path.name):
        try:
            raw = _read_text(path)
            result = strip_notebook_comments(raw, strip_docstrings=strip_docstrings)
        except (OSError, json.JSONDecodeError, ValueError):
            return None  # not a valid notebook -> skip rather than corrupt
        if result is None:
            return None  # non-Python notebook
        out = stripped_path(path)
        _write_text(out, result)
        return out

    return None


def _read_text(path: Path) -> str:
    # fs_path() keeps this working for >260-char paths on Windows.
    with open(fs_path(path), "r", encoding="utf-8", errors="replace") as f:
        return f.read()


def _write_text(path: Path, text: str) -> None:
    with open(fs_path(path), "w", encoding="utf-8") as f:
        f.write(text)


def ensure_stripped_copy(path: Path, strip_docstrings: bool = False) -> Path | None:
    """Like make_stripped_copy, but only writes if the stripped copy is missing."""
    path = Path(path)
    if not is_code_submission(path.name):
        return None
    if os.path.exists(fs_path(stripped_path(path))):
        return None
    return make_stripped_copy(path, strip_docstrings=strip_docstrings)
