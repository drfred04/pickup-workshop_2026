"""Discovery + lookups against the Blackboard REST API.

All endpoints and field names here were verified against Anthology's official docs
(see docs/DESIGN_NOTES.md, "Verified against official docs").
"""
from __future__ import annotations

from dataclasses import dataclass

from .api import BlackboardClient
from .config import Config
from .util import sanitize

# Attempt statuses that represent a real, submitted attempt (v2 values).
SUBMITTED_STATUSES = {"NeedsGrading", "Completed", "NeedsGradingAgain"}
# Columns we monitor: gradable, submittable assignment columns.
SUBMITTABLE_GRADING_TYPE = "Attempts"


@dataclass
class Course:
    id: str          # internal pk1 id, e.g. "_12345_1"
    name: str
    code: str        # human course code, e.g. "PHYS-301-001"
    term_id: str = ""  # the course's term/semester id (e.g. "_123_1"); "" if none

    @property
    def label(self) -> str:
        return sanitize(self.name or self.code or self.id)


@dataclass
class NameInfo:
    family: str
    given: str
    username: str
    email: str = ""

    @property
    def label(self) -> str:
        """Filename prefix: LastName_FirstName_username (sanitized). Filenames keep the
        username, not the email (emails contain '@' and are noisier in a filename)."""
        parts = [p for p in (self.family, self.given, self.username) if p]
        return sanitize("_".join(parts)) if parts else "unknown"

    @property
    def display(self) -> str:
        """Human-readable: 'Family, Given (email)'. Falls back to username if no email."""
        ident = self.email or self.username
        name = ", ".join(p for p in (self.family, self.given) if p) or ident or "Unknown"
        if ident and (self.family or self.given):
            return f"{name} ({ident})"
        return name


def list_instructor_courses(client: BlackboardClient, config: Config) -> list[Course]:
    """Return the courses the instructor teaches.

    If ``instructor_username`` is configured, we list that user's memberships and keep
    Instructor roles (precise). Otherwise we fall back to every course the token can see.
    The result is then narrowed by ``term_filter`` (semester names, the recommended default)
    and/or ``course_filter`` (specific IDs or codes) when provided.
    """
    courses: list[Course] = []

    if config.instructor_username:
        user_ref = f"userName:{config.instructor_username}"
        memberships = client.get_all(f"/learn/api/public/v1/users/{user_ref}/courses")
        for m in memberships:
            if m.get("courseRoleId") not in (None, "Instructor"):
                continue
            cid = m.get("courseId")
            if not cid:
                continue
            detail = client.get(f"/learn/api/public/v1/courses/{cid}") or {}
            courses.append(
                Course(id=cid, name=detail.get("name", ""), code=detail.get("courseId", ""),
                       term_id=detail.get("termId", ""))
            )
    else:
        for c in client.get_all("/learn/api/public/v1/courses"):
            courses.append(
                Course(id=c.get("id", ""), name=c.get("name", ""), code=c.get("courseId", ""),
                       term_id=c.get("termId", ""))
            )

    # Semester/term filter (recommended default): match user-supplied names against each
    # course's term name (case-insensitive substring), or its term id exactly.
    if config.term_filter:
        wanted_terms = [w.strip().lower() for w in config.term_filter if w.strip()]
        term_names = get_term_names(client)
        courses = [c for c in courses if _matches_term(c, wanted_terms, term_names)]

    if config.course_filter:
        wanted = set(config.course_filter)
        courses = [c for c in courses if c.id in wanted or c.code in wanted]

    return courses


def get_term_names(client: BlackboardClient) -> dict[str, str]:
    """Map term id -> human term name (e.g. '_123_1' -> 'Fall 2026'). Empty if the terms
    endpoint isn't available/entitled — term-name filtering then can't match, so we fail open
    to 'no term match' and the user should verify names via ``--check``."""
    out: dict[str, str] = {}
    try:
        for t in client.get_all("/learn/api/public/v1/terms"):
            tid = t.get("id")
            if tid:
                out[tid] = t.get("name") or ""
    except Exception:  # noqa: BLE001 - terms are advisory; never fail discovery over them
        pass
    return out


def _matches_term(course: Course, wanted_terms: list[str], term_names: dict[str, str]) -> bool:
    """True if the course's term matches any wanted term. A wanted string matches when it
    equals the term id, or is a substring of the term's name (so 'Fall 2026' matches a term
    named 'Fall 2026 Undergraduate'). Both compared case-insensitively."""
    tid = (course.term_id or "").lower()
    tname = (term_names.get(course.term_id, "") or "").lower()
    for w in wanted_terms:
        if w and (w == tid or (tname and w in tname)):
            return True
    return False


def list_assignments(client: BlackboardClient, course_id: str) -> list[dict]:
    """Gradebook columns that are submittable assignments (have attempts)."""
    cols = client.get_all(f"/learn/api/public/v2/courses/{course_id}/gradebook/columns")
    out = []
    for c in cols:
        grading = c.get("grading") or {}
        if grading.get("type") == SUBMITTABLE_GRADING_TYPE:
            out.append(c)
    return out


def column_due(column: dict) -> str | None:
    return (column.get("grading") or {}).get("due")


def column_name(column: dict) -> str:
    return column.get("name") or column.get("id") or "Unnamed assignment"


def get_attempts(client: BlackboardClient, course_id: str, column_id: str) -> list[dict]:
    return client.get_all(
        f"/learn/api/public/v2/courses/{course_id}/gradebook/columns/{column_id}/attempts"
    )


def get_student_roster(client: BlackboardClient, course_id: str) -> set[str]:
    """User IDs of enrolled students (courseRoleId == 'Student')."""
    members = client.get_all(f"/learn/api/public/v1/courses/{course_id}/users")
    return {m["userId"] for m in members if m.get("courseRoleId") == "Student" and m.get("userId")}


def is_submitted(attempt: dict) -> bool:
    if attempt.get("status") in SUBMITTED_STATUSES:
        return True
    # Fallback: a present submission timestamp with a non-in-progress status.
    return bool(attempt.get("attemptDate")) and attempt.get("status") != "InProgress"


def submission_timestamp(attempt: dict) -> str | None:
    receipt = attempt.get("attemptReceipt") or {}
    return receipt.get("submissionDate") or attempt.get("attemptDate") or attempt.get("created")


class NameResolver:
    """Resolves and caches userId -> NameInfo via /users/{id}."""

    def __init__(self, client: BlackboardClient, email_domain: str = ""):
        self.client = client
        self.email_domain = email_domain
        self._cache: dict[str, NameInfo] = {}

    def resolve(self, user_id: str) -> NameInfo:
        if user_id in self._cache:
            return self._cache[user_id]
        u = self.client.get(f"/learn/api/public/v1/users/{user_id}") or {}
        name = u.get("name") or {}
        username = u.get("userName", "")
        email = ((u.get("contact") or {}).get("email") or "").strip()
        if not email and username and self.email_domain:
            email = f"{username}@{self.email_domain}"
        info = NameInfo(
            family=name.get("family", ""),
            given=name.get("given", ""),
            username=username,
            email=email,
        )
        self._cache[user_id] = info
        return info
