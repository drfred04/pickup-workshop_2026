"""Per-course submission-status spreadsheet (CSV).

Layout:
  - Column 1: Last Name, Column 2: First Name
  - One further column per assignment (header = assignment name)
  - Cell value per student/assignment:
        ""  (blank) -> submitted on time
        "L"         -> submitted late
        "X"         -> not submitted (and the due date has passed)
    A not-yet-due, not-submitted assignment is left blank (still pending).

Rewritten in full on each run, so it always reflects current state.
"""
from __future__ import annotations

import csv
from pathlib import Path

ON_TIME = ""
LATE = "L"
MISSING = "X"


def write_status_csv(path: Path, assignments, students, statuses) -> Path:
    """
    assignments: list of (column_id, display_name) in column order
    students:    list of (user_id, NameInfo) in row order
    statuses:    dict[(user_id, column_id)] -> "", "L", or "X"
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    header = ["Last Name", "First Name"] + [name for _, name in assignments]
    tmp = path.with_suffix(".csv.tmp")
    with open(tmp, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(header)
        for uid, info in students:
            row = [info.family, info.given]
            for col_id, _ in assignments:
                val = statuses.get((uid, col_id), ON_TIME)
                # On-time is "OK" internally (green check in HTML) but blank in the CSV.
                row.append("" if val == "OK" else val)
            writer.writerow(row)
    tmp.replace(path)  # atomic
    return path
