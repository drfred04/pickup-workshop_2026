"""Small cross-platform layer for the few OS-specific actions this tool performs.

Everything else in the package is plain, portable Python. The only OS‑specific behaviors are:
  * opening a file or URL in an application,
  * opening a pre‑filled mail draft, and
  * showing the "run now?" launch dialog.

Those all live here so a port to another OS has exactly one file to fill in (plus scheduling,
which lives outside Python — launchd on macOS, Task Scheduler on Windows).

Platform status:
  * **macOS** — fully implemented and in use.
  * **Windows** — implemented and tested: file/URL/mail open via ``os.startfile`` (+ a mac→Windows
    app-name map, with ``.cmd`` launchers like VS Code's ``code`` resolved through the shell), and
    a native Yes/No dialog via ``user32.MessageBoxTimeoutW`` that preserves the "no response -> run"
    timeout behavior. Scheduling is Windows Task Scheduler (see ``install/windows/``).
  * **Linux / other** — file/URL/mail via ``xdg-open``; dialog via a tkinter fallback.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

IS_MAC = sys.platform == "darwin"
IS_WINDOWS = os.name == "nt"


def enable_utf8_console() -> None:
    """Make stdout/stderr emit UTF-8 so Unicode in our messages (em dashes, ``✓``, arrows,
    student names) prints correctly instead of turning into mojibake on Windows' legacy console
    code page. Safe no-op on macOS/Linux and when the streams are already UTF-8 or unredirectable.
    """
    if not IS_WINDOWS:
        return
    for stream in (sys.stdout, sys.stderr):
        try:
            enc = (getattr(stream, "encoding", "") or "").lower()
            if enc.replace("-", "") != "utf8" and hasattr(stream, "reconfigure"):
                stream.reconfigure(encoding="utf-8")  # type: ignore[union-attr]  # 3.7+ TextIO
        except (OSError, ValueError):
            pass


# --------------------------------------------------------------------------- #
# Opening files / URLs / mail
# --------------------------------------------------------------------------- #

def open_in_app(target, app: str = "") -> None:
    """Open a file path or URL. If ``app`` is given (e.g. 'Safari', 'Visual Studio Code'),
    prefer it and fall back to the OS default if launching that app fails. Never raises —
    opening something is a convenience, never worth crashing a run over."""
    target = str(target)
    try:
        if IS_MAC:
            _open_mac(target, app)
        elif IS_WINDOWS:
            _open_windows(target, app)
        else:  # Linux / other
            subprocess.run(["xdg-open", target], check=False)
    except OSError:
        pass


def _open_mac(target: str, app: str) -> None:
    if app:
        result = subprocess.run(["open", "-a", app, target], check=False)
        if result.returncode != 0:              # named app missing -> system default
            subprocess.run(["open", target], check=False)
    else:
        subprocess.run(["open", target], check=False)


# macOS app *names* (the shipped config defaults) mapped to Windows equivalents. A Windows user
# would normally set dashboard_browser="" (system default browser) and code_editor_app to "code"
# or a full path — but mapping the defaults means it still works out of the box. "" means
# "no equivalent, use the OS default handler".
_WINDOWS_APPS = {
    "Visual Studio Code": "code",     # the `code` launcher (installed with the "Add to PATH" option)
    "Safari": "",                     # no Safari on Windows -> default browser
    "Preview": "",                    # no Preview on Windows -> default image viewer
    "Google Chrome": "chrome",
    "Firefox": "firefox",
    "Microsoft Edge": "msedge",
}


def _open_windows(target: str, app: str) -> None:
    # os.startfile() launches files, http(s) URLs, and mailto: with the user's default handler
    # and returns immediately (non-blocking) — the closest match to macOS `open`.
    if app:
        cmd = _WINDOWS_APPS.get(app, app)       # map known names; else treat `app` as a command/path
        if cmd:
            # Launchers like VS Code's `code` are really `code.cmd`; a bare Popen(["code", ...])
            # raises FileNotFoundError because it doesn't apply PATHEXT. Resolve the real
            # executable (respecting PATHEXT) with shutil.which first; a .cmd shim must run
            # through the shell, so use shell=True in that case.
            resolved = shutil.which(cmd) or cmd
            try:
                if resolved.lower().endswith((".cmd", ".bat")):
                    subprocess.Popen(f'"{resolved}" "{target}"', shell=True)
                else:
                    subprocess.Popen([resolved, target])
                return
            except OSError:
                pass                            # app not found -> default handler
    os.startfile(target)  # type: ignore[attr-defined]  # Windows-only API; default handler


def open_mail(mailto_url: str) -> None:
    """Open a pre-filled mail draft (a ``mailto:`` URL) in the default mail client."""
    open_in_app(mailto_url)


# --------------------------------------------------------------------------- #
# Launch dialog ("Download from Blackboard?")
# --------------------------------------------------------------------------- #

def ask_run_now(message: str, title: str, *, confirm_label: str = "Run Now", icon_source="",
                cache_dir=None, timeout: int = 300) -> str:
    """Show a 2‑button launch dialog. Returns ``"run"`` or ``"skip"``. ``confirm_label`` is the
    text on the affirmative button (macOS dialog only; the Windows/fallback dialogs use Yes/No).

    "Not Now"/Escape → "skip" (don't run). No response (the dialog times out) → "run", so an
    unattended morning run still proceeds when you're away from the machine.
    """
    if IS_MAC:
        return _ask_run_now_mac(message, title, confirm_label, icon_source, cache_dir, timeout)
    if IS_WINDOWS:
        return _ask_run_now_windows(message, title, timeout)
    return _ask_run_now_fallback(message, title)


def _as_quote(s: str) -> str:
    """Escape a string for embedding inside an AppleScript double-quoted literal."""
    return s.replace("\\", "\\\\").replace('"', '\\"')


def _mac_icon_clause(icon_source, cache_dir) -> str:
    """AppleScript ``with icon ...`` clause. Converts a PNG to ``.icns`` via ``sips`` if needed;
    falls back to the standard note icon when no custom icon is available."""
    if not icon_source:
        return "with icon note"
    src_path = Path(icon_source).expanduser()
    if not src_path.exists():
        return "with icon note"
    cache_dir = Path(cache_dir) if cache_dir else src_path.parent
    icns = cache_dir / "dialog_icon.icns"
    try:
        if not icns.exists() or icns.stat().st_mtime < src_path.stat().st_mtime:
            r = subprocess.run(["sips", "-s", "format", "icns", str(src_path), "--out", str(icns)],
                               capture_output=True, check=False)
            if r.returncode != 0:
                return "with icon note"
        if icns.exists():
            return f'with icon (POSIX file "{icns}")'
    except OSError:
        pass
    return "with icon note"


def _ask_run_now_mac(message, title, confirm_label, icon_source, cache_dir, timeout) -> str:
    icon = _mac_icon_clause(icon_source, cache_dir)
    cl = _as_quote(confirm_label)
    script = (
        'tell application "System Events"\n'
        '  activate\n'
        f'  set r to display dialog "{_as_quote(message)}" '
        f'with title "{_as_quote(title)}" '
        f'buttons {{"Not Now", "{cl}"}} default button "{cl}" cancel button "Not Now" '
        f'{icon} giving up after {timeout}\n'
        'end tell\n'
        'return (button returned of r) & "|||" & ((gave up of r) as string)'
    )
    try:
        proc = subprocess.run(["osascript", "-e", script],
                              capture_output=True, text=True, timeout=timeout + 60)
    except (OSError, subprocess.SubprocessError):
        return "run"        # no GUI / hung -> just run
    if proc.returncode != 0:
        return "skip"       # "Not Now" (cancel button) or Escape -> don't run today
    parts = proc.stdout.strip().split("|||")
    button = parts[0].strip() if parts else ""
    gave_up = len(parts) > 1 and parts[1].strip().lower() == "true"
    if gave_up:
        return "run"        # no response -> default to running
    return "skip" if button == "Not Now" else "run"


def _ask_run_now_windows(message, title, timeout) -> str:
    """Native Windows Yes/No via user32. ``MessageBoxTimeoutW`` auto-dismisses after ``timeout``
    seconds and returns IDTIMEOUT, which lets us keep the macOS "no response -> run" behavior for
    unattended morning runs. Falls back to a plain MessageBox (no timeout), then to tkinter.

    NOTE(windows-TODO, untested): a custom app icon isn't shown here (MessageBox only offers the
    standard system icons). For a branded dialog with a custom icon, swap this for a small
    tkinter/Win32 window when a real Windows build is done.
    """
    try:
        import ctypes
        MB_YESNO = 0x00000004
        MB_ICONQUESTION = 0x00000020
        MB_SETFOREGROUND = 0x00010000
        IDYES, IDNO, IDTIMEOUT = 6, 7, 32000
        flags = MB_YESNO | MB_ICONQUESTION | MB_SETFOREGROUND
        user32 = ctypes.windll.user32  # type: ignore[attr-defined]  # Windows-only
        try:
            # MessageBoxTimeoutW is undocumented but present on all modern Windows:
            #   (hwnd, text, caption, uType, wLanguageId, dwMilliseconds)
            rc = user32.MessageBoxTimeoutW(0, str(message), str(title), flags, 0,
                                           int(timeout) * 1000)
        except AttributeError:
            rc = user32.MessageBoxW(0, str(message), str(title), flags)  # no timeout available
        if rc == IDNO:
            return "skip"
        return "run"  # IDYES, IDTIMEOUT (no response), or anything else -> run
    except Exception:  # noqa: BLE001 - no GUI / ctypes issue -> tkinter, then unattended default
        return _ask_run_now_fallback(message, title)


def _ask_run_now_fallback(message, title) -> str:
    """Non‑macOS: a simple Yes/No dialog via tkinter. If no GUI is available, default to "run"
    (matching the macOS "no response -> run" behavior for unattended automation).

    TODO(windows): add a timeout auto-answer and a custom icon when a Windows build ships.
    """
    try:
        import tkinter
        from tkinter import messagebox
        root = tkinter.Tk()
        root.withdraw()
        try:
            answer = messagebox.askyesno(title, message)
        finally:
            root.destroy()
        return "run" if answer else "skip"
    except Exception:  # noqa: BLE001 - no display / tk missing -> proceed unattended
        return "run"
