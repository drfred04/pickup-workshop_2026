"""BB Offline Dashboard — Blackboard submission downloader + morning dashboard.

A daily, automated tool that downloads new Blackboard assignment submissions for
all of an instructor's courses and produces a morning summary dashboard.

See docs/DESIGN_NOTES.md in the project root for the full design.
"""

__version__ = "0.1.0"
