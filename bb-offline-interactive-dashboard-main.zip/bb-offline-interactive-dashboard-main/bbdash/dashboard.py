"""Render the morning dashboard as a self-contained HTML file (plus per-submission detail pages).

The dashboard stays entirely on your machine; no student data is transmitted anywhere.

Interactive features:
  - on-time submissions show a green check (✓); late = L; missing = ✕;
  - clicking a ✓ or L opens a detail page for that one student + assignment in a new tab;
  - clicking a student's name focuses the whole dashboard on just that student.
"""
from __future__ import annotations

import html
import json
import re
import shutil
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from urllib.parse import quote


@dataclass
class SubmissionRow:
    course: str
    assignment: str
    student: str
    student_key: str            # stable id (userId) for the "focus one student" filter
    late: bool
    when: str
    files: list = field(default_factory=list)   # [(name, abs_path), ...]
    page_id: str = ""           # this assignment's per-assignment page (links the assignment name)


@dataclass
class MissingRow:
    course: str
    assignment: str
    due: str
    students: list = field(default_factory=list)  # [(display, key), ...]
    student_mailtos: dict = field(default_factory=dict)  # key -> nudge mailto for that student
    group_mailto: str = ""   # a single nudge addressed to every missing student in this row
    page_id: str = ""        # this assignment's per-assignment page (links the assignment name)


@dataclass
class Avatar:
    data_uri: str = ""     # a real photo, as a data: URI (self-contained in the dashboard)
    initials: str = ""     # fallback badge text
    color: str = "#8a8a8a"
    uid: str = ""          # student id (so a dropped photo can be routed to the right file)
    path: str = ""         # on-disk photo file, if any (click a thumbnail to open it full-size)


@dataclass
class GridCell:
    status: str            # "OK" (on time) | "L" (late) | "X" (missing) | "" (nothing yet)
    detail_id: str = ""    # for OK/L: links to that submission's detail page
    mailto: str = ""       # for X: a mailto: URL to email the student about the missing work


@dataclass
class StatusGrid:
    course: str
    assignments: list[str]
    rows: list             # [(student_display, student_key, [GridCell, ...]), ...]
    csv_path: str = ""
    gradebook_url: str = ""   # link to this course's Blackboard gradebook
    assignment_ids: list = field(default_factory=list)  # page_id per column, aligned with `assignments`


@dataclass
class SubmissionDetail:
    detail_id: str
    student: str
    email: str
    course: str
    assignment: str
    late: bool
    when: str
    due: str
    files: list = field(default_factory=list)   # [(name, abs_path), ...]
    text: str = ""
    avatar: "Avatar | None" = None


@dataclass
class AssignmentRow:
    student: str                # display (may include "(email)")
    student_key: str            # uid
    status: str                 # "OK" | "L" | "X" | ""
    when: str = ""              # submission time (submitters only)
    files: list = field(default_factory=list)   # [(name, abs_path), ...]
    mailto: str = ""            # for missing (X): a pre-filled nudge email
    text: str = ""              # typed submission, if any


@dataclass
class AssignmentPage:
    course: str
    assignment: str
    due: str
    page_id: str                # basename of the per-assignment HTML page
    rows: list = field(default_factory=list)     # [AssignmentRow, ...]
    gradebook_url: str = ""


@dataclass
class RosterTable:
    """All enrolled students for one course, colored by their status on that course's
    most-recently-due assignment: red row = not submitted, orange = late, plain = on time."""
    course: str
    assignment: str            # the anchor (most-recently-due) assignment name
    due: str                   # its due date (display)
    rows: list = field(default_factory=list)  # [(student_display, student_key, css, label), ...]


@dataclass
class DashboardData:
    generated_at: datetime
    new_submissions: list[SubmissionRow] = field(default_factory=list)
    new_late: list[SubmissionRow] = field(default_factory=list)
    newly_due_missing: list[MissingRow] = field(default_factory=list)
    roster_tables: list = field(default_factory=list)   # per-course all-students status tables
    weekly_outstanding: list[MissingRow] = field(default_factory=list)
    include_weekly: bool = False
    status_grids: list[StatusGrid] = field(default_factory=list)
    details: list[SubmissionDetail] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    # When set, filename links open files in their native app via the local companion.
    opener_prefix: str = ""   # e.g. "http://127.0.0.1:8765/open?path="
    opener_token: str = ""
    avatars: dict = field(default_factory=dict)   # student_key -> Avatar
    avatars_dir: str = ""     # abs path to the avatars cache (where dropped photos are saved)
    assignment_pages: list = field(default_factory=list)  # per-assignment roster pages
    shortcuts_href: str = ""   # relative link to the Course Shortcuts page, if it was generated


def _e(s: str) -> str:
    return html.escape(str(s))


def _file_flag(late: bool, when: str = "") -> str:
    """A small on-time (✓) / late (L) marker shown right after a file, using the same colors
    as the status grid (green ✓ / orange L). A late file also shows *when* it was submitted,
    inline, so that time isn't lost when the student is kept in the on-time table."""
    if late:
        when_html = f" <span class='latewhen'>&mdash; {_e(when)}</span>" if when else ""
        return f" <span class='ffl' title='this file was submitted late'>L</span>{when_html}"
    return " <span class='ffok' title='this file was submitted on time'>✓</span>"


def _file_link(entry, opener_prefix: str = "", opener_token: str = "") -> str:
    """Render a file entry as a link that opens it via the companion, followed by an on-time/late
    flag for that file's attempt. ``entry`` is ``(display_name, abs_path[, late])``; the visible
    text is the original filename (no ``Last_First_username_`` prefix), the link still targets the
    full on-disk path."""
    name = path = ""
    late = False
    when = ""
    if isinstance(entry, (tuple, list)):
        name = entry[0] if entry else ""
        path = entry[1] if len(entry) > 1 else ""
        late = bool(entry[2]) if len(entry) > 2 else False
        when = entry[3] if len(entry) > 3 else ""
    else:
        name = entry
    flag = _file_flag(late, when)
    if path:
        try:
            file_uri = Path(path).as_uri()
        except (ValueError, OSError):
            file_uri = ""
        if opener_prefix:
            open_url = f"{opener_prefix}{quote(str(path))}&token={quote(opener_token)}"
            href = file_uri or "#"
            return (
                f'<a href="{_e(href)}" onclick="return bbOpen(\'{_e(open_url)}\')">'
                f"{_e(name)}</a>{flag}"
            )
        if file_uri:
            return f'<a href="{_e(file_uri)}">{_e(name)}</a>{flag}'
    return f"{_e(name)}{flag}"


_EMAIL_RE = re.compile(r"\(([^()]+@[^()]+)\)\s*$")


def _course_num_from_str(s: str) -> str:
    """Pull a short course designator (e.g. 'PHYS 220') from a course string."""
    m = re.search(r"[A-Z]{2,5}[ -]?\d{3}[A-Z]?", s or "")
    return m.group(0).replace("-", " ") if m else (s or "")


def _course_anchor(course_label: str) -> str:
    """A stable, URL-safe anchor id for a course's status grid (target of the Course-column links)."""
    slug = re.sub(r"[^a-z0-9]+", "-", (course_label or "").lower()).strip("-")
    return f"course-{slug or 'x'}"


def _course_link(course_label: str) -> str:
    """A course name that jumps to that course's grid in the Submission status section."""
    return (f"<a href='#{_course_anchor(course_label)}' class='courselink'>"
            f"{_e(course_label)}</a>")


def _avatar_img(av, extra_cls: str = "") -> str:
    """Render a student photo (data-URI <img>) or an initials badge. Each carries the student
    id (and photo path, if any) so the dashboard's JS can open it full-size on click or accept a
    photo dropped onto it."""
    if not av:
        return ""
    cls = ("avatar " + extra_cls).strip()
    data = ""
    if av.uid:
        data += f' data-uid="{_e(av.uid)}"'
    if av.path:
        data += f' data-avpath="{_e(av.path)}"'
    if av.data_uri:
        tip = " title=\"Click to view full size · drag a photo here to replace\"" if av.path else ""
        return f'<img class="{cls}" src="{av.data_uri}" alt=""{data}{tip}>'
    tip = " title=\"Drag a photo here to add one\"" if av.uid else ""
    return (f'<span class="{cls} initials" style="background:{_e(av.color)}"{data}{tip}>'
            f'{_e(av.initials)}</span>')


def _student_cell(display: str, key: str, course_str: str = "", avatars: dict = None) -> str:
    """Render a student as: an avatar (photo or initials), a name that focuses the dashboard
    (click), and — if the display contains an email in parentheses — the email as a separate
    mailto link (subject = the course number, body = 'Dear <first>,')."""
    avatar = _avatar_img((avatars or {}).get(key))
    m = _EMAIL_RE.search(display)
    name_part = display[:m.start()].rstrip() if m else display
    namelink = (
        f'<a href="#" class="snamelink" data-student="{_e(key)}" '
        f'data-sname="{_e(display)}">{_e(name_part)}</a>'
    )
    if not m:
        return f"{avatar}{namelink}"
    email = m.group(1).strip()
    given = name_part.split(",")[-1].strip() if "," in name_part else name_part
    mail = (f"mailto:{email}?subject={quote(_course_num_from_str(course_str))}"
            f"&body={quote('Dear ' + given + ',')}")
    return f'{avatar}{namelink} (<a href="{_e(mail)}" class="emlink">{_e(email)}</a>)'


def _submission_table(rows, opener_prefix: str = "", opener_token: str = "", avatars: dict = None,
                      apage_href_map: dict = None) -> str:
    if not rows:
        return "<p class='empty'>None.</p>"
    body = []
    for r in rows:
        files = (
            "<br>".join(_file_link(f, opener_prefix, opener_token) for f in r.files)
            if r.files else "<span class='empty'>—</span>"
        )
        body.append(
            f"<tr class='srow' data-student='{_e(r.student_key)}'>"
            f"<td>{_course_link(r.course)}</td><td>{_assignment_link(r.assignment, r.page_id, apage_href_map)}</td>"
            f"<td>{_student_cell(r.student, r.student_key, r.course, avatars)}</td>"
            f"<td>{_e(r.when)}</td><td class='files'>{files}</td></tr>"
        )
    return (
        "<table><thead><tr><th>Course</th><th>Assignment</th><th>Student</th>"
        "<th>Submitted</th><th>Files</th></tr></thead><tbody>"
        + "".join(body)
        + "</tbody></table>"
    )


def _roster_section(tables, avatars: dict = None) -> str:
    """The 'All students' overview: one table per course, each row tinted by that student's
    status on the course's most-recently-due assignment (red = not submitted, orange = late)."""
    if not tables:
        return ""
    legend = ("<p class='rosterlegend'>"
              "<span class='swatch s-miss'></span> not submitted &nbsp;&nbsp;"
              "<span class='swatch s-late'></span> late &nbsp;&nbsp;"
              "<span class='swatch'></span> on time</p>")
    blocks = []
    for t in tables:
        body = []
        for display, key, css, label in t.rows:
            cls = ("srow " + css).strip()
            body.append(
                f"<tr class='{cls}' data-student='{_e(key)}'>"
                f"<td>{_student_cell(display, key, t.course, avatars)}</td>"
                f"<td>{_e(label)}</td></tr>"
            )
        blocks.append(
            f"<h3 class='rostercourse'>{_course_link(t.course)} &nbsp;·&nbsp; {_e(t.assignment)} "
            f"<span class='rosterdue'>(due {_e(t.due)})</span></h3>"
            "<table class='rostertbl'><thead><tr><th>Student</th><th>Status</th></tr></thead>"
            f"<tbody>{''.join(body)}</tbody></table>"
        )
    return ("<h2 id='sec-roster'>All students — status on the most recent assignment</h2>"
            + legend + "".join(blocks))


def _xmail_link(mailto: str, title: str) -> str:
    """A small red ✕ that drafts a nudge email (same idea as the ✕ in the status grid)."""
    return f'<a href="{_e(mailto)}" class="xmail-inline" title="{_e(title)}">✕</a>'


def _missing_table(rows, avatars: dict = None, apage_href_map: dict = None) -> str:
    if not rows:
        return "<p class='empty'>None.</p>"
    body = []
    for r in rows:
        if r.students:
            parts = []
            for disp, key in r.students:
                cell = _student_cell(disp, key, r.course, avatars)
                mailto = r.student_mailtos.get(key)
                x = _xmail_link(mailto, "Email this student about the missing assignment") if mailto else ""
                parts.append(f'<span class="mstud" data-student="{_e(key)}">{cell}{x}</span>')
            spans = "<br>".join(parts)
        else:
            spans = "<span class='empty'>(none)</span>"
        # The group ✕ opens a separate, personalized draft per student (via the companion).
        # Its href is a plain mass mailto, used only as a fallback if the companion is off.
        group_x = (f'<a href="{_e(r.group_mailto)}" class="xmail-inline xmail-all" '
                   f'title="Email each missing student separately">✕</a>'
                   if r.group_mailto else "")
        body.append(
            f"<tr class='mrow'><td>{_course_link(r.course)}</td>"
            f"<td>{_assignment_link(r.assignment, r.page_id, apage_href_map)}</td>"
            f"<td>{_e(r.due)}</td><td class='nmiss'>{_e(len(r.students))}{group_x}</td>"
            f"<td class='files'>{spans}</td></tr>"
        )
    return (
        "<table><thead><tr><th>Course</th><th>Assignment</th><th>Due</th>"
        "<th># Missing</th><th>Students</th></tr></thead><tbody>"
        + "".join(body)
        + "</tbody></table>"
    )


def _status_cell(cell: GridCell, href_map: dict) -> str:
    if cell.status == "X":
        if cell.mailto:
            return (f'<td class="cell miss"><a href="{_e(cell.mailto)}" class="xmail" '
                    'title="Email this student about the missing assignment">✕</a></td>')
        return "<td class='cell miss'>✕</td>"
    if cell.status == "OK":
        inner = "<span class='ok'>✓</span>"
    elif cell.status == "L":
        inner = "<span class='late-cell'>L</span>"
    else:
        return "<td class='cell'></td>"  # nothing to show yet
    href = href_map.get(cell.detail_id)
    if href:
        inner = f"<a href='{_e(href)}' target='_blank' class='detaillink'>{inner}</a>"
    return f"<td class='cell'>{inner}</td>"


def _assignment_link(name: str, page_id: str, apage_href_map: dict = None) -> str:
    """The assignment name, linked to that assignment's own roster page when available
    (same target as the status-grid column headings; opens in the same tab)."""
    href = apage_href_map.get(page_id) if (apage_href_map and page_id) else None
    if href:
        return f"<a href='{_e(href)}' class='asglink'>{_e(name)}</a>"
    return _e(name)


def _asg_header(name: str, page_id: str, apage_href_map: dict = None) -> str:
    """A grid column heading, linked to that assignment's own roster page when available."""
    return f"<th class='asg'>{_assignment_link(name, page_id, apage_href_map)}</th>"


def _status_grid_html(grid: StatusGrid, href_map: dict, avatars: dict = None,
                      apage_href_map: dict = None) -> str:
    aids = grid.assignment_ids if grid.assignment_ids else [""] * len(grid.assignments)
    head = "".join(_asg_header(a, aid, apage_href_map)
                   for a, aid in zip(grid.assignments, aids))
    body = []
    for student, key, cells in grid.rows:
        tds = "".join(_status_cell(c, href_map) for c in cells)
        body.append(
            f"<tr class='srow' data-student='{_e(key)}'>"
            f"<td class='student'>{_student_cell(student, key, grid.course, avatars)}</td>{tds}</tr>"
        )
    gb_button = (
        f"<a class='gbbtn' href='{_e(grid.gradebook_url)}' target='_blank'>Online Gradebook</a>"
        if grid.gradebook_url else ""
    )
    caption = (f"<div class='gridcaption' id='{_course_anchor(grid.course)}'>"
               f"{_e(grid.course)}{gb_button}</div>")
    path_note = (
        f"<div class='pathnote'>Spreadsheet: {_e(grid.csv_path)}</div>" if grid.csv_path else ""
    )
    return (
        caption
        + "<table class='grid'><thead><tr><th class='student'>Student</th>"
        + head
        + "</tr></thead><tbody>"
        + "".join(body)
        + "</tbody></table>"
        + path_note
    )


def _gb_buttons_for(courses, gb_by_course: dict) -> str:
    """One green button per distinct course present (order preserved), each linking to that
    course's Blackboard gradebook. Labeled with just the course number (the surrounding
    'Online Gradebooks' bar supplies the context)."""
    seen: set = set()
    out = []
    for c in courses:
        url = gb_by_course.get(c)
        if not url or c in seen:
            continue
        seen.add(c)
        out.append(f"<a class='gbbtn' href='{_e(url)}' target='_blank'>"
                   f"{_e(_course_num_from_str(c))}</a>")
    return "".join(out)


def _status_section(data: DashboardData, href_map: dict, apage_href_map: dict = None) -> str:
    if not data.status_grids:
        return ""
    legend = (
        "<p class='legend'>"
        "<span class='ok'>✓</span> on time &nbsp;·&nbsp; "
        "<span class='late-cell'>L</span> late &nbsp;·&nbsp; "
        "<span class='miss'>✕</span> not submitted &nbsp;·&nbsp; "
        "blank = nothing due yet &nbsp;·&nbsp; "
        "<em>click an assignment heading for that whole assignment; click a ✓ or L for details; "
        "click a ✕ to email the student; click a name to focus one student</em></p>"
    )
    grids = "".join(_status_grid_html(g, href_map, data.avatars, apage_href_map)
                    for g in data.status_grids)
    return "<h2>Submission status</h2>" + legend + grids


_BBOPEN_SCRIPT = """<script>
  function bbOpen(u) { try { fetch(u, {mode:'no-cors'}).catch(function(){}); } catch(e){} return false; }
</script>"""

_FILTER_SCRIPT = """<script>
  // Hide any daily section (New submissions / New late / Missing) that has no visible rows —
  // whether it's empty for everyone or just empty for the currently-focused student.
  function bbUpdateSections() {
    document.querySelectorAll('section.rsec').forEach(function(sec){
      var visible = false;
      sec.querySelectorAll('tbody tr').forEach(function(r){
        if (r.style.display !== 'none') visible = true;
      });
      sec.style.display = visible ? '' : 'none';
    });
  }
  function bbFilter(key, name) {
    document.querySelectorAll('tr.srow').forEach(function(row){
      row.style.display = (row.getAttribute('data-student') === key) ? '' : 'none';
    });
    document.querySelectorAll('.mstud').forEach(function(s){
      s.style.display = (s.getAttribute('data-student') === key) ? '' : 'none';
    });
    document.querySelectorAll('tr.mrow').forEach(function(row){
      var match = false;
      row.querySelectorAll('.mstud').forEach(function(s){ if (s.getAttribute('data-student') === key) match = true; });
      row.style.display = match ? '' : 'none';
    });
    var bar = document.getElementById('filterbar');
    document.getElementById('filtername').textContent = name;
    bar.style.display = '';
    bbUpdateSections();
  }
  function bbShowAll() {
    document.querySelectorAll('tr.srow, tr.mrow, .mstud').forEach(function(el){ el.style.display = ''; });
    document.getElementById('filterbar').style.display = 'none';
    bbUpdateSections();
  }
  document.addEventListener('click', function(e){
    var t = e.target.closest ? e.target.closest('.snamelink') : null;
    if (t) { e.preventDefault(); bbFilter(t.getAttribute('data-student'), t.getAttribute('data-sname')); }
  });
  document.addEventListener('DOMContentLoaded', bbUpdateSections);
</script>"""

def _avatar_script(opener_prefix: str, opener_token: str, avatars_dir: str) -> str:
    """Client script: click a thumbnail to open the photo full-size (via the companion, so it
    opens in Preview), and drop an image file onto any thumbnail to save it as that student's
    photo. Needs the companion; without it, photos are just static images."""
    if not opener_prefix:
        return ""
    avatar_endpoint = opener_prefix.split("/open?")[0] + "/avatar"
    cfg = {
        "open": opener_prefix, "avatar": avatar_endpoint,
        "token": opener_token, "dir": avatars_dir,
    }
    return "<script>window.BB_AV=" + json.dumps(cfg) + ";" + """
    (function(){
      var C = window.BB_AV;
      function openFull(path){
        try { fetch(C.open + encodeURIComponent(path) + '&token=' + encodeURIComponent(C.token),
                    {mode:'no-cors'}).catch(function(){}); } catch(e){}
      }
      function extOf(file){
        var t = (file.type||'').toLowerCase();
        if (t.indexOf('png')>=0) return 'png';
        if (t.indexOf('gif')>=0) return 'gif';
        return 'jpg';
      }
      // Update every thumbnail for this student (grids + tables all show the same person).
      function applyPhoto(uid, dataUrl, path){
        document.querySelectorAll('.avatar').forEach(function(el){
          if (el.getAttribute('data-uid') !== uid) return;
          var img = el;
          if (el.tagName !== 'IMG'){
            img = document.createElement('img');
            img.className = el.className.replace('initials','').replace(/\\s+/g,' ').trim();
            img.setAttribute('data-uid', uid);
            img.alt = '';
            el.parentNode.replaceChild(img, el);
          }
          img.removeAttribute('style');
          img.src = dataUrl;
          if (path) img.setAttribute('data-avpath', path);
          img.title = 'Click to view full size \\u00b7 drag a photo here to replace';
        });
      }
      document.addEventListener('click', function(e){
        var a = e.target.closest ? e.target.closest('img.avatar[data-avpath]') : null;
        if (a){ e.preventDefault(); openFull(a.getAttribute('data-avpath')); }
      });
      function overAvatar(e){ return e.target.closest ? e.target.closest('.avatar[data-uid]') : null; }
      document.addEventListener('dragover', function(e){
        var a = overAvatar(e); if (a){ e.preventDefault(); a.classList.add('dropok'); }
      });
      document.addEventListener('dragleave', function(e){
        var a = overAvatar(e); if (a){ a.classList.remove('dropok'); }
      });
      document.addEventListener('drop', function(e){
        var a = overAvatar(e); if (!a) return;
        e.preventDefault(); a.classList.remove('dropok');
        var f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
        if (!f || f.type.indexOf('image/') !== 0) return;
        var uid = a.getAttribute('data-uid'), ext = extOf(f);
        var rd = new FileReader();
        rd.onload = function(){
          var predicted = C.dir ? (C.dir + '/' + uid + '.' + ext) : '';
          applyPhoto(uid, rd.result, predicted);   // show it immediately
          // Persist it (fire-and-forget; text/plain avoids a CORS preflight).
          try {
            fetch(C.avatar + '?token=' + encodeURIComponent(C.token) +
                  '&uid=' + encodeURIComponent(uid) + '&ext=' + ext,
                  {method:'POST', mode:'no-cors', body: new Blob([f], {type:'text/plain'})})
              .catch(function(){});
          } catch(e){}
        };
        rd.readAsDataURL(f);
      });
    })();
    </script>"""


def _group_mail_script(opener_prefix: str, opener_token: str) -> str:
    """Client script: clicking the ✕ in the '# Missing' column opens a SEPARATE, personalized
    email draft for each missing student in that row (routed through the companion's ``open``,
    so every student gets their own draft — not one mass email). Needs the companion; without
    it the ✕ falls back to its plain mass-mailto href."""
    if not opener_prefix:
        return ""
    mail_endpoint = opener_prefix.split("/open?")[0] + "/mail"
    cfg = {"mail": mail_endpoint, "token": opener_token}
    return "<script>window.BB_MAIL=" + json.dumps(cfg) + ";" + """
    (function(){
      var C = window.BB_MAIL;
      function draft(mailtoUrl){
        try {
          fetch(C.mail + '?token=' + encodeURIComponent(C.token) +
                '&url=' + encodeURIComponent(mailtoUrl), {mode:'no-cors'}).catch(function(){});
        } catch(e){}
      }
      document.addEventListener('click', function(e){
        var a = e.target.closest ? e.target.closest('a.xmail-all') : null;
        if (!a) return;
        e.preventDefault();
        var tr = a.closest('tr');
        if (!tr) return;
        var links = tr.querySelectorAll('.mstud a.xmail-inline');
        var i = 0;
        (function next(){
          if (i >= links.length) return;
          var href = links[i].getAttribute('href'); i++;
          if (href && href.indexOf('mailto:') === 0) draft(href);
          setTimeout(next, 400);   // stagger so Mail opens a distinct draft per student
        })();
      });
    })();
    </script>"""


_STYLE = """<style>
  body { font-family: -apple-system, system-ui, sans-serif; margin: 2rem; color: #1a1a1a; }
  h1 { font-size: 1.5rem; margin-bottom: .25rem; }
  .sub { color: #555; margin-top: 0; }
  h2 { font-size: 1.1rem; margin-top: 2rem; border-bottom: 2px solid #eee; padding-bottom: .25rem; }
  table { border-collapse: collapse; width: 100%; margin-top: .5rem; font-size: .9rem; }
  th, td { text-align: left; padding: .4rem .6rem; border-bottom: 1px solid #eee; vertical-align: top; }
  th { background: #f6f6f6; }
  .late { color: #b00020; font-weight: 600; }
  .ontime { color: #2e7d32; }
  .empty { color: #999; }
  .files { font-size: .85rem; color: #333; }
  .err { color: #b00020; }
  .xmail-inline { color: #c1121f; font-weight: 800; text-decoration: none; cursor: pointer;
                  margin-left: .4rem; font-size: 1.4rem; line-height: 1; vertical-align: middle; }
  .xmail-inline:hover { opacity: .65; }
  .sub a.countlink { color: #0a58ca; text-decoration: none; font-weight: 600; }
  .sub a.countlink:hover { text-decoration: underline; }
  td.nmiss { white-space: nowrap; }
  .snamelink { color: #0a58ca; text-decoration: none; cursor: pointer; }
  .snamelink:hover { text-decoration: underline; }
  .emlink { color: #0a58ca; text-decoration: none; }
  .emlink:hover { text-decoration: underline; }
  .legend { font-size: .85rem; color: #555; margin: .25rem 0 1rem; }
  .legend .ok { color: #2e7d32; font-weight: 800; }
  .legend .miss { color: #c1121f; font-weight: 800; }
  .legend .late-cell { color: #b8860b; font-weight: 800; }
  .gridcaption { font-weight: 600; margin-top: 1.25rem; }
  .gbbtn { display: inline-block; margin-left: .9rem; padding: .35rem 1rem; font-size: 1rem;
           font-weight: 700; color: #fff; background: #2e7d32; border-radius: 7px;
           text-decoration: none; vertical-align: middle; box-shadow: 0 1px 2px rgba(0,0,0,.15); }
  .gbbtn:hover { background: #1b5e20; }
  .gbbar { margin: .6rem 0 1.1rem; display: flex; flex-wrap: wrap; align-items: center;
           row-gap: .5rem; }
  .gbbar .gblabel { font-weight: 700; font-size: 1.05rem; }
  .gbbar .gbbtn:first-of-type { margin-left: .6rem; }
  table.grid { width: auto; min-width: 50%; }
  table.grid th.asg { writing-mode: vertical-rl; text-orientation: mixed; transform: rotate(180deg);
                      white-space: nowrap; vertical-align: bottom; padding: .5rem .35rem; font-weight: 600; }
  table.grid th.asg a.asglink { color: #0a58ca; text-decoration: none; }
  table.grid th.asg a.asglink:hover { text-decoration: underline; }
  .backlink { margin: 0 0 1rem; }
  .backlink a { color: #0a58ca; text-decoration: none; font-weight: 600; }
  .backlink a:hover { text-decoration: underline; }
  .topnav { margin: .6rem 0 .2rem; }
  .topnav .gbbtn { margin-left: 0; }
  a.asglink { color: #0a58ca; text-decoration: none; }
  a.asglink:hover { text-decoration: underline; }
  a.courselink { color: #0a58ca; text-decoration: none; }
  a.courselink:hover { text-decoration: underline; }
  .gridcaption { scroll-margin-top: 1rem; }
  table.grid th.student, table.grid td.student { text-align: left; white-space: nowrap;
                      position: sticky; left: 0; background: #fff; font-weight: 500; }
  table.grid td.cell { text-align: center; min-width: 2.2rem; font-size: 1.1rem; }
  table.grid td.miss { color: #c1121f; font-weight: 800; font-size: 1.45rem; line-height: 1; }
  table.grid td.miss a.xmail { color: inherit; text-decoration: none; cursor: pointer; }
  table.grid td .ok { color: #2e7d32; font-weight: 800; font-size: 1.35rem; }
  table.grid td .late-cell { color: #b8860b; font-weight: 800; }
  .detaillink { text-decoration: none; }
  .pathnote { font-size: .8rem; color: #888; margin: .25rem 0 .5rem; }
  .nodue { color: #2e7d32; font-size: 1.35rem; font-weight: 700; margin: .5rem 0; }
  .files a { color: #0a58ca; text-decoration: none; }
  .files a:hover { text-decoration: underline; }
  .files a.xmail-inline { color: #c1121f; }  /* keep the ✕ red inside the Students column */
  .ffok { color: #2e7d32; font-weight: 800; }   /* per-file "on time" flag (green ✓) */
  .ffl  { color: #b8860b; font-weight: 800; }   /* per-file "late" flag (orange L) */
  .latewhen { color: #b8860b; font-size: .85em; }  /* a late file's submission time, inline */
  .dashnav { display: flex; justify-content: space-between; align-items: center; margin-bottom: .5rem; }
  .dnav-left { text-align: left; } .dnav-right { text-align: right; }
  .dnav-link { color: #0a58ca; text-decoration: none; font-weight: 600; }
  .dnav-link:hover { text-decoration: underline; }
  .rostercourse { font-size: 1.05rem; margin: 1rem 0 .35rem; }
  .rosterdue { color: #666; font-weight: 400; font-size: .9rem; }
  table.rostertbl { border-collapse: collapse; margin-bottom: .5rem; }
  table.rostertbl td, table.rostertbl th { padding: .3rem .7rem; border-bottom: 1px solid #eee; text-align: left; }
  tr.rowmiss td { background: #fdeaea; }   /* not submitted (red) */
  tr.rowlate td { background: #fff4e0; }   /* late (orange) */
  .rosterlegend { color: #444; font-size: .9rem; margin: .25rem 0 .5rem; }
  .swatch { display: inline-block; width: .9rem; height: .9rem; vertical-align: middle;
            border: 1px solid #ccc; margin-right: .2rem; }
  .swatch.s-miss { background: #fdeaea; } .swatch.s-late { background: #fff4e0; }
  #filterbar { position: sticky; top: 0; background: #fffae6; border: 1px solid #e6d98a;
               padding: .5rem .75rem; margin-bottom: 1rem; border-radius: 4px; font-size: .95rem; }
  #filterbar a { color: #0a58ca; }
  pre { background: #f6f6f6; padding: .75rem; border-radius: 4px; overflow-x: auto; white-space: pre-wrap; }
  .avatar { width: 26px; height: 26px; border-radius: 50%; object-fit: cover;
            vertical-align: middle; margin-right: .45rem; display: inline-block; }
  .avatar.initials { color: #fff; font-weight: 700; font-size: .75rem; line-height: 26px;
                     text-align: center; text-transform: uppercase; }
  .avatar.lg { width: 72px; height: 72px; margin-right: 1rem; }
  .avatar.lg.initials { font-size: 1.6rem; line-height: 72px; }
  img.avatar[data-avpath] { cursor: zoom-in; }
  .avatar[data-uid] { transition: box-shadow .1s, outline .1s; }
  .avatar.dropok { outline: 3px solid #2e7d32; outline-offset: 1px;
                   box-shadow: 0 0 0 4px rgba(46,125,50,.25); }
  .detailhead { display: flex; align-items: center; margin-bottom: .5rem; }
  .detailhead h1 { margin: 0; }
  .detailhead .sub { margin: .2rem 0 0; }
</style>"""


def _detail_email_link(detail: SubmissionDetail) -> str:
    if not detail.email:
        return ""
    m = _EMAIL_RE.search(detail.student)
    name_part = detail.student[:m.start()].rstrip() if m else detail.student
    given = name_part.split(",")[-1].strip() if "," in name_part else name_part
    mail = (f"mailto:{detail.email}?subject={quote(_course_num_from_str(detail.course))}"
            f"&body={quote('Dear ' + given + ',')}")
    return f'<a href="{_e(mail)}" class="emlink">{_e(detail.email)}</a>'


def _render_detail(detail: SubmissionDetail, opener_prefix: str, opener_token: str) -> str:
    files_html = (
        "<br>".join(_file_link(f, opener_prefix, opener_token) for f in detail.files)
        if detail.files else "<span class='empty'>(no files)</span>"
    )
    text_html = (
        f"<h2>Typed submission</h2><pre>{_e(detail.text)}</pre>" if detail.text else ""
    )
    status = "<span class='late'>LATE</span>" if detail.late else "<span class='ontime'>On time</span>"
    title = f"{detail.student} — {detail.assignment}"
    avatar_html = _avatar_img(detail.avatar, "lg")
    header = (
        f"<div class='detailhead'>{avatar_html}<div><h1>{_e(detail.student)}</h1>"
        f"<p class='sub'>{_detail_email_link(detail)}</p></div></div>"
        if avatar_html else
        f"<h1>{_e(detail.student)}</h1><p class='sub'>{_detail_email_link(detail)}</p>"
    )
    return (
        "<!doctype html><html lang='en'><head><meta charset='utf-8'>"
        "<meta name='viewport' content='width=device-width, initial-scale=1'>"
        f"<title>{_e(title)}</title>{_STYLE}{_BBOPEN_SCRIPT}</head><body>"
        f"{header}"
        "<table><tbody>"
        f"<tr><th>Course</th><td>{_e(detail.course)}</td></tr>"
        f"<tr><th>Assignment</th><td>{_e(detail.assignment)}</td></tr>"
        f"<tr><th>Status</th><td>{status}</td></tr>"
        f"<tr><th>Submitted</th><td>{_e(detail.when)}</td></tr>"
        f"<tr><th>Due</th><td>{_e(detail.due)}</td></tr>"
        f"<tr><th>Files</th><td class='files'>{files_html}</td></tr>"
        "</tbody></table>"
        f"{text_html}"
        "</body></html>"
    )


def _assignment_status_cell(row: "AssignmentRow") -> str:
    if row.status == "OK":
        return "<span class='ontime'>on time</span>"
    if row.status == "L":
        return "<span class='late'>LATE</span>"
    if row.status == "X":
        if row.mailto:
            return _xmail_link(row.mailto, "Email this student about the missing assignment")
        return "<span class='xmail-inline' style='cursor:default'>✕</span>"
    return "<span class='empty'>—</span>"


def _render_assignment_page(page: "AssignmentPage", opener_prefix: str, opener_token: str,
                            avatars: dict = None, back_href: str = "") -> str:
    """One page per assignment: a row for every student (like the New submissions table) with
    their status, submission time, and file links — plus the red ✕ + nudge email for missing."""
    body = []
    for r in page.rows:
        files = ("<br>".join(_file_link(f, opener_prefix, opener_token) for f in r.files)
                 if r.files else "<span class='empty'>—</span>")
        body.append(
            f"<tr class='srow' data-student='{_e(r.student_key)}'>"
            f"<td>{_student_cell(r.student, r.student_key, page.course, avatars)}</td>"
            f"<td>{_assignment_status_cell(r)}</td>"
            f"<td>{_e(r.when)}</td>"
            f"<td class='files'>{files}</td></tr>"
        )
    table = ("<table><thead><tr><th>Student</th><th>Status</th><th>Submitted</th>"
             "<th>Files</th></tr></thead><tbody>" + "".join(body) + "</tbody></table>")
    gb = (f"<a class='gbbtn' href='{_e(page.gradebook_url)}' target='_blank'>Online Gradebook</a>"
          if page.gradebook_url else "")
    title = f"{page.assignment} — {page.course}"
    back = (f"<p class='backlink'><a href='{_e(back_href)}'>&larr; Back to the dashboard</a></p>"
            if back_href else "")
    return (
        "<!doctype html><html lang='en'><head><meta charset='utf-8'>"
        "<meta name='viewport' content='width=device-width, initial-scale=1'>"
        f"<title>{_e(title)}</title>{_STYLE}{_BBOPEN_SCRIPT}</head><body>"
        f"{back}"
        f"<h1>{_e(page.assignment)}{gb}</h1>"
        f"<p class='sub'>{_e(page.course)} &nbsp;·&nbsp; Due {_e(page.due)}</p>"
        + table +
        "</body></html>"
    )


def dashboard_stamp(dt) -> str:
    """Filename stamp for one run: ``YYYY-MM-DD__HH-MM`` (24-hour; a double underscore separates
    the date from the time for readability). Timestamping (not just the date) means re-running on
    the same day keeps each run as its own snapshot instead of overwriting the earlier one; it
    still sorts chronologically so "latest" logic works."""
    return dt.strftime("%Y-%m-%d__%H-%M")


_NEXT_MARKER = "<!--NEXTLINK-->"  # placeholder a later run patches with the "Next Dashboard" link


def _dashboard_nav(prev_name: str) -> str:
    """Top nav bar: 'Previous Dashboard' (left) links to the prior snapshot; 'Next Dashboard'
    (right) is a placeholder — a static page can't know its successor at write time, so the run
    that creates the *next* dashboard patches this marker (see ``_patch_next_link``)."""
    prev = (f"<a href=\"{quote(prev_name)}\" class='dnav-link'>&larr; Previous Dashboard</a>"
            if prev_name else "")
    return (f"<div class='dashnav'><div class='dnav-left'>{prev}</div>"
            f"<div class='dnav-right'>{_NEXT_MARKER}</div></div>")


def _patch_next_link(prev_path: Path, new_name: str) -> None:
    """Point the prior dashboard's 'Next Dashboard' placeholder at the newly-written one."""
    try:
        text = prev_path.read_text(encoding="utf-8")
    except OSError:
        return
    if _NEXT_MARKER not in text:
        return  # a pre-feature dashboard (no placeholder) — leave it as-is
    link = f"<a href=\"{quote(new_name)}\" class='dnav-link'>Next Dashboard &rarr;</a>"
    try:
        prev_path.write_text(text.replace(_NEXT_MARKER, link), encoding="utf-8")
    except OSError:
        pass


def prune_old_dashboards(dashboard_dir: Path, keep_stamp: str) -> None:
    """Delete every snapshot except ``keep_stamp`` (used when keep_previous_dashboards=false)."""
    keep_html = f"{keep_stamp}.html"
    for p in dashboard_dir.glob("*.html"):
        if p.name in (keep_html, "course_shortcuts.html"):
            continue
        try:
            p.unlink()
        except OSError:
            pass
    for sub in ("details", "assignments"):
        d = dashboard_dir / sub
        if d.is_dir():
            for child in d.iterdir():
                if child.name != keep_stamp:
                    shutil.rmtree(child, ignore_errors=True)


def render(data: DashboardData, dashboard_dir: Path, keep_previous: bool = True) -> Path:
    stamp = dashboard_stamp(data.generated_at)
    title = f"Blackboard Offline Interactive Dashboard — {data.generated_at.strftime('%Y-%m-%d %H:%M')}"
    dashboard_dir.mkdir(parents=True, exist_ok=True)

    # 1) Write a detail page per submission and build a detail_id -> file:// URL map. The
    # per-run subfolders use the same stamp, so every run is a self-contained snapshot.
    href_map: dict[str, str] = {}
    if data.details:
        details_dir = dashboard_dir / "details" / stamp
        details_dir.mkdir(parents=True, exist_ok=True)
        for d in data.details:
            page = _render_detail(d, data.opener_prefix, data.opener_token)
            out = details_dir / f"{d.detail_id}.html"
            out.write_text(page, encoding="utf-8")
            href_map[d.detail_id] = out.resolve().as_uri()  # absolute file:// (robust to relative dirs)

    # 1b) Write a per-assignment roster page and map page_id -> file:// URL (for the grid headers).
    apage_href_map: dict[str, str] = {}
    if data.assignment_pages:
        apages_dir = dashboard_dir / "assignments" / stamp
        apages_dir.mkdir(parents=True, exist_ok=True)
        # Relative link back to this run's main dashboard (dashboard_dir/<stamp>.html).
        back_href = f"../../{stamp}.html"
        for p in data.assignment_pages:
            page_html = _render_assignment_page(p, data.opener_prefix, data.opener_token,
                                                data.avatars, back_href)
            out = apages_dir / f"{p.page_id}.html"
            out.write_text(page_html, encoding="utf-8")
            apage_href_map[p.page_id] = out.resolve().as_uri()

    n_missing = sum(len(m.students) for m in data.newly_due_missing)
    # The three groups are disjoint by construction (main.py places each student in exactly one
    # of new_submissions / new_late by overall status), so the counts just measure each list.
    counts_html = (
        f"<b>New Submissions:</b> <a class='countlink' href='#sec-new'>{len(data.new_submissions)} on time</a> - "
        f"<a class='countlink' href='#sec-late'>{len(data.new_late)} late</a> - "
        f"<a class='countlink' href='#sec-missing'>{n_missing} missing</a>"
    )

    if data.newly_due_missing:
        newly_due_html = _missing_table(data.newly_due_missing, data.avatars, apage_href_map)
    else:
        newly_due_html = "<p class='nodue'>No assignments were due last night.</p>"

    weekly_section = ""
    if data.include_weekly:
        weekly_section = (
            "<h2>Weekly roundup — outstanding (still-missing) submissions</h2>"
            + _missing_table(data.weekly_outstanding, data.avatars, apage_href_map)
        )

    status_section = _status_section(data, href_map, apage_href_map)

    # A single "Online Gradebooks" bar near the top: one button per course in the dashboard
    # (replaces the old per-section gradebook buttons that repeated next to each heading).
    gb_by_course = {g.course: g.gradebook_url for g in data.status_grids if g.gradebook_url}
    gb_order = [g.course for g in data.status_grids if g.gradebook_url]
    online_gb = _gb_buttons_for(gb_order, gb_by_course)
    gb_bar = (f"<p class='gbbar'><span class='gblabel'>Online Gradebooks</span>{online_gb}</p>"
              if online_gb else "")

    errors_section = ""
    if data.errors:
        items = "".join(f"<li>{_e(err)}</li>" for err in data.errors)
        errors_section = f"<h2 class='err'>Warnings</h2><ul class='err'>{items}</ul>"

    # Previous/Next navigation. "Previous" = the newest snapshot that already exists (computed
    # before this run's file is written). "Next" is a placeholder patched into the prior file
    # below. Both are only meaningful when previous dashboards are kept.
    prev_path = None
    if keep_previous:
        existing = sorted(p for p in dashboard_dir.glob("*.html")
                          if p.name != "course_shortcuts.html")
        prev_path = existing[-1] if existing else None
    nav_html = _dashboard_nav(prev_path.name if prev_path else "") if keep_previous else ""

    op, ot = data.opener_prefix, data.opener_token
    parts = [
        "<!doctype html><html lang='en'><head><meta charset='utf-8'>",
        "<meta name='viewport' content='width=device-width, initial-scale=1'>",
        f"<title>{_e(title)}</title>", _STYLE, _BBOPEN_SCRIPT, _FILTER_SCRIPT,
        _avatar_script(data.opener_prefix, data.opener_token, data.avatars_dir),
        _group_mail_script(data.opener_prefix, data.opener_token), "</head><body>",
        nav_html,
        "<div id='filterbar' style='display:none'>Showing only <b><span id='filtername'></span></b>"
        " — <a href='#' onclick='bbShowAll();return false;'>Show all students</a></div>",
        "<h1>Blackboard Offline Interactive Dashboard</h1>",
        f"<p class='sub'>Last Updated {_e(data.generated_at.strftime('%A, %B %d, %Y at %I:%M %p'))}"
        f"<br>{counts_html}</p>",
        gb_bar,
        (f"<p class='topnav'><a class='gbbtn' href='{_e(data.shortcuts_href)}'>Course Shortcuts &rarr;</a></p>"
         if data.shortcuts_href else ""),
        # Missing first, then the all-students roster overview, then the submitted tables.
        "<section class='rsec'>",
        f"<h2 id='sec-missing'>Missing — assignments that just came due</h2>", newly_due_html,
        "</section>",
        (f"<section class='rsec'>{_roster_section(data.roster_tables, data.avatars)}</section>"
         if data.roster_tables else ""),
        "<section class='rsec'>",
        f"<h2 id='sec-new'>New on time submissions</h2>", _submission_table(data.new_submissions, op, ot, data.avatars, apage_href_map),
        "</section><section class='rsec'>",
        f"<h2 id='sec-late'>New late submissions</h2>", _submission_table(data.new_late, op, ot, data.avatars, apage_href_map),
        "</section>",
        weekly_section, status_section, errors_section,
        "</body></html>",
    ]
    out = dashboard_dir / f"{stamp}.html"
    out.write_text("".join(parts), encoding="utf-8")
    if keep_previous:
        if prev_path is not None:
            _patch_next_link(prev_path, out.name)
    else:
        prune_old_dashboards(dashboard_dir, stamp)
    return out
