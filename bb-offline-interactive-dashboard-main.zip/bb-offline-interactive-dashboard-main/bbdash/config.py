"""Configuration loading.

Credentials come from a JSON config file (default ``~/.bbdash/config.json``) and
may be overridden by environment variables. The config file should be readable only by
you (the loader enforces 0600 permissions on it where possible).
"""
from __future__ import annotations

import json
import os
import stat
from dataclasses import dataclass, field
from pathlib import Path

DEFAULT_CONFIG_PATH = Path.home() / ".bbdash" / "config.json"

# Default bodies for the "you're missing an assignment" nudge emails. Placeholders
# {first_name}, {assignment}, and {course_number} are filled in per student; any other
# text is used verbatim. New = an assignment that just came due; old = a still-missing
# older one (so its wording doesn't inaccurately say "last night").
DEFAULT_MISSING_EMAIL_NEW = (
    "Hi {first_name},\n\n"
    "I see that you didn't get {assignment} turned in last night for {course_number}. "
    "Be sure to get that turned in. If you have questions, please come see me.\n\n"
    "Best wishes,"
)
DEFAULT_MISSING_EMAIL_OLD = (
    "Hi {first_name},\n\n"
    "{assignment} is still missing for {course_number}. "
    "Be sure to get that turned in. If you have questions, please come see me.\n\n"
    "Best wishes,"
)


class ConfigError(Exception):
    pass


@dataclass
class Config:
    # --- Required: identifies and authenticates against your Blackboard instance ---
    domain: str                 # e.g. "blackboard.fmarion.edu"
    application_key: str        # OAuth Application Key from developer.blackboard.com
    application_secret: str     # OAuth Application Secret (keep private!)

    # --- Strongly recommended: scope discovery to the courses you teach ---
    instructor_username: str = ""   # your Blackboard username, e.g. "lengelhardt"

    # --- Optional behavior ---
    output_dir: Path = field(default_factory=lambda: Path.home() / "BB Offline Dashboard")
    data_dir: Path = field(default_factory=lambda: Path.home() / ".bbdash")
    # Restrict which courses are watched. term_filter is the recommended default: semester
    # names (e.g. ["Fall 2026"]), matched case-insensitively against each course's term.
    # course_filter is the alternative: specific course IDs or codes. Empty = all courses.
    # If both are set, a course must satisfy both.
    term_filter: list[str] = field(default_factory=list)
    course_filter: list[str] = field(default_factory=list)  # course IDs/codes; empty = all
    # Day to emit the outstanding-missing roundup. In the config JSON this may be a day NAME
    # ("Monday"/"Mon", case-insensitive) or an int 0=Mon … 6=Sun; it's normalized to an int here.
    weekly_roundup_weekday: int = 0
    # Bodies for the missing-assignment nudge emails. Placeholders {first_name}, {assignment},
    # {course_number} are substituted per student. "new" = just came due; "old" = still missing
    # from before. Edit these to change the wording; leave a placeholder out to omit it.
    missing_email_new: str = DEFAULT_MISSING_EMAIL_NEW
    missing_email_old: str = DEFAULT_MISSING_EMAIL_OLD
    # Local "open file" companion: dashboard links open files in their native app via this port.
    # Set to 0 to disable (dashboard falls back to plain file:// links).
    opener_port: int = 8765
    # Used to show a student's email after their name. If the API doesn't return an email,
    # it's constructed as <username>@<student_email_domain>.
    student_email_domain: str = "g.fmarion.edu"
    # macOS app to open the finished dashboard in (Safari handles the companion links most
    # reliably). Set to "" to use your system default browser instead.
    dashboard_browser: str = "Safari"
    # Keep every run's dashboard as its own timestamped snapshot (enabling the Previous/Next
    # links between them). Set false to keep only the latest — each run then deletes the earlier
    # dashboards (and their detail/assignment pages).
    keep_previous_dashboards: bool = True
    # Files with these extensions open in `code_editor_app` (via the companion); everything
    # else opens in its normal default app. Set code_editor_app to "" to disable routing.
    code_editor_app: str = "Visual Studio Code"
    code_extensions: list[str] = field(default_factory=lambda: [".py", ".pyw", ".ipynb"])
    # In the comment-stripped copy, also remove docstrings (module/class/function
    # triple-quoted documentation). Set to false to keep docstrings.
    strip_docstrings: bool = True
    # Show a "Run now / Skip today / Wait until <time>" dialog before each run.
    # Set to false for fully unattended runs (no dialog).
    launch_prompt: bool = True
    # URL template for the "--gradebook" shortcut. {base} = instance URL, {course_id} = pk1.
    # If this doesn't land on the gradebook for your Ultra version, just edit the path here.
    gradebook_url_template: str = "{base}/ultra/courses/{course_id}/grades?gradebookView=list"
    # URL template for the "Course Content" shortcut (jumps to the course's content outline,
    # handy for uploading class notes). Same {base}/{course_id} substitutions as the gradebook.
    content_url_template: str = "{base}/ultra/courses/{course_id}/outline"
    # Optional custom icon for the launch dialog (path to a .png or .icns). Empty = default;
    # but ~/.bbdash/dialog_icon.png is auto-detected and used if present.
    dialog_icon: str = ""
    # Show student photos in the dashboard (real Blackboard photo where available, else a
    # colored initials badge). Photos are cached locally in data_dir/avatars.
    student_photos: bool = True

    @property
    def base_url(self) -> str:
        d = self.domain.strip()
        if not d.startswith("http"):
            d = "https://" + d
        return d.rstrip("/")

    @property
    def state_path(self) -> Path:
        return self.data_dir / "state.json"

    @property
    def token_cache_path(self) -> Path:
        return self.data_dir / "token_cache.json"

    @property
    def dashboard_dir(self) -> Path:
        # Generated HTML lives with the submissions (a visible folder), not in the hidden
        # data_dir — so everything the instructor looks at is in one place.
        return self.output_dir / "Dashboard"

    @property
    def opener_token_path(self) -> Path:
        return self.data_dir / "opener.token"

    def ensure_dirs(self) -> None:
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.dashboard_dir.mkdir(parents=True, exist_ok=True)
        self.output_dir.mkdir(parents=True, exist_ok=True)


def _expand(p) -> Path:
    return Path(os.path.expanduser(str(p)))


def _strip_jsonc(text: str) -> str:
    """Remove ``//`` line comments and ``/* */`` block comments so the config may be commented
    (JSONC). Comment markers inside string values are left alone, so a "https://..." URL or a
    body with "//" in it is never damaged."""
    out = []
    i, n = 0, len(text)
    in_str = False
    while i < n:
        ch = text[i]
        if in_str:
            out.append(ch)
            if ch == "\\" and i + 1 < n:      # keep an escaped char (e.g. \" or \\) verbatim
                out.append(text[i + 1])
                i += 2
                continue
            if ch == '"':
                in_str = False
            i += 1
            continue
        if ch == '"':                          # JSON strings are always double-quoted
            in_str = True
            out.append(ch)
            i += 1
            continue
        if ch == "/" and i + 1 < n and text[i + 1] == "/":
            i += 2
            while i < n and text[i] not in ("\n", "\r"):
                i += 1
            continue
        if ch == "/" and i + 1 < n and text[i + 1] == "*":
            i += 2
            while i + 1 < n and not (text[i] == "*" and text[i + 1] == "/"):
                i += 1
            i += 2
            continue
        out.append(ch)
        i += 1
    return "".join(out)


_WEEKDAYS = {
    "monday": 0, "mon": 0,
    "tuesday": 1, "tue": 1, "tues": 1,
    "wednesday": 2, "wed": 2, "weds": 2,
    "thursday": 3, "thu": 3, "thur": 3, "thurs": 3,
    "friday": 4, "fri": 4,
    "saturday": 5, "sat": 5,
    "sunday": 6, "sun": 6,
}


def _parse_weekday(value) -> int:
    """Accept a weekday as an int (0=Mon … 6=Sun) or a name ('Monday'/'Mon', case-insensitive).
    Anything unrecognized falls back to 0 (Monday)."""
    if isinstance(value, bool):          # bool is an int subclass; don't treat True/False as 1/0
        return 0
    if isinstance(value, int):
        return value if 0 <= value <= 6 else 0
    if isinstance(value, str):
        s = value.strip().lower()
        if s in _WEEKDAYS:
            return _WEEKDAYS[s]
        if s.lstrip("-").isdigit() and 0 <= int(s) <= 6:
            return int(s)
    return 0


def load_config(path: str | os.PathLike | None = None, require_credentials: bool = True) -> Config:
    """Load config from a JSON file, then apply environment-variable overrides.

    Environment overrides (handy for testing / CI):
      BB_DOMAIN, BB_APPLICATION_KEY, BB_APPLICATION_SECRET, BB_INSTRUCTOR_USERNAME

    ``require_credentials=False`` allows loading with the Blackboard domain/key/secret
    absent — used by the standalone "open file" companion, which only needs output_dir,
    data_dir, and opener_port and never contacts Blackboard.
    """
    cfg_path = _expand(path) if path else DEFAULT_CONFIG_PATH
    data: dict = {}
    if cfg_path.exists():
        _warn_if_world_readable(cfg_path)
        try:
            data = json.loads(_strip_jsonc(cfg_path.read_text()))
        except json.JSONDecodeError as e:
            raise ConfigError(f"Config file {cfg_path} is not valid JSON: {e}") from e

    # Environment overrides take precedence.
    env_map = {
        "domain": "BB_DOMAIN",
        "application_key": "BB_APPLICATION_KEY",
        "application_secret": "BB_APPLICATION_SECRET",
        "instructor_username": "BB_INSTRUCTOR_USERNAME",
    }
    for field_name, env_name in env_map.items():
        if os.environ.get(env_name):
            data[field_name] = os.environ[env_name]

    if require_credentials:
        missing = [k for k in ("domain", "application_key", "application_secret") if not data.get(k)]
        if missing:
            raise ConfigError(
                "Missing required config value(s): "
                + ", ".join(missing)
                + f".\nProvide them in {cfg_path} (see config.example.json) "
                "or via environment variables."
            )

    return Config(
        domain=data.get("domain", ""),
        application_key=data.get("application_key", ""),
        application_secret=data.get("application_secret", ""),
        instructor_username=data.get("instructor_username", ""),
        output_dir=_expand(data.get("output_dir", Path.home() / "BB Offline Dashboard")),
        data_dir=_expand(data.get("data_dir", Path.home() / ".bbdash")),
        term_filter=list(data.get("term_filter", [])),
        course_filter=list(data.get("course_filter", [])),
        weekly_roundup_weekday=_parse_weekday(data.get("weekly_roundup_weekday", 0)),
        missing_email_new=data.get("missing_email_new", DEFAULT_MISSING_EMAIL_NEW),
        missing_email_old=data.get("missing_email_old", DEFAULT_MISSING_EMAIL_OLD),
        opener_port=int(data.get("opener_port", 8765)),
        student_email_domain=data.get("student_email_domain", "g.fmarion.edu"),
        dashboard_browser=data.get("dashboard_browser", "Safari"),
        keep_previous_dashboards=bool(data.get("keep_previous_dashboards", True)),
        code_editor_app=data.get("code_editor_app", "Visual Studio Code"),
        code_extensions=list(data.get("code_extensions", [".py", ".pyw", ".ipynb"])),
        strip_docstrings=bool(data.get("strip_docstrings", True)),
        launch_prompt=bool(data.get("launch_prompt", True)),
        gradebook_url_template=data.get(
            "gradebook_url_template", "{base}/ultra/courses/{course_id}/grades?gradebookView=list"),
        content_url_template=data.get(
            "content_url_template", "{base}/ultra/courses/{course_id}/outline"),
        dialog_icon=data.get("dialog_icon", ""),
        student_photos=bool(data.get("student_photos", True)),
    )


def _warn_if_world_readable(path: Path) -> None:
    # POSIX permission bits are meaningless on Windows: chmod can't clear the group/other
    # read bits (stat always reports 0o666), so this check would warn on every run and tell
    # the user to run a `chmod` that doesn't exist there. Access is governed by NTFS ACLs and
    # the file lives in the user's private profile, so skip the warning on Windows.
    if os.name == "nt":
        return
    try:
        mode = path.stat().st_mode
        if mode & (stat.S_IRGRP | stat.S_IROTH):
            print(
                f"[warning] {path} is readable by other users. "
                f"Run: chmod 600 {path}"
            )
    except OSError:
        pass
