# ARCHITECTURE & SECURITY — for institutional review

**Audience:** university information‑security and Blackboard administration staff evaluating this
tool for use by a faculty member.

**One‑sentence summary:** a local, read‑only desktop tool that uses an instructor's own
Blackboard REST credentials to download that instructor's course submissions to their own
encrypted disk and render a local HTML dashboard — with no third‑party services and no inbound
network exposure.

---

## 1. Trust boundaries & network topology

There are exactly **two** network peers.

```
   ┌─────────────────────────────────────────────────────────────┐
   │  Instructor's machine (macOS, single user account)          │
   │                                                             │
   │   bbdash (Python)                                         │
   │      │  outbound HTTPS (TLS 1.2+), read‑only GETs           │
   │      ▼                                                      │
   │   ── internet ──►  {{BASE_URL}}  (your Blackboard server)   │   ◄── peer #1
   │                                                             │
   │   local "opener" companion                                 │
   │      binds 127.0.0.1:8765  (loopback ONLY)                 │   ◄── peer #2 (localhost)
   │      ▲                                                      │
   │      │  the local HTML dashboard calls it to open files       │
   │   default browser (viewing a local file:// dashboard)         │
   └─────────────────────────────────────────────────────────────┘
```

- **Outbound (peer #1):** direct HTTPS to the institution's own Blackboard REST API. No proxy,
  no intermediary, no vendor cloud, no analytics/telemetry endpoint.
- **Inbound (peer #2):** the optional "opener" companion is a small HTTP listener bound
  **strictly to `127.0.0.1`** (the loopback interface). It is **not** bound to `0.0.0.0` and is
  therefore unreachable from any other device on the campus network — it does not accept LAN or
  remote connections. It is additionally protected by a random per‑machine bearer **token**
  (stored `chmod 600`), and it only ever performs two local actions: (a) open a file that lives
  under the instructor's download folder in its native macOS application, and (b) open a
  pre‑filled `mailto:` draft. It cannot read, write, or serve arbitrary files, and it makes no
  outbound network calls.

> If loopback‑only inbound is still a concern, the companion is optional: set `opener_port: 0`
> and the tool runs with zero listening sockets (dashboard file links degrade to plain `file://`
> links). Nothing else changes.

## 2. Authentication

- **Flow:** OAuth 2.0 **Client Credentials** (two‑legged). The tool sends the instructor's
  Application Key + Secret as an HTTP Basic header to
  `POST {{BASE_URL}}/learn/api/public/v1/oauth2/token` with
  `grant_type=client_credentials`, and receives a short‑lived bearer token.
- **No interactive login, no redirect URI, no browser‑based consent.**
- **Token handling:** the bearer token is held in memory and cached in a `chmod 600` file so
  back‑to‑back runs don't re‑authenticate needlessly. It expires per Blackboard's policy and is
  refreshed automatically; a `401` triggers exactly one transparent re‑auth.
- **Credential storage:** Key, Secret, Base URL, and username live in
  `~/.bbdash/config.json`, created with `0600` permissions (owner read/write only). The
  Secret is never logged or transmitted anywhere except the token endpoint above.

## 3. Complete list of REST endpoints used (all read‑only)

| Method | Endpoint | Purpose |
|---|---|---|
| `POST` | `/learn/api/public/v1/oauth2/token` | Obtain bearer token (credentials only; no data) |
| `GET` | `/learn/api/public/v1/users/userName:{username}/courses` | List the instructor's courses |
| `GET` | `/learn/api/public/v1/courses` · `/courses/{id}` | Course lookup / details |
| `GET` | `/learn/api/public/v1/courses/{id}/users` | Course roster |
| `GET` | `/learn/api/public/v1/users/{id}` | Student name / email for the dashboard |
| `GET` | `/learn/api/public/v2/courses/{id}/gradebook/columns` | Assignment columns + due dates |
| `GET` | `/learn/api/public/v2/courses/{id}/gradebook/columns/{col}/attempts` | Student attempts / status |
| `GET` | `/learn/api/public/v1/courses/{id}/gradebook/attempts/{att}/files` | List + download attempt files |
| `GET` | signed `…/bbcswebdav/…` URL (from the submission body) | Download a file the student attached *inline* in their submission (e.g. a ZIP), fetched on the same Blackboard host |
| `GET` | `/learn/api/public/v1/users/{id}/avatar` | Optional student photo for the dashboard |

**No write endpoints are called.** The application performs no `POST`/`PUT`/`DELETE` against any
data resource (the only `POST` is the credential‑only token request). It never modifies grades,
feedback, course content, or user records. Grade entry remains entirely in Blackboard's own UI.

## 4. Data‑at‑rest lifecycle

All artifacts are written under the single user's home directory on the local, FileVault‑encrypted
disk:

| Location | Contents | Lifecycle |
|---|---|---|
| `~/.bbdash/config.json` | Credentials (`0600`) | Created at setup; user‑controlled |
| `~/.bbdash/token_cache.json` | Short‑lived bearer token (`0600`) | Auto‑expires; safe to delete anytime |
| `~/.bbdash/state.json` | "Already downloaded" bookkeeping | Rebuilds if deleted |
| `~/BB Offline Dashboard/Dashboard/` | Generated HTML dashboards (dashboard + per-assignment/detail pages) | User deletes at will |
| `~/.bbdash/avatars/` | Cached student photos (FERPA data) | User deletes at will |
| `~/BB Offline Dashboard/<Course>/<Assignment>/` | Downloaded submission files (FERPA data) | User deletes at will |

- **Purge:** deleting `~/.bbdash/` and `~/BB Offline Dashboard/` removes all cached student data and
  credentials. The tool re‑creates only what a subsequent run needs.
- **No hidden copies:** the tool writes nothing outside these paths and uploads nothing.
- **Student photos** are the most sensitive artifact; they are embedded into dashboard HTML as
  local data and cached on disk. Dashboards containing them should be treated as FERPA records and
  not shared. Photos can be disabled entirely with `student_photos: false`.

## 5. Execution environments

The tool always runs **the same Python package** (`python3 -m bbdash`) — plain, inspectable `.py`
source under the user's own Python (only runtime dependency: `requests`). There is **no
frozen/obfuscated binary and no bundled third‑party code**; the items below differ only in how
that same command is launched:

- **Command line** — `python3 -m bbdash` (macOS/Linux) or `python -m bbdash` (Windows), typically
  from a project virtual environment.
- **One‑click launcher (optional).** On macOS, a small `osacompile`d AppleScript `.app` that just
  shells out to the same `python3 -m bbdash` (a thin launcher, not a compiled binary; unsigned, so
  Gatekeeper prompts once on first open). On Windows, an optional shortcut / `.ps1` wrapper that
  runs the same command. Either way it's the same source you can review.
- **Scheduled run (optional).** A per‑user **launchd** agent (macOS) or **Task Scheduler** task
  (Windows) runs the tool at login / a set morning time — as the user (never root), with the
  user's own credentials, performing the same read‑only calls, and removable with a single
  command. No system‑level daemon or elevated privilege is used.

A signed, frozen, downloadable installer is possible future work; it is explicitly out of scope
here.

## 6. Supply chain

- Runtime dependency surface is intentionally tiny: **`requests`** (HTTPS client) plus the
  Python standard library. No web framework, no headless browser, no scraping/automation stack,
  no cloud SDKs.
- The source is distributed as readable `.py` files for inspection.

## 7. What this tool deliberately does **not** do

- No browser automation or credential scraping (it uses the official REST API only).
- No writing to Blackboard (read‑only).
- No outbound connection to anything other than the institution's own Blackboard host.
- No listening socket reachable off‑device.
- No transmission of student data to the tool's author, Anthology, Anthropic, or any third
  party.

---

*Contact for questions or a source walkthrough: {{YOUR_NAME}} <{{YOUR_EMAIL}}>.*
