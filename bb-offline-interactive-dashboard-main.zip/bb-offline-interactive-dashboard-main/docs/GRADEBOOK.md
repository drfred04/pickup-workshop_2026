# GRADEBOOK — design brief for the in-dashboard scoring feature

**Status:** design brief / not yet implemented. Written as the starting spec for a fresh session.
The four product decisions in §5 are now **settled** (see each ✅ below); build to them.
**Goal:** let the instructor record a score for each student *while reviewing their submissions in
the dashboard*, save those scores locally, and export them for entry/import into Blackboard.

> Read `README_TECHNICAL.md` and `docs/ARCHITECTURE.md` first for how the tool is put together.
> This brief assumes that context.

---

## 0. The hard constraint (read this first)

**The tool is read-only to Blackboard. This feature must not change that.** The whole basis of the
IT approval (`docs/IT_APPROVAL_EMAIL.md`) and the security review (`docs/ARCHITECTURE.md` §3, §7)
is that the app makes **only** read-only GETs and **never** writes grades/content back to
Blackboard. So:

- The gradebook is a **local artifact**. Scores are stored on the instructor's machine and
  **exported as a CSV** the instructor imports into Blackboard (Gradebook → Work Offline → Upload)
  or types in by hand.
- **Do NOT** add any API call that posts grades. No `POST`/`PUT`/`PATCH` to any Blackboard grade
  endpoint, ever. If someone asks for "push grades to Blackboard," that's a *different* project
  with a *different* IT approval — out of scope here.

When this feature ships, update `docs/ARCHITECTURE.md` §4 (a new local scores file joins the
data-at-rest table — grades are FERPA-sensitive) and note the CSV export path.

---

## 1. Why this is tractable: reuse the "opener" companion

The dashboard is a static `file://` HTML page — it can't write files by itself. But the project
**already** has the exact mechanism needed: the **opener companion** (`bbdash/opener.py`), a
token-protected local server on `127.0.0.1` that the dashboard calls. It already:

- `GET /open`  — open a file in its native app
- `GET /mail`  — open a pre-filled mailto draft
- `POST /avatar` — **receives data from the browser and writes a file** (a dropped photo)

**Saving a score is the same pattern as `/avatar`.** Add a `POST /grade` endpoint that accepts
`{course_id, column_id, user_id, score, (optional) comment}` (token-checked) and writes it to a
local **scores store**. The dashboard's JS posts to it exactly like the avatar-drop code does
(`bbdash/dashboard.py` → `_avatar_script`, and `bbOpen`/group-mail scripts are the JS templates to
copy). No new server, no new dependency.

If `opener_port: 0` (companion disabled), the grading UI should degrade gracefully — e.g. inputs
still work in-page and a **"Download CSV"** button lets the user save scores manually (see §4).

---

## 2. The scores store (the heart of the feature)

Dashboards are regenerated every run (now one timestamped snapshot per run,
`Dashboard/YYYY-MM-DD__HH-MM.html`), so **scores cannot live in the HTML**. They live in a
separate store, keyed by **identity, not by run**, so every snapshot sees the same scores:

- **Key:** `(course_id, column_id, user_id)` — all stable Blackboard ids the tool already has
  (`bbdash/discover.py`: courses, gradebook columns, roster/`NameInfo`).
- **Value:** `{ score, comment?, updated_at }`.
- **Format & location (settled, §5):** a single JSON file the companion read-modify-writes
  atomically (write temp + `os.replace`, like `state.py`/`opener.py` already do for `0600` files) at
  **`~/.bbdash/grades.json`**. JSON is robust for incremental single-cell writes; **CSV is the
  export** only, generated on demand into `~/BB Offline Dashboard/Gradebook/` (grouped per course,
  Blackboard-import-shaped).

**Concurrency:** two processes touch the store — the **companion** writes on each `POST /grade`,
and the **morning run** reads it at dashboard-generation time to pre-fill inputs. Overlap is rare
(single user), but write atomically and re-read before write. `bbdash/state.py` is the existing
JSON-persistence pattern to follow.

**Reload into new dashboards:** `bbdash/main.py` `run()` should load the store and pass the scores
into `DashboardData` so `render()` pre-fills each input's `value=` — your entered scores reappear
in every future dashboard. This is what makes it feel like a persistent gradebook.

---

## 3. Where the grading UI goes

**Settled (§5): the per-assignment roster page is the primary home**, with the same input mirrored
on the detail page. The roster page (`bbdash/dashboard.py` `_render_assignment_page`, one row per
student, already shows each student's status + file links) is where you're already looking at each
student's files, so add a **Score** input and an optional **comment** field per row, plus a
**"Download CSV"** button for that assignment. The per-student **detail page** gets the same input
(same store) for when a submission is opened up close. A dedicated course **gradebook grid**
(students × assignments) is a possible later phase, not phase 1.

The flow is: type a score → JS `POST /grade` to the companion → companion writes the store → a
small "saved ✓" affordance. Debounce/save-on-blur so it isn't chatty.

---

## 4. Export (the deliverable)

A **"Download CSV"** action produces a file the instructor imports into Blackboard or reads while
entering grades manually. Two ways to emit it:

- Companion writes the CSV to `~/BB Offline Dashboard/Gradebook/<Course>.csv` on demand (reuse
  `bbdash/gradesheet.py`, which already writes the per-course `submission_status.csv` matrix), and
  `/open`s it; **or**
- The page builds the CSV client-side from the current inputs and triggers a browser download (works
  even with the companion off).

Match Blackboard's Work-Offline upload column shape if feasible (verify against a real export);
otherwise a clear `Last, First, Username, Score` CSV the instructor pastes/enters.

---

## 5. Product decisions — SETTLED

1. **UI placement ✅ — per-assignment roster page (primary).** Add a **Score** input (plus an
   optional **comment** field) per student row on `_render_assignment_page`, where the files +
   status already are — grading happens while reviewing. **Also mirror the same input on the
   per-student detail page**, writing to the same store, for when a submission is opened up close.
   A whole-course editable grid is a possible *later* phase, not phase 1.
2. **Store ✅ — JSON is the source of truth; CSV is an export.** Live store = a JSON file the
   companion read-modify-writes atomically at **`~/.bbdash/grades.json`** (`0600`, follow the
   `state.py` pattern) — JSON handles single-cell updates cleanly, which CSV does not. CSV is
   **generated on demand** (never the store of record) into the visible
   **`~/BB Offline Dashboard/Gradebook/`** so it's easy to find and use.
3. **Scope ✅ — points + optional comment, one assignment at a time.** Per student per assignment:
   a numeric score and an optional short comment (comments are ~free on the same `POST /grade`).
   No whole-course grid in phase 1.
4. **Export ✅ — Blackboard-import-shaped CSV, with a browser-download fallback.** Target the
   Gradebook **Work-Offline upload** column format — **verify the exact columns against a real
   export early** (before building the writer); fall back to a clean `Last, First, Username, Score`
   CSV if matching is impractical. The companion writes the CSV to the `Gradebook/` folder **and**
   the page offers a client-side "Download CSV" so export still works when `opener_port: 0`.

---

## 6. Suggested phased plan

1. **Store + companion write path.** New `bbdash/grades.py` (load/save/merge, atomic). Add
   `POST /grade` to `bbdash/opener.py` (token-checked, validated). Unit-test the store and the
   endpoint with a fake request (mirror `tests/` style — stdlib `unittest`, no new deps).
2. **Reload into the dashboard.** `main.py` loads scores → `DashboardData`; `render()` pre-fills
   input values on the roster page. Verify a score survives a re-render (a new snapshot shows it).
3. **UI + save-on-blur JS.** Add the input(s) + a JS `postGrade()` (copy the avatar-drop fetch),
   with a "saved ✓" affordance and graceful degrade when `opener_port: 0`.
4. **CSV export.** "Download CSV" per course/assignment; confirm the shape against a real
   Blackboard Work-Offline upload template.
5. **Docs + tests.** Update `README_TECHNICAL.md` (feature + config), `docs/ARCHITECTURE.md` §4
   (new local grades file; FERPA note), and the demo so colleagues can see it. Add regression
   tests. Keep the read-only-to-Blackboard guarantee intact.

---

## 7. Code map (files this will touch)

| File | Role in this feature |
|---|---|
| `bbdash/opener.py` | Add `POST /grade`; the write path (model on `do_POST` `/avatar`) |
| `bbdash/grades.py` *(new)* | Load/save/merge the scores store atomically; build CSV |
| `bbdash/dashboard.py` | Grading inputs on the roster page; `postGrade()` JS; pre-fill values |
| `bbdash/main.py` | Load scores into `DashboardData` before `render()` |
| `bbdash/config.py` | Optional: store location / a `gradebook_*` setting |
| `bbdash/gradesheet.py` | Reuse for CSV writing conventions |
| `tests/` | New tests for the store, the endpoint, and CSV export |

**Guardrails:** token-protect `/grade`; validate inputs (numeric/bounded score); write `0600`;
never call a Blackboard write endpoint; treat the scores file as FERPA data (local only, gitignored
under the existing `/BB Offline Dashboard/` and `~/.bbdash` rules).
