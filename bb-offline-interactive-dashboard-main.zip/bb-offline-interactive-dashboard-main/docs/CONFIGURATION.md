# CONFIGURATION — how the tool reads your credentials

This tool has **one** configuration system: a JSON file at `~/.bbdash/config.json`, with
optional **environment‑variable overrides** for the credentials. There is intentionally no
`.env` file and no separate secret store in this version — one mechanism, easy to audit.

The file may include `//` line comments and `/* */` block comments (JSONC) to annotate your
settings; markers inside string values (like a `https://` URL) are preserved.

Both the command line and the optional double‑click app use this same file. You set it up **once**.

---

## Option 1 (recommended) — setup helper

```bash
python3 install/setup_config.py                 # Windows: python install\setup_config.py
```

By default this **creates `~/.bbdash/config.json` from a template and opens it in your editor**
so you can paste in your Application Key, Application Secret, and username (the Base URL is
pre‑filled) and save. Re‑running never overwrites an existing config — it just reopens it.

Prefer to type each value at a prompt instead (Secret masked with `*`)? Add `--interactive`:

```bash
python3 install/setup_config.py --interactive
```

Either way it writes the file with `chmod 600` (owner‑only) on macOS/Linux; on Windows it lives
in your private user profile. No dependencies beyond the Python standard library.

## Option 2 — edit the template by hand

```bash
mkdir -p ~/.bbdash
cp config.example.json ~/.bbdash/config.json
chmod 600 ~/.bbdash/config.json
# then edit ~/.bbdash/config.json
```

Minimum required fields:

```json
{
  "domain": "https://blackboard.yourschool.edu",
  "application_key": "PASTE-YOUR-APPLICATION-KEY",
  "application_secret": "PASTE-YOUR-APPLICATION-SECRET",
  "instructor_username": "your-blackboard-username",
  "term_filter": ["Fall 2026"],
  "course_filter": []
}
```

> `domain` is your **Base URL** (scheme + host, no trailing path). `application_key` is the
> **Key**, not the Application **ID**.
>
> To restrict which courses the tool watches, prefer `term_filter` — a list of semester names
> (e.g. `["Fall 2026"]`), matched case-insensitively against each course's term (a substring is
> enough, so `"Fall 2026"` also matches a term named `"Fall 2026 Undergraduate"`). Alternatively
> use `course_filter` with specific course IDs/codes. Leave **both** empty (`[]`) to watch every
> course you teach. Run `--check` to see your courses with their exact term names.

## Option 3 — environment variables (power users / no file)

Any of these override the file, which is handy for testing or keeping the Secret out of a file
entirely (e.g., injected by your shell profile or a secrets manager):

```bash
export BB_DOMAIN="https://blackboard.yourschool.edu"
export BB_APPLICATION_KEY="…"
export BB_APPLICATION_SECRET="…"
export BB_INSTRUCTOR_USERNAME="jsmith"
python3 -m bbdash --check
```

---

## How the app loads it (for reviewers)

The loader (`bbdash/config.py`) reads the JSON file if present, then applies the
`BB_*` environment overrides, and **fails fast with a clear error** if required credentials are
missing — it does not fall back to prompting or to insecure defaults:

```python
# bbdash/config.py  (excerpt — this already ships in the tool)
def load_config(path=None, require_credentials=True):
    cfg_path = _expand(path) if path else DEFAULT_CONFIG_PATH   # ~/.bbdash/config.json
    data = {}
    if cfg_path.exists():
        _warn_if_world_readable(cfg_path)                       # nudge to chmod 600
        data = json.loads(_strip_jsonc(cfg_path.read_text()))  # tolerate // and /* */ comments

    # Environment variables take precedence over the file.
    for field_name, env_name in {
        "domain": "BB_DOMAIN",
        "application_key": "BB_APPLICATION_KEY",
        "application_secret": "BB_APPLICATION_SECRET",
        "instructor_username": "BB_INSTRUCTOR_USERNAME",
    }.items():
        if os.environ.get(env_name):
            data[field_name] = os.environ[env_name]

    if require_credentials:
        missing = [k for k in ("domain", "application_key", "application_secret")
                   if not data.get(k)]
        if missing:
            raise ConfigError(
                "Missing required config value(s): " + ", ".join(missing)
                + f".\nProvide them in {cfg_path} (see config.example.json) "
                  "or via environment variables."
            )
    return Config(...)
```

Security properties worth noting for an audit:

- The config file is created `0600` and the loader **warns** if it is ever group/world‑readable.
- The Secret is only ever sent to your Blackboard token endpoint; it is never logged.
- Missing credentials raise a descriptive `ConfigError` — no silent misconfiguration.

---

## Roadmap (not in this version)

A future release may store the Secret in the OS credential manager (macOS Keychain via the
`keyring` library) instead of a file, and add a graphical first‑run credential dialog.

**Important caveat we've already flagged:** this tool's headline feature is an **unattended
scheduled run** (via `launchd`). Reading a secret from the Keychain non‑interactively can
prompt for an unlock or fail when no GUI session is active, which would break the automated
morning run. So even when Keychain support lands, the file‑based path (`chmod 600`) will remain
the supported option for scheduled/unattended use. That is why this current version stays with
the audited file + env‑var model rather than adopting `keyring` prematurely.
