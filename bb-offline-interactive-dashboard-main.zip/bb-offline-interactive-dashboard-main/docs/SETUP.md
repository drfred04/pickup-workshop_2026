# SETUP — Register your Blackboard REST application (BYOK)

This tool uses a **Bring‑Your‑Own‑Key (BYOK)** model. There is no shared account and no
vendor cloud. Each instructor registers their *own* developer application, gets their *own*
credentials, and has their *own* campus IT approve it on their institution's Blackboard.

You will end up with **four values** that you give to the app:

| Value | Example | Where it comes from |
|---|---|---|
| **Application Key** | `a1b2c3d4-…` | developer.anthology.com (Step 2) |
| **Application Secret** | `f9…rfYg` | developer.anthology.com (Step 2) — **secret, never share** |
| **Blackboard Base URL** | `https://blackboard.yourschool.edu` | your campus (Step 4) |
| **Your Blackboard username** | `jsmith` | the name you log into Blackboard with |

> ⚠️ **The Application *Key* is not the same as the Application *ID*.** The portal shows both.
> The app needs the **Key** (and the **Secret**), not the ID. Copying the ID into the Key
> field is the single most common setup mistake — it produces an HTTP 401 at run time.

---

## Step 1 — Create a developer account

1. Go to **https://developer.anthology.com** (formerly `developer.blackboard.com`).
2. Click **Register / Sign up** and create an account with your university email.
3. Verify your email and sign in.

## Step 2 — Register a new REST application

1. In the developer portal, open **My Applications → Create Application** (wording varies by
   portal version).
2. Fill in:
   - **Application Name:** e.g. `Morning Submission Dashboard (jsmith)` — include your username so
     your IT admin can identify it later.
   - **Description:** *Read‑only tool that downloads an instructor's own course submissions to
     the instructor's local machine and builds a local grading dashboard. No data leaves the
     machine.*
   - **Domain(s) / Redirect / OAuth callback:** **Leave any Redirect URI / OAuth callback field
     blank.** This application uses the **Client Credentials** grant (see box below), which does
     *not* use a redirect URI. If the form forces a value, `https://localhost` is a harmless
     placeholder — the app never uses it.
3. Submit. The portal will display:
   - **Application ID** (you do **not** need this for the app; keep it — your IT admin will).
   - **Application Key** ← you need this.
   - **Application Secret** ← you need this. It is shown **once**. Copy it immediately.

> **Why no Redirect URI?** This tool authenticates with the two‑legged **Client Credentials**
> OAuth 2.0 flow: it sends your Key + Secret directly to your Blackboard's token endpoint and
> receives a short‑lived bearer token. There is no browser login, no consent screen, and
> therefore no redirect URI. (A future version may offer a three‑legged "log in with your
> Blackboard account" flow; that one *would* use a redirect URI. This version does not.)

## Step 3 — Record your Application ID for IT

Your campus Blackboard administrator approves applications **by Application ID** on your
institution's Blackboard instance. Copy the **Application ID** now — you will paste it into the
IT approval email (see `IT_APPROVAL_EMAIL.md`). Registering the app in the portal does **not**
grant it access to your institution's data; only your admin can do that (Step 5).

## Step 4 — Find your Blackboard Base URL

The Base URL is simply the address you use to log into Blackboard, with no path after the
hostname. To find it:

1. Log into Blackboard in your browser the way you normally do.
2. Look at the address bar. Take the `https://` and the hostname, and drop everything after it.

Common shapes:

- `https://blackboard.yourschool.edu`
- `https://yourschool.blackboard.com`
- `https://learn.yourschool.edu`

Example: if your browser shows
`https://blackboard.yourschool.edu/ultra/course`, your Base URL is
`https://blackboard.yourschool.edu`.

## Step 5 — Get campus IT approval (the real gate)

Registering the app is not enough. Your institution's Blackboard **System Administrator** must
approve your Application ID **on your institution's instance** and grant it read access. This is
usually a quick change for them, but it is the step that actually unblocks the tool — and it can
take days depending on your IT ticket queue.

➡️ Send the email in **`IT_APPROVAL_EMAIL.md`** to your Blackboard/LMS administrator. It is
pre‑written and explains exactly what to approve and why it is FERPA‑safe.

Until IT approves your Application ID, every run will fail with **HTTP 401 Unauthorized** — this
is expected, not a bug.

## Step 6 — Enter your credentials into the app

Run the guided setup once — `python3 install/setup_config.py` — or copy `config.example.json`
and fill it in (see `CONFIGURATION.md` and the master `README.md`). This is a one‑time step; after
that, both the command line and the optional one‑click app just run.

## Step 7 — Verify

```bash
python3 -m bbdash --check
```

This authenticates, lists the courses the app can see, and downloads nothing. If it prints
your courses, you are done. If it prints an error, see the **Troubleshooting** section of the
master `README.md`.

---

### Security reminders

- Your **Application Secret** is a password. **Never** email it, paste it into a ticket, commit
  it to a repository, or share it — not even with IT. IT only needs your **Application ID**.
- The app stores your credentials in a file readable only by your user account
  (`~/.bbdash/config.json`, permissions `600`). Do not loosen those permissions.
- If you ever suspect your Secret leaked, return to the developer portal and **rotate
  (regenerate) the Secret**, then re‑run the setup.
