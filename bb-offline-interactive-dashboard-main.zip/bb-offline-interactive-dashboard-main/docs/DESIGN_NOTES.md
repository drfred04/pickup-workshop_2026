# BB Offline Dashboard — Design Notes

*(Original implementation plan, kept for historical context — the tool is now live and has grown
beyond this design. A few things below no longer match the shipping code: the generated artifact
called the “morning report” here is now the **dashboard** (module `report.py` → `dashboard.py`); the
planned `analyze.py` logic ended up inline in `main.py`; later modules (`submission.py` for inline
attachments, `gradebook.py`, `osutil.py`, `util.py`) aren't shown; and the current on-disk layout is
`~/BB Offline Dashboard/` with the dashboard under its `Dashboard/` subfolder. For the authoritative
current picture see `README_TECHNICAL.md` and `docs/ARCHITECTURE.md`.)*

A daily, automated tool that downloads new Blackboard assignment submissions for all of
Larry Engelhardt's courses and produces a morning summary report.

Status: **Planning / blocked on IT** (waiting for the REST API integration to be registered
on FMU's Blackboard instance — Application ID `d74c2bc7-2130-496f-8029-d2779f91ad96`).

---

## What it does

Every morning at login, the script:

1. Scans **all** the professor's courses for assignments that recently came due.
2. Downloads any **new** submission files (and text/online-text submissions).
3. Files everything into `Course / Assignment / LastName_FirstName_...`.
4. Produces an **auto-opening report file** summarizing the night's activity.

---

## Confirmed requirements (decisions log)

| Decision | Choice |
|---|---|
| Scope | **All assignments**, all courses, automatically |
| Trigger | **Auto-run at login** every morning (macOS launchd LaunchAgent) |
| Text/online-text submissions | **Save them** (as `.txt`) |
| Python code submissions (`.py`/`.pyw` + `.ipynb` notebooks) | Keep the original **and** write a `_nocomments` copy with all `#` comments stripped (via `tokenize`, so `#` inside strings is safe) and docstrings removed (via AST; `strip_docstrings`, default on; sole-statement docstrings replaced with `pass`). **Shebang lines kept.** For notebooks, only Python code cells are stripped; markdown + cell-magic cells untouched |
| Status spreadsheet | Each run writes/overwrites a per-course `submission_status.csv`: columns = Last Name, First Name, then one per assignment; cell = blank (on time), `L` (late), `X` (missing, past due); blank if not yet due. Also shown inline in the report as a grid with big red ✕'s |
| Student identifier | Report shows the student's **email** after their name (from the API `contact.email`, falling back to `<username>@<student_email_domain>`); filenames still use username |
| Open-file companion | A localhost-only server (token-protected, restricted to `output_dir`) lets report filename links open files in their native macOS app via `open`. Disable with `opener_port: 0` |
| Re-run behavior | **Skip unchanged files** (SHA-256 hash check); if a file changed, **keep both versions** |
| Directory structure | `BB Offline Dashboard / <Course> / <Assignment> / <files>` |
| File naming | Start with **LastName_FirstName_** then username + original filename |
| Report delivery | **Auto-opening report file** (stays local; no student data transmitted) |
| Late submissions | **Always watched, indefinitely**; each late arrival reported **once**, the morning after it lands |
| Missing — freshly due | Reported in the morning report when the assignment comes due |
| Missing — older assignments | Re-surfaced **once per week** (weekly outstanding-work roundup), never daily |

---

## Reporting cadence

- **Daily report:** new on-time submissions, newly-arrived late submissions (any age of
  assignment), and missing students for assignments that just came due.
- **Weekly roundup:** outstanding (still-missing) submissions for older assignments.
- A **state file** ensures every event is reported exactly once; missing-work re-surfaces
  only on the weekly cadence.

---

## Directory & naming example

```
BB Offline Dashboard/
├── PHYS 301 - General Physics/
│   ├── Homework 3/
│   │   ├── Engelhardt_Larry_lengelhardt_lab3.pdf
│   │   └── Smith_John_jsmith_lab3.pdf
│   └── Midterm/
└── PHYS 205 - Modern Physics/
```

Resubmissions: Blackboard typically creates a **new attempt** (own ID) rather than
overwriting, so "keep both versions" is natural; a SHA-256 hash stored in state is the
backstop — identical file is skipped, a changed file is saved alongside with a version/date
suffix. *(Resubmission behavior to be verified against docs.)*

---

## Architecture

| Module | Responsibility |
|---|---|
| `config.py` | Load domain + credentials (Key/Secret) from a local 0600 config file or env vars |
| `auth.py` | OAuth Bearer token (Client Credentials flow); cache + auto-refresh on expiry/401 |
| `api.py` | GET wrapper: Bearer header, full pagination, retry/backoff on 429/5xx |
| `discover.py` | Scan all courses, find recently-due assignments, build rosters |
| `analyze.py` | Compute submitted / missing / late from attempts vs roster vs due date |
| `download.py` | Download new files only (hash-checked) into the Course/Assignment tree |
| `codeproc.py` | For `.py`/`.pyw`/`.ipynb` submissions, write a comment-stripped `_nocomments` copy alongside the original |
| `gradesheet.py` | Write the per-course `submission_status.csv` matrix (on time / late / missing) |
| `opener.py` | Localhost "open file in native app" companion (token-protected, `output_dir`-scoped) |
| `report.py` | Generate the auto-opening morning report (HTML) |
| `state.py` | Persist seen submissions, reported events, file hashes, weekly-roundup timestamp |
| `main.py` | Orchestrates a single morning run |

---

## REST API endpoints used

| Purpose | Endpoint |
|---|---|
| List my courses | `GET /learn/api/public/v1/courses` |
| List assignments (with due dates) | `GET /learn/api/public/v2/courses/{courseId}/gradebook/columns` |
| List enrolled students | `GET /learn/api/public/v1/courses/{courseId}/users` |
| List submission attempts | `GET /learn/api/public/v2/courses/{courseId}/gradebook/columns/{columnId}/attempts` |
| List files on an attempt | `GET /learn/api/public/v1/courses/{courseId}/gradebook/attempts/{attemptId}/files` |
| Download a file | `GET /learn/api/public/v1/courses/{courseId}/gradebook/attempts/{attemptId}/files/{attemptFileId}/download` ✓ verified |
| Look up a student by ID | `GET /learn/api/public/v1/users/{userId}` |

---

## Critical dependency: OAuth flow

Unattended morning runs require a token obtainable **without** a browser login →
**Client Credentials flow** (Key + Secret → token). If IT enables only the interactive
**Authorization Code flow**, fully unattended runs become awkward (periodic re-auth).
**When IT replies, confirm which flow is enabled; Client Credentials is preferred.**

---

## Phase plan

1. Auth — Client Credentials token + caching (Authorization Code as fallback)
2. API client — Bearer auth, full pagination, retry/backoff
3. Discovery — scan all courses, find recently-due assignments, build rosters
4. Analysis — compute submitted / missing / late
5. Download — new files only, hash-checked, into Course/Assignment tree
6. Report — generate auto-opening morning summary (HTML)
7. State — persist seen/reported events + file hashes + weekly timestamp
8. Scheduling — launchd LaunchAgent (RunAtLoad) for login auto-run
9. Test — dry run on one course, then scale to all

---

## Open items (now resolved)

The tool is **live and validated end‑to‑end** against FMU's Blackboard (`fmarion.blackboard.com`)
and has since been extended to Windows, so the questions that were open during design are settled:

**Was "waiting on IT" — now confirmed:**
- OAuth flow: **Client Credentials** is enabled and in use (unattended, no browser).
- Scoping: the integration is granted app‑level **read** entitlements; the tool self‑restricts to
  the instructor's own courses via `course_filter`.
- The integration is registered and read‑only access works (`--check` + downloads succeed).

**Was "still to confirm during implementation" — now confirmed:**
- Resubmission handled via per‑file hashing (keeps a copy when a file actually changed).
- Pagination: follow `paging.nextPage` until absent — verified against the live token.

**Verified API facts (kept for reference):**
- **File download** is a dedicated sub-path: `.../files/{attemptFileId}/download` — *not* a
  `viewUrl` field. The original script's download logic was wrong and would have failed.
- **Due date** field is `grading.due` (ISO 8601), on the gradebook column.
- **Attempt** objects expose: `id`, `userId`, `status`, `created`, `attemptDate`, `modified`,
  `studentSubmission`, and `attemptReceipt { receiptId, submissionDate, submissionTotalSize }`.
  → Late detection: compare `attemptDate` (or `attemptReceipt.submissionDate`) vs `grading.due`.
- **Attempt status** values: `InProgress`, `NeedsGrading`, `Completed`, `InProgressAgain`,
  `NeedsGradingAgain`. (The original script filtered on `Graded`/`ReadyToSubmit`, which are
  NOT valid v2 values — it would have silently dropped real submissions.)
- **Attempts endpoint** should use **v2**: `/learn/api/public/v2/.../columns/{columnId}/attempts`
  (original used v1).

Sources: Anthology "Pulling Gradebook Data and Assessment Grades" docs; Blackboard REST API
attempt object schema; developer portal API reference.
