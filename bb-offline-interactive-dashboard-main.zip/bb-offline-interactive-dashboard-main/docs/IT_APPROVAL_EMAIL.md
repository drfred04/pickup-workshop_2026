# IT Approval Email — template

Send this to your campus **Blackboard / LMS System Administrator** (often in IT, Instructional
Technology, or the Center for Teaching & Learning). Replace every `{{PLACEHOLDER}}`.

Attach or link **`ARCHITECTURE.md`** — it is written specifically for a security review and
will answer most follow‑up questions.

> **Accuracy note (read before sending):** This tool uses the two‑legged **Client Credentials**
> OAuth flow. That means the registered *application* is granted read scopes at the system
> level by you (the admin); it does not "act as" the instructor via an interactive login. The
> tool **self‑restricts in software** to the instructor's own courses (via a configurable course
> filter), but that restriction is a property of the software, not of the entitlement grant. The
> email below states this honestly. Please do not edit it to claim the app is technically
> incapable of seeing other courses — a reviewer will check, and the accurate story is still a
> good one.

---

**To:** {{IT_ADMIN_EMAIL}}
**Subject:** Approval request — read‑only Blackboard REST application (App ID {{APPLICATION_ID}})

Dear {{IT_ADMIN_NAME}},

I am requesting approval for a Blackboard REST API application on our institution's Blackboard
instance so that I can download my own courses' student submissions to my office computer for
local grading.

**What I'm asking you to do:** approve the following application on our Blackboard instance and
grant it read‑only REST access.

- **Application ID:** `{{APPLICATION_ID}}`
- **Application name (in the developer portal):** `{{APPLICATION_NAME}}`
- **Requested by:** {{YOUR_NAME}}, {{YOUR_DEPARTMENT}}, Blackboard username `{{YOUR_USERNAME}}`
- **Grant type:** OAuth 2.0 **Client Credentials** (two‑legged; no interactive login, no
  redirect URI)

**What the application does, precisely.** It is a local desktop tool. On each run it:

1. Authenticates to `{{BASE_URL}}/learn/api/public/v1/oauth2/token` over HTTPS (TLS 1.2+).
2. Lists the courses I teach, their rosters, gradebook columns, and student attempts.
3. Downloads the submitted files/text to an access‑controlled folder on my local machine.
4. Builds an HTML summary that is viewed locally in my browser.

**Every data call is read‑only (HTTP GET).** The complete list of REST endpoints it uses is in
the attached `ARCHITECTURE.md`. It never writes grades, never modifies course content, and
never calls any `MODIFY`/`POST`/`PUT`/`DELETE` data endpoint.

**FERPA / data handling.**

- **No third‑party cloud.** The tool talks to exactly two places: our own Blackboard server
  (outbound HTTPS) and `127.0.0.1` (a localhost‑only helper on my machine). No student data is
  transmitted to any external or vendor service. There is no analytics, telemetry, or
  "phone‑home."
- **Transport security.** All Blackboard calls use HTTPS (TLS 1.2+) via the standard Python
  `requests` library and the OS certificate store.
- **Data at rest, local only.** Submissions and the generated dashboard are stored on my
  institution‑managed, encrypted (FileVault) local disk, under my user account, and can be
  deleted by me at any time.
- **Scope of access.** The application is granted application‑level read entitlements by you.
  The software is configured to restrict itself to the courses I teach; I am happy to have that
  configuration reviewed. If our instance supports scoping the grant more tightly (e.g., to
  specific entitlements or courses), I welcome the tightest scope that still allows reading my
  own courses' submissions.
- **Credential handling.** The application Secret is stored in a permission‑restricted file
  (`chmod 600`) on my machine and is never shared or transmitted anywhere except our Blackboard
  token endpoint.

**Entitlements needed (read‑only).** The app needs to read: the course list for my account,
course memberships (rosters), gradebook columns, student attempts, attempt files, and user
profile/avatar data. These correspond to standard read entitlements — I've listed the exact
endpoints in `ARCHITECTURE.md` so you can grant the minimum necessary.

I'm glad to meet, do a screen‑share walkthrough, or provide the source code for review. I know
these requests take care to evaluate, and I appreciate your time in getting it approved.

Thank you,

{{YOUR_NAME}}
{{YOUR_TITLE}}, {{YOUR_DEPARTMENT}}
{{YOUR_EMAIL}} · {{YOUR_PHONE}}

---

### Follow‑up notes (do not include in the email)

- If IT replies that they can only enable the **Authorization Code (three‑legged)** flow, that is
  a different setup — tell the tool's maintainer; a three‑legged version is on the roadmap.
- If IT asks "why not use the built‑in gradebook download?" — this tool complements it: it
  fetches the *submission files themselves* (code, notebooks, plots) for offline grading, which
  the gradebook "Work Offline" export does not do.
- Keep your **Application Secret** out of all correspondence. IT only needs the **Application
  ID**.
